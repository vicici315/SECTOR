﻿// Unity built-in shader source. Copyright (c) 2016 Unity Technologies. MIT license (see license.txt)

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Profiling;

namespace UnityEditor
{
    internal class CFShaderGUIBase : ShaderGUI
    {


#if USE_CUSTOM_UNITY
        public enum BlendMode
        {
            Opaque,
            Cutout,
            AlphaBlend,   // Old school alpha-blending mode, fresnel does not affect amount of transparency
            Transparent, // Physically plausible transparency mode, implemented as alpha pre-multiply
            Add,
            MultiAlphaAdd,
        }

        public enum CullMode
        {
            DoubleSide = 0,
            Front = 1,
            Back = 2,
        }
        protected MaterialEditor m_MaterialEditor;

        int testShaderLod = Shader.globalMaximumLOD;
        protected bool showAllProperties = false;
        bool m_FirstTimeApply = true;
        HashSet<string> m_ProcessedProperties;
        bool m_FixAllMode = false;
        bool m_PreviewMode = false;
        static bool m_ForceFixAllMode = false;

        public static void StartForceFixAll()
        {
            m_ForceFixAllMode = true;
        }

        public static void StopForceFixAll()
        {
            m_ForceFixAllMode = false;
        }

        protected MaterialProperty FindAndMarkProperty(string propertyName, MaterialProperty[] properties)
        {
            if (m_ProcessedProperties != null)
                m_ProcessedProperties.Add(propertyName);
            return ShaderGUI.FindProperty(propertyName, properties);
        }
        protected MaterialProperty FindAndMarkProperty(string propertyName, MaterialProperty[] properties, bool propertyIsMandatory)
        {
            if (m_ProcessedProperties != null)
                m_ProcessedProperties.Add(propertyName);
            return ShaderGUI.FindProperty(propertyName, properties, propertyIsMandatory);
        }
        protected void MarkProperty(string propertyName)
        {
            if (m_ProcessedProperties != null)
                m_ProcessedProperties.Add(propertyName);
        }
        protected virtual void DoFirstTimeApply(Material material, MaterialProperty[] props)
        {
            OnMaterialChanged(material);
        }
        public override void AssignNewShaderToMaterial(Material material, Shader oldShader, Shader newShader)
        {
            base.AssignNewShaderToMaterial(material, oldShader, newShader);
        }
        public virtual void OnMaterialChanged(Material material)
        {
            if (blendMode != null)
            {
                var currentBlendMode = (BlendMode)material.GetFloat(blendMode.name);
                SetupMaterialWithBlendMode(material, currentBlendMode);
            }

        }
        protected virtual bool DrawManagedProperties(Material material, MaterialProperty[] props)
        {
            return false;
        }

        protected virtual bool defaultDrawTilingOffset { get { return true; } }

        protected MaterialProperty blendMode = null;
        protected MaterialProperty cullMode = null;
        private static class Styles
        {
            public static string renderingMode = "Rendering Mode";
            public static string cullMode = "Cull Mode";
            public static readonly string[] blendNames = Enum.GetNames(typeof(BlendMode));
            public static readonly string[] cullNames = Enum.GetNames(typeof(CullMode));
        }
        public virtual void FindProperties(MaterialProperty[] props)
        {
            // 对CFStandard系列的shader而言，_BlendMode选项是无效的。统一用_SubMode设置。
            blendMode = FindProperty("_BlendMode", props, false);
            cullMode = FindProperty("_cull", props, false);
        }
        protected void BlendModePopup()
        {
            EditorGUI.showMixedValue = blendMode.hasMixedValue;
            var mode = (BlendMode)blendMode.floatValue;

            EditorGUI.BeginChangeCheck();
            mode = (BlendMode)EditorGUILayout.Popup(Styles.renderingMode, (int)mode, Styles.blendNames);
            if (EditorGUI.EndChangeCheck())
            {
                m_MaterialEditor.RegisterPropertyChangeUndo("Rendering Mode");
                blendMode.floatValue = (float)mode;
            }

            EditorGUI.showMixedValue = false;
        }

        protected void CullModePopup()
        {
            EditorGUI.showMixedValue = cullMode.hasMixedValue;

            CullMode cull = (CullMode)cullMode.floatValue;
            EditorGUI.BeginChangeCheck();
            cull = (CullMode)EditorGUILayout.Popup(Styles.cullMode, (int)cull, Styles.cullNames);
            if (EditorGUI.EndChangeCheck())
            {
                m_MaterialEditor.RegisterPropertyChangeUndo("Cull Mode");
                cullMode.floatValue = (float)cull;
            }
            EditorGUI.showMixedValue = false;
        }
        protected virtual void DrawHeaders()
        {
            if (blendMode != null)
            {
                BlendModePopup();
            }
            if (cullMode != null)
            {
                CullModePopup();
            }
        }
        public static void SetupMaterialWithBlendMode(Material material, BlendMode blendMode)
        {
            switch (blendMode)
            {
                case BlendMode.Opaque:
                    material.SetOverrideTag("RenderType", "");
                    material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                    material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.Zero);
                    material.SetInt("_ZWrite", 1);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                    break;
                case BlendMode.Cutout:
                    material.SetOverrideTag("RenderType", "TransparentCutout");
                    material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                    material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.Zero);
                    material.SetInt("_ZTest", (int)UnityEngine.Rendering.CompareFunction.LessEqual);
                    material.SetInt("_ZWrite", 1);

                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                    break;
                case BlendMode.AlphaBlend:
                    material.SetOverrideTag("RenderType", "Transparent");
                    material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                    material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                    material.SetInt("_ZWrite", 0);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.EnableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                    break;
                case BlendMode.Transparent:
                    material.SetOverrideTag("RenderType", "Transparent");
                    material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                    material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                    material.SetInt("_ZWrite", 0);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.EnableKeyword("_ALPHAPREMULTIPLY_ON");
                    break;
                case BlendMode.Add:
                    material.SetOverrideTag("RenderType", "Transparent");
                    material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                    material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.One);
                    material.SetInt("_ZWrite", 0);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                    break;
                case BlendMode.MultiAlphaAdd:
                    material.SetOverrideTag("RenderType", "Transparent");
                    material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                    material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.One);
                    material.SetInt("_ZWrite", 0);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                    break;
            }
        }
        public void ShaderPropertiesGUI(Material material, MaterialProperty[] props)
        {
            m_ProcessedProperties = new HashSet<string>();
            if (m_ForceFixAllMode)
                m_FixAllMode = true;

            // Use default labelWidth
            EditorGUIUtility.labelWidth = 0f;

            // Detect any changes to the material
            EditorGUI.BeginChangeCheck();

            DrawHeaders();
            bool needFix = DrawManagedProperties(material, props);

            EditorGUILayout.Space();
            EditorGUILayout.Space();

            for (var i = 0; i < props.Length; i++)
            {
                var prop = props[i];
                if (m_ProcessedProperties.Contains(prop.name))
                    continue;
                if ((prop.flags & (MaterialProperty.PropFlags.HideInInspector | MaterialProperty.PropFlags.PerRendererData)) != 0)
                    continue;

                if (prop.type == MaterialProperty.PropType.Texture)
                {
                    bool isCustom = false;
                    var format = new RequestedMapFormat();
                    format.sRGB = false;
                    format.needTilingOffset = defaultDrawTilingOffset;
                    format.allowAniso = true;
                    format.preserveCoverage = false;
                    format.cutoutAlpha = 0.5f;
                    format.boostCoverage = 0;
                    {
                        EditorGUILayout.Space();
                        if ((prop.flags & MaterialProperty.PropFlags.Gamma) != 0)
                            format.sRGB = true;
                        if ((prop.flags & MaterialProperty.PropFlags.NoScaleOffset) != 0)
                            format.needTilingOffset = false;
                        if (prop.textureDimension == UnityEngine.Rendering.TextureDimension.Cube)
                        {
                            format.sRGB = true;
                            format.needTilingOffset = false;
                        }

                        string[] attribs = ShaderUtil.GetShaderPropertyAttributes(material.shader, prop.name);
                        if (attribs != null)
                        {
                            foreach (var attrib in attribs)
                            {
                                if (attrib == "PackNormalGlossiness")
                                    format.mipMode = TextureImporterMipFilter.NormalGlossiness;
                                else if (attrib == "PackNormalRoughness")
                                    format.mipMode = TextureImporterMipFilter.NormalRoughness;
                                else if (attrib == "PackNormalX")
                                    format.mipMode = TextureImporterMipFilter.NormalX;
                                else if (attrib == "NeedAlpha")
                                    format.needAlpha = true;
                                else if (attrib == "ScaleOffset")
                                    format.needTilingOffset = true;
                                else if (attrib == "Custom")
                                    isCustom = true;
                                else if (attrib == "AllowAlpha")
                                    format.allowAlpha = true;
                                else if (attrib == "NoMipmap")
                                    format.enableMipMap = false;
                            }
                        }

                        m_MaterialEditor.TexturePropertySingleLine(new GUIContent(prop.displayName), prop);

                        if (!isCustom)
                        {
                            if (FixTexture(prop.textureValue, format, m_PreviewMode, m_FixAllMode))
                                needFix = true;
                        }
                        if (format.needTilingOffset)
                        {
                            EditorGUI.BeginChangeCheck();

                            Vector2 tiling = new Vector2(prop.textureScaleAndOffset.x, prop.textureScaleAndOffset.y);
                            Vector2 offset = new Vector2(prop.textureScaleAndOffset.z, prop.textureScaleAndOffset.w);

                            EditorGUILayout.BeginHorizontal();

                            EditorGUILayout.LabelField("Tiling", GUILayout.Width(45));
                            tiling = EditorGUILayout.Vector2Field(GUIContent.none, tiling, GUILayout.Width(100));
                            EditorGUILayout.LabelField("Offset", GUILayout.Width(45));
                            offset = EditorGUILayout.Vector2Field(GUIContent.none, offset, GUILayout.Width(100));

                            EditorGUILayout.EndHorizontal();

                            if (EditorGUI.EndChangeCheck())
                                prop.textureScaleAndOffset = new Vector4(tiling.x, tiling.y, offset.x, offset.y);
                        }
                        EditorGUILayout.Space();
                        DrawTextureSimpleInfo(prop.textureValue, prop.ToString());
                    }
                }
                else
                {
                    float h = m_MaterialEditor.GetPropertyHeight(prop, prop.displayName);
                    Rect r = EditorGUILayout.GetControlRect(true, h, EditorStyles.layerMaskField);

                    m_MaterialEditor.ShaderProperty(r, prop, prop.displayName);
                }
            }
            m_ProcessedProperties = null;

            // Third properties
            //GUILayout.Label(Styles.forwardText, EditorStyles.boldLabel);
            //if (highlights != null)
            //    m_MaterialEditor.ShaderProperty(highlights, Styles.highlightsText);
            //if (reflections != null)
            //    m_MaterialEditor.ShaderProperty(reflections, Styles.reflectionsText);
            //if(simpleDynamicSpecIBL!=null)
            //    m_MaterialEditor.ShaderProperty(simpleDynamicSpecIBL, Styles.simpleDynmIBLspecText);

            if (EditorGUI.EndChangeCheck())
            {
                OnMaterialChanged(material);
            }

            EditorGUILayout.Space();

            m_FixAllMode = false;
            m_PreviewMode = false;
            if (needFix)
            {
                GUI.color = Color.magenta;
                if (GUILayout.Button("Fix All Textures!!!"))
                {
                    m_FixAllMode = true;
                }
                GUI.color = Color.white;
            }
            else
            {
                if (GUILayout.Button("Preview Android Texture"))
                {
                    m_FixAllMode = true;
                    m_PreviewMode = true;
                }
            }

            EditorGUILayout.Space();

            GUILayout.Label("Advanced Options", EditorStyles.boldLabel);
            
            // _CustomRenderQueue是shader属性m_SavedProperties。 m_CustomRenderQueue是材质属性。这两个值是不一样的。
            // material.renderQueue返回的是m_CustomRenderQueue。如果为-1，则返回shader.renderQueue （这个值是写死在shader中的，不可设置，一般是2000）。
            // _CustomRenderQueue的目的是当设置了特殊的renderQueue的时候，不会被SubMode的设置覆盖为默认renderQueue。如果期望恢复默认设置，需要选择From Shader选项。
            // 即，现在的逻辑就是，如果指定了renderQueue，则_CustomRenderQueue修改为对应的值，m_CustomRenderQueue也会被同步设置。
            // 如果没有指定renderQueue，则_CustomRenderQueue为-1，m_CustomRenderQueue为根据SubMode设置的默认值。
            // 如果_CustomRenderQueue为-1，则Popup选项显示为From Shader，Input显示的值是m_CustomRenderQueue（实际的renderQueue）。
            var customRenderQueue = FindProperty("_CustomRenderQueue", props, false);
            if (customRenderQueue != null)
            {
                int customRenderQueueValue = (int) customRenderQueue.floatValue;
                // 如果_CustomRenderQueue值为-1，那么编辑器Popup永远显示From Shader。输入框中显示真正的queue值（m_CustomRenderQueue）。
                bool hasChanged = m_MaterialEditor.RenderQueueField(customRenderQueueValue == -1);
                
                // 有指定renderQueue，同步更新_CustomRenderQueue。如果选了From Shader，则_CustomRenderQueue会被更新为-1。
                // m_CustomRenderQueue会在后续的OnMaterialChanged修改为根据SubMode设置的值。
                if (hasChanged)
                {
                    // 此处应该使用m_CustomRenderQueue的值，不能直接用material.renderQueue，当m_CustomRenderQueue==-1时，material.renderQueue会返回shader.renderQueue==2000。
                    customRenderQueue.floatValue = ShaderUtil.GetMaterialRawRenderQueue(material);
                    OnMaterialChanged(material);
                }
            }
            else
            {
                m_MaterialEditor.RenderQueueField();
            }

            m_MaterialEditor.EnableInstancingField();
            m_MaterialEditor.DoubleSidedGIField();
        }

        public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
        {
            FindProperties(props); // MaterialProperties can be animated so we do not cache them but fetch them every event to ensure animated values are updated correctly

            m_MaterialEditor = materialEditor;
            Material material = materialEditor.target as Material;

            // Make sure that needed setup (ie keywords/renderqueue) are set up if we're switching some existing
            // material to a standard shader.
            // Do this before any GUI code has been issued to prevent layout issues in subsequent GUILayout statements (case 780071)
            if (m_FirstTimeApply)
            {
                DoFirstTimeApply(material, props);
                m_FirstTimeApply = false;
            }

            ShaderPropertiesGUI(material, props);

            EditorGUILayout.BeginHorizontal();
            testShaderLod = EditorGUILayout.IntField("Set Global Lod", testShaderLod);
            if (GUILayout.Button("Set global Shader LOD"))
            {
                if (Shader.globalMaximumLOD != testShaderLod)
                {
                    Shader.globalMaximumLOD = testShaderLod;
#if !TIMIJ3_UNITY_CP_EDITOR
                    GameEngine.AssetManager.ReCreateAllShaders();
#endif
                }
            }
            EditorGUILayout.EndHorizontal();

            showAllProperties = EditorGUILayout.Toggle("Show All Properties", showAllProperties);
            m_ForceFixAllMode = EditorGUILayout.Toggle("Force Fix All Mode", m_ForceFixAllMode);

            ShowShaderKeywords(material);
        }
        bool shaderKeywordsFoldout = true;
        void ShowShaderKeywords(Material material)
        {
            shaderKeywordsFoldout = EditorGUILayout.Foldout(shaderKeywordsFoldout, "Shader Keywords");
            if (shaderKeywordsFoldout)
            {
                EditorGUI.indentLevel++;
                foreach (var keyword in material.shaderKeywords)
                {
                    EditorGUILayout.LabelField(keyword);
                }
                EditorGUI.indentLevel--;
            }
        }

        public static void Create4colorPBRshaderUniform(Vector4 col0Pbr,    // roughness / roughness blend / metallic
                                                        Vector4 col1Pbr,
                                                        Vector4 col2Pbr,
                                                        Vector4 col3Pbr,
                                                        bool shouldSwitchColor01,
                                                        bool shouldSwitchColor23,
                                                        Color col0Albedo,
                                                        Color col2Albedo,
                                                        ref MaterialProperty shaderUniform_4ColColor0,
                                                        ref MaterialProperty shaderUniform_4ColColor1,

                                                        ref MaterialProperty shaderUniform_4colSwitch,

                                                        ref MaterialProperty shaderUniform_4colPbr0,
                                                        ref MaterialProperty shaderUniform_4colPbr1,
                                                        ref MaterialProperty shaderUniform_4colPbr2,
                                                        ref MaterialProperty shaderUniform_4colPbr3
            )
        {

        }

        public static void CreateCamouflageColorCombinationShaderUniform(Color col0, Color col1, Color col2, Color col3, ref Vector4  unirform0, ref Vector4 unirform1, ref Vector4 unirform2)
        {
            // setup:
            // unirform0 : xyz [ col1.rgb ]            w [col3.r - col2.r]
            // unirform1 : xyz [ col0.rgb - col1.rgb ] w [col3.g - col2.g]
            // unirform2 : xyz [ col2.rgb - col1.rgb ] w [col3.b - col2.b]

            col0 = col0.linear;
            col1 = col1.linear;
            col2 = col2.linear;
            col3 = col3.linear;

            unirform0.Set(col1.r,          col1.g,          col1.b,          col3.r - col2.r);
            unirform1.Set(col0.r - col1.r, col0.g - col1.g, col0.b - col1.b, col3.g - col2.g);
            unirform2.Set(col2.r - col1.r, col2.g - col1.g, col2.b - col1.b, col3.b - col2.b);
        }

        public static void ShaderUniformToCamouflageColor(Vector4 unirform0,  Vector4 unirform1,  Vector4 unirform2, ref Color col0, ref Color col1, ref Color col2, ref Color col3)
        {

            col1.r = unirform0.x;
            col1.g = unirform0.y;
            col1.b = unirform0.z;
            col1.a = 1.0f;

            col0.r = col1.r + unirform1.x;
            col0.g = col1.g + unirform1.y;
            col0.b = col1.b + unirform1.z;
            col0.a = 1.0f;

            col2.r = col1.r + unirform2.x;
            col2.g = col1.g + unirform2.y;
            col2.b = col1.b + unirform2.z;
            col2.a = 1.0f;

            col3.r = col2.r + unirform0.w;
            col3.g = col2.g + unirform1.w;
            col3.b = col2.b + unirform2.w;
            col3.a = 1.0f;

            col0 = col0.gamma;
            col1 = col1.gamma;
            col2 = col2.gamma;
            col3 = col3.gamma;
        }

        #region Texture Tools
        public static long GetStorageSize(System.Object obj)
        {
            Texture target = obj as Texture;
            return target == null ? 0 : UnityEditor.TextureUtil.GetStorageMemorySizeLong(target);
        }

        protected static bool m_Toolbox = false;
        protected void DrawTextureSimpleInfo(Texture tex, string header)
        {
            return;
            if (tex == null) return;
#if !TIMIJ3_UNITY_CP_EDITOR
            EditorGUI.BeginChangeCheck();
            if (NGUIEditorTools.DrawHeader(header) && tex != null)
            {
                NGUIEditorTools.BeginContents();
                DrawTextureSimpleInfo(tex);
                NGUIEditorTools.EndContents();
            }
            EditorGUI.EndChangeCheck();
#endif
        }
        protected void DrawTextureSimpleInfo(Texture tex)
        {
            return;
            TextureImporter textureImporter =
                AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(tex)) as TextureImporter;
            if (textureImporter == null) return;

            //EditorGUILayout.LabelField(TextureInspectorHelp.GetInfoString(tex));
            EditorGUILayout.LabelField("Tex size", string.Format("({0}, {1})", tex.width, tex.height));
            {
                // init
                //if (AppleFormat == null) AppleFormat = TextureImportPlatformSettings.kTextureFormatsValueApplePVR;
                //if (AppleFormatString == null)
                //{
                //    AppleFormatString = CBuildTextureStrings(TextureImportPlatformSettings.kTextureFormatsValueApplePVR);
                //    for (int i = 0; i < AppleFormatString.Length; i++)
                //    {
                //        AppleFormatString[i] = AppleFormatString[i].Trim();
                //    }
                //}
                //if (AndroidFormat == null) AndroidFormat = TextureImportPlatformSettings.kTextureFormatsValueAndroid;
                //if (AndroidFormatString == null)
                //{
                //    AndroidFormatString = CBuildTextureStrings(TextureImportPlatformSettings.kTextureFormatsValueAndroid);
                //    for (int i = 0; i < AndroidFormatString.Length; i++)
                //    {
                //        AndroidFormatString[i] = AndroidFormatString[i].Trim();
                //    }
                //}
            }
            TextureImporterFormat fmApple = textureImporter.GetPlatformTextureSettings("iPhone").format;
            EditorGUILayout.LabelField("Format(Apple)", GetStrByValue((int)fmApple, AppleFormatString, AppleFormat));
            //EditorGUI.BeginChangeCheck();
            //fm = (TextureImporterFormat)EditorGUILayout.IntPopup(new GUIContent("Format(Apple)"), (int)fm, ConvertContent(AppleFormatString), AppleFormat);
            //if (EditorGUI.EndChangeCheck())
            //{
            //    textureImporter.GetPlatformTextureSettings("iPhone").format = fm;
            //}

            TextureImporterFormat fmAndroid = textureImporter.GetPlatformTextureSettings("Android").format;
            EditorGUILayout.LabelField("Format(Android)", GetStrByValue((int)fmAndroid, AndroidFormatString, AndroidFormat));
            //EditorGUI.BeginChangeCheck();
            //fm = (TextureImporterFormat)EditorGUILayout.IntPopup(new GUIContent("Format(Android)"), (int)fm, ConvertContent(AndroidFormatString), AndroidFormat);
            //EditorGUI.BeginChangeCheck();
            //if (EditorGUI.EndChangeCheck())
            //{
            //    textureImporter.GetPlatformTextureSettings("Android").format = fm;
            //}

            //EditorGUILayout.LabelField("mipmapEnabled", textureImporter.mipmapEnabled.ToString());
            EditorGUILayout.LabelField("sRGBTexture", textureImporter.sRGBTexture.ToString());
            //EditorGUILayout.LabelField("textureType", textureImporter.textureType.ToString());
            EditorGUILayout.LabelField("Runtime Size", string.Format("{0:n0} kbyte", Profiler.GetRuntimeMemorySizeLong(tex) / (double)1024));
            EditorGUILayout.LabelField("Storage Size", string.Format("{0:n0} kbyte", GetStorageSize(tex) / (double)1024));
        }


        public static string[] CBuildTextureStrings(int[] texFormatValues)
        {
            string[] retval = new string[texFormatValues.Length];
            for (int i = 0; i < texFormatValues.Length; i++)
            {
                int val = texFormatValues[i];
                retval[i] = " " + TextureUtil.GetTextureFormatString((TextureFormat)val);
            }
            return retval;
        }

        protected static int[] AppleFormat = null;
        protected static string[] AppleFormatString = null;

        protected static int[] AndroidFormat = null;
        protected static string[] AndroidFormatString = null;

        protected string GetStrByValue(int value, string[] strArray, int[] valueArray)
        {
            int id = -1;
            for (int i = 0; i < valueArray.Length; i++)
            {
                if (valueArray[i] == value)
                {
                    id = i;
                    break;
                }
            }
            return (id > 0 && id < strArray.Length) ? strArray[id] : "";
        }

        public static readonly List<TextureImporterFormat> FormatAndroidAlpha = new List<TextureImporterFormat>()
        {
            TextureImporterFormat.ETC2_RGBA8,
            TextureImporterFormat.RGBA16,
            TextureImporterFormat.RGBA32,
        };

        public static readonly List<TextureImporterFormat> FormatAndroidNoAlpha = new List<TextureImporterFormat>()
        {
            TextureImporterFormat.ETC_RGB4,
            TextureImporterFormat.RGB16,
            TextureImporterFormat.RGB24,
        };

        public static readonly List<TextureImporterFormat> FormatIosAlpha = new List<TextureImporterFormat>()
        {
            TextureImporterFormat.ASTC_RGBA_6x6,
            TextureImporterFormat.ASTC_RGBA_6x6,
            TextureImporterFormat.ASTC_RGBA_4x4,
        };

        public static readonly List<TextureImporterFormat> FormatIosNoAlpha = new List<TextureImporterFormat>()
        {
            TextureImporterFormat.ASTC_RGB_6x6,
            TextureImporterFormat.ASTC_RGB_6x6,
            TextureImporterFormat.ASTC_RGB_4x4,
        };

        public static readonly List<TextureImporterFormat> FormatStandaloneAlpha = new List<TextureImporterFormat>()
        {
            TextureImporterFormat.DXT5,
            TextureImporterFormat.RGBA16,
            TextureImporterFormat.RGBA32,
        };

        public static readonly List<TextureImporterFormat> FormatStandaloneNoAlpha = new List<TextureImporterFormat>()
        {
            TextureImporterFormat.DXT1,
            TextureImporterFormat.RGB16,
            TextureImporterFormat.RGB24,
        };

        public static int GetQualityFromFormat(TextureImporterFormat fmt)
        {
#if !TIMIJ3_UNITY_CP_EDITOR
            return AssetImportProcessor.GetCompressQuality(fmt);
#else
            return 50;
#endif
        }

        protected class RequestedMapFormat
        {
            public bool sRGB = true;
            public bool needTilingOffset = false;
            public bool enableMipMap = true;
            public TextureImporterMipFilter mipMode = TextureImporterMipFilter.BoxFilter;
            public bool needAlpha = false;
            public bool allowAlpha = false;
            public bool allowAniso = false;
            public bool preserveCoverage = false;
            public float cutoutAlpha = 0.5f;
            public float boostCoverage = 0;
        }

        enum TextureSize
        {
            Size1,
            Size2,
            Size4,
            Size8,
            Size16,
            Size32,
            Size64,
            Size128,
            Size256,
            Size512,
            Size1024,
            Size2048,
            Size4096,
        }

        public enum TextureCompression
        {
            Compressed,     // 压缩纹理。绝大多数模型的材质都是这个。
            Force16,        // 16位
            Force24_32,     // 真彩色，按现在的逻辑，选择这个下拉框就会显示Mixed。
            Mixed,          // 不能被设置，选择Force24_32就会显示为Mixed标签。Android下是RGB24，iOS下是astc6x6。
        }

        enum TextureAniso
        {
            None,
            Low_2,
            Ground_4,
            High_6,
            Other
        }

        public bool ForceAlpha(string path)
        {
            var lowerPath = path.ToLowerInvariant();
            if (lowerPath.Contains("_trans."))
            {
                return true;
            }
            return false;
        }
        protected bool FixTexture(Texture tex, RequestedMapFormat format)
        {
            return FixTexture(tex, format, m_PreviewMode, m_FixAllMode);
        }

        protected bool FixTexture(Texture tex, RequestedMapFormat format, bool usePreviewMode, bool fixAllMode)
        {
            format.allowAniso = true;

            if (!tex) return false;
            var assetPath = AssetDatabase.GetAssetPath(tex);
            var texImport = AssetImporter.GetAtPath(assetPath) as TextureImporter;
            if (!texImport) return false;

            bool hasAny = false;
            bool fixedAny = false;

            var defaultFormat = texImport.GetDefaultPlatformTextureSettings();

            var standaloneFormat = texImport.GetStandaloneFormat();
            bool forceAlpha = ForceAlpha(assetPath);
            if (format.allowAlpha && FormatStandaloneAlpha.Contains(standaloneFormat.format))
                forceAlpha = true;

            var standalone = format.needAlpha || forceAlpha ? FormatStandaloneAlpha : FormatStandaloneNoAlpha;

            var android = format.needAlpha || forceAlpha ? FormatAndroidAlpha : FormatAndroidNoAlpha;
            var androidFormat = texImport.GetAndroidFormat();

            var ios = format.needAlpha || forceAlpha ? FormatIosAlpha : FormatIosNoAlpha;
            var iosFormat = texImport.GetAppleFormat();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(string.Format("Size {0}x{1}  (File {2:n0}k)", tex.width, tex.height, TextureUtil.GetStorageMemorySizeLong(tex) / (double)1024));

            // 设置图片尺寸
            var maxTextureSize = defaultFormat.maxTextureSize;
            int sizei = 0;
            while (maxTextureSize > 1)
            {
                sizei++;
                maxTextureSize = maxTextureSize >> 1;
            }
            TextureSize size = (TextureSize)sizei;
            TextureSize newSize = (TextureSize)EditorGUILayout.EnumPopup(size);
            if (size != newSize)
            {
                fixedAny = true;
                defaultFormat.maxTextureSize = 1 << (int)newSize;
                texImport.SetPlatformTextureSettings(defaultFormat);

                androidFormat.maxTextureSize = defaultFormat.maxTextureSize;
                iosFormat.maxTextureSize = defaultFormat.maxTextureSize;
                standaloneFormat.maxTextureSize = defaultFormat.maxTextureSize;
                texImport.SetPlatformTextureSettings(androidFormat);
                texImport.SetPlatformTextureSettings(iosFormat);
                texImport.SetPlatformTextureSettings(standaloneFormat);
            }

            // 设置压缩纹理格式
            var compression = TextureCompression.Mixed;
            if (androidFormat.format == android[0] && iosFormat.format == ios[0])
                compression = TextureCompression.Compressed;
            if (androidFormat.format == android[1] && iosFormat.format == ios[1])
                compression = TextureCompression.Force16;
            if (androidFormat.format == android[2] && iosFormat.format == ios[2])
                compression = TextureCompression.Force24_32;
            var newCompression = (TextureCompression)EditorGUILayout.EnumPopup(compression);
            if (newCompression != compression && newCompression != TextureCompression.Mixed)
            {
                switch (newCompression)
                {
                    case TextureCompression.Compressed:
                        androidFormat.format = android[0];
                        iosFormat.format = ios[0];
                        standaloneFormat.format = standalone[0];
                        break;
                    case TextureCompression.Force16:
                        androidFormat.format = android[1];
                        iosFormat.format = ios[1];
                        standaloneFormat.format = standalone[1];
                        break;
                    case TextureCompression.Force24_32:
                        androidFormat.format = android[2];
                        // 这里用的是astc6x6，估计是对模型和地表而言，6x6质量已经够用了。UI才需要4x4
                        iosFormat.format = ios[1];
                        standaloneFormat.format = standalone[2];
                        break;
                }
                fixedAny = true;
                texImport.SetPlatformTextureSettings(androidFormat);
                texImport.SetPlatformTextureSettings(iosFormat);
                texImport.SetPlatformTextureSettings(standaloneFormat);
            }

            // 设置各向异性。长条地表可能需要设置，否则采样效果比较糟糕。
            if (format.allowAniso)
            {
                var aniso = TextureAniso.Other;
                switch (texImport.anisoLevel)
                {
                    case -1:
                    case 0:
                    case 1:
                        aniso = TextureAniso.None;
                        break;
                    case 2:
                        aniso = TextureAniso.Low_2;
                        break;
                    case 4:
                        aniso = TextureAniso.Ground_4;
                        break;
                    case 6:
                        aniso = TextureAniso.High_6;
                        break;
                    default:
                        aniso = TextureAniso.Other;
                        break;
                }
                var newAniso = (TextureAniso)EditorGUILayout.EnumPopup(aniso);
                if (newAniso != aniso)
                {
                    switch (newAniso)
                    {
                        case TextureAniso.None:
                            texImport.anisoLevel = -1;
                            fixedAny = true;
                            break;
                        case TextureAniso.Low_2:
                            texImport.anisoLevel = 2;
                            fixedAny = true;
                            break;
                        case TextureAniso.Ground_4:
                            texImport.anisoLevel = 4;
                            fixedAny = true;
                            break;
                        case TextureAniso.High_6:
                            texImport.anisoLevel = 6;
                            fixedAny = true;
                            break;
                    }
                }
            }

            EditorGUILayout.EndHorizontal();

            // pbr材质的纹理格式受材质决定。都会有这么一个标签。
            string targetUserData = "EnableCustomFormatSetting";
            bool fixUserdata = !texImport.userData.Contains(targetUserData);
            if (fixUserdata)
            {
                hasAny = true;
                if (fixAllMode || FixButton("No Custom Setting!"))
                {
                    fixedAny = true;
                    texImport.userData += targetUserData;
                }
            }

            bool fixTextureType = texImport.textureType != TextureImporterType.Default;
            if (fixTextureType)
            {
                hasAny = true;
                if (fixAllMode || FixButton("Texture Type Wrong", false))
                {
                    fixedAny = true;
                    texImport.textureType = TextureImporterType.Default;
                }
            }

            if (tex.dimension == UnityEngine.Rendering.TextureDimension.Cube)
            {
                TextureImporterSettings importSettings = new TextureImporterSettings();
                texImport.ReadTextureSettings(importSettings);
                bool fixConvolutionType = importSettings.cubemapConvolution != TextureImporterCubemapConvolution.Specular;
                if (fixConvolutionType)
                {
                    hasAny = true;
                    if (fixAllMode || FixButton("Cubemap Convolution Type Wrong", true))
                    {
                        fixedAny = true;
                        importSettings.cubemapConvolution = TextureImporterCubemapConvolution.Specular;
                        texImport.SetTextureSettings(importSettings);
                    }
                }
            }

            if (!format.allowAniso)
            {
                bool fixaniso = texImport.anisoLevel > 1;
                if (fixaniso)
                {
                    hasAny = true;
                    if (fixAllMode || FixButton("Aniso Wrong", true))
                    {
                        fixedAny = true;
                        texImport.anisoLevel = -1;
                    }
                }
            }

            bool fixsrgb = texImport.sRGBTexture != format.sRGB;
            if (fixsrgb)
            {
                hasAny = true;
                if (fixAllMode || FixButton("sRGB Wrong", false))
                {
                    fixedAny = true;
                    texImport.sRGBTexture = format.sRGB;
                }
            }

            bool fixMip = !texImport.mipmapEnabled;
            if (fixMip && !texImport.assetPath.ToLowerInvariant().Contains("_1p.") && format.enableMipMap)
            {
                hasAny = true;
                if (fixAllMode || FixButton("Mipmap not enabled"))
                {
                    fixedAny = true;
                    texImport.mipmapEnabled = true;
                }
            }

            bool fixMipMode = texImport.mipmapFilter != format.mipMode;
            if (fixMipMode)
            {
                hasAny = true;
                if (fixAllMode || FixButton("Mipmap Mode Error"))
                {
                    fixedAny = true;
                    texImport.mipmapFilter = format.mipMode;
                }
            }

            bool fixTrilinear = texImport.filterMode != FilterMode.Trilinear;
            if (fixTrilinear)
            {
                hasAny = true;
                if (fixAllMode || FixButton("Filter Mode not Trilinear Error"))
                {
                    fixedAny = true;
                    texImport.filterMode = FilterMode.Trilinear;
                }
            }

            bool fixPreserveCoverage = texImport.mipMapsPreserveCoverage != format.preserveCoverage;
            if (fixPreserveCoverage)
            {
                hasAny = true;
                if (fixAllMode || FixButton("Fix Preserve Coverage"))
                {
                    fixedAny = true;
                    texImport.mipMapsPreserveCoverage = format.preserveCoverage;
                }
            }
            if (format.preserveCoverage)
            {
                bool fixCutoutAlpha = texImport.alphaTestReferenceValue != format.cutoutAlpha;
                if (fixCutoutAlpha)
                {
                    hasAny = true;
                    if (fixAllMode || FixButton("Fix cutout reference"))
                    {
                        fixedAny = true;
                        texImport.alphaTestReferenceValue = format.cutoutAlpha;
                    }
                }

                bool fixBoostCoverage = texImport.alphaTestCoverageBoostInMip != format.boostCoverage;
                if (fixBoostCoverage)
                {
                    hasAny = true;
                    if (fixAllMode || FixButton("Fix Coverage Boost"))
                    {
                        fixedAny = true;
                        texImport.alphaTestCoverageBoostInMip = format.boostCoverage;
                    }
                }

            }

            // 某个平台设置的图片格式不在列表中，则认为是非法格式，修正为压缩纹理格式。
            bool fixAndroid = !androidFormat.overridden
                || !android.Contains(androidFormat.format)
                || androidFormat.maxTextureSize != defaultFormat.maxTextureSize;
            if (fixAndroid)
            {
                hasAny = true;
                if (fixAllMode || FixButton("Android format error", format.needAlpha))
                {
                    fixedAny = true;
                    androidFormat.overridden = true;
                    androidFormat.compressionQuality = GetQualityFromFormat(android[0]);
                    androidFormat.format = android[0];
                    androidFormat.maxTextureSize = defaultFormat.maxTextureSize;
                    texImport.SetPlatformTextureSettings(androidFormat);
                }
            }
            bool fixIos = !iosFormat.overridden
                || !ios.Contains(iosFormat.format)
                || iosFormat.maxTextureSize != defaultFormat.maxTextureSize;
            if (fixIos)
            {
                hasAny = true;
                if (fixAllMode || FixButton("iOS format error", format.needAlpha))
                {
                    fixedAny = true;
                    iosFormat.overridden = true;
                    iosFormat.compressionQuality = GetQualityFromFormat(ios[0]);
                    iosFormat.format = ios[0];
                    iosFormat.maxTextureSize = defaultFormat.maxTextureSize;
                    texImport.SetPlatformTextureSettings(iosFormat);
                }
            }

            if (usePreviewMode)
                standalone = android;

            bool standaloneFormatGood = standalone.Contains(standaloneFormat.format);
            if (usePreviewMode)
                standaloneFormatGood = androidFormat.format == standaloneFormat.format;

            bool fixStandalone = !standaloneFormat.overridden
                || !standaloneFormatGood
                || standaloneFormat.maxTextureSize != defaultFormat.maxTextureSize;
            if (fixStandalone)
            {
                hasAny = true;
                if (fixAllMode || FixButton("Standalone format error", false))
                {
                    fixedAny = true;
                    standaloneFormat.overridden = true;
                    standaloneFormat.compressionQuality = GetQualityFromFormat(standalone[0]);
                    if (usePreviewMode)
                        standaloneFormat.format = androidFormat.format;
                    else
                        standaloneFormat.format = standalone[0];
                    standaloneFormat.maxTextureSize = defaultFormat.maxTextureSize;
                    texImport.SetPlatformTextureSettings(standaloneFormat);
                }
            }



            if (fixedAny)
            {
                texImport.SaveAndReimport();
            }

            GUI.color = Color.magenta;
            if (!fixAllMode && hasAny && GUILayout.Button("Fix All"))
            {
                FixTexture(tex, format, usePreviewMode, true);
            }
            GUI.color = Color.white;

            return hasAny;
        }

        protected bool FixButton(string hint, bool isError = true)
        {
            if (isError)
                GUI.color = Color.red;
            else
                GUI.color = Color.yellow;
            if (m_MaterialEditor)
            {
                var r = m_MaterialEditor.HelpBoxWithButton(new GUIContent(hint), new GUIContent("Fix"));
                return r;
            }
            GUI.color = Color.white;
            return false;
        }

        #endregion
#endif
    }
} // namespace UnityEditor
