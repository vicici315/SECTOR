﻿// Unity built-in shader source. Copyright (c) 2016 Unity Technologies. MIT license (see license.txt)

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Profiling;

namespace UnityEditor
{
    internal class LobbyHairGUI : ShaderGUI
    {
#if USE_CUSTOM_UNITY
        protected MaterialEditor m_MaterialEditor;
        
        public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
        {
            m_MaterialEditor = materialEditor;
            Material material = materialEditor.target as Material;

            base.OnGUI(materialEditor, props);

            if (material.name.ToLower().Contains("_3p") || material.name.ToLower().Contains("_br") )
            {
                material.renderQueue = -1;
            }
            else
            {
                material.renderQueue = -1;
            }

        }
        
#endif
    }
} // namespace UnityEditor
