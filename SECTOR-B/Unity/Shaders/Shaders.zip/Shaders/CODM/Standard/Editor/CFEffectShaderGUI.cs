﻿// Unity built-in shader source. Copyright (c) 2016 Unity Technologies. MIT license (see license.txt)

using System;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Rendering;

namespace UnityEditor
{
    internal class CFEffectShaderGUI : CFShaderGUIBase
    {
#if USE_CUSTOM_UNITY


        public enum EffectType  //main mode
        {
            Flow1,      // 
            Flow2,
            Material,
        }

        public enum ChannelType
        {
            R,
            RG,
            RGB,
            ColorMap,
        }

        public enum SubMode
        {
            FlowMap = 0,
            RidescenceClearCoat = 1
        }

        public enum MaskMode
        {
            SingelGradientChannel = 0,
            DualGradientChannels = 1,
            MaterialIDMode = 2
        }

        public enum UvMode
        {
            Uv0 = 0,
            LocalSpaceProjection = 1,
            Uv1 = 2
        }

        public enum PlanarProjectMode
        {
            XY = 0,
            XZ = 1,
            YZ = 2,
            //Custom = 3
        }

        //一张flowmap + 闪烁
        public enum Flow1Type
        {
            NoEffect,
            Breath,
            Flake,
            HSV,
            Ramp,
            Flipbook
        }

        //两张flowmap，不同方式结合
        public enum Flow2Type
        {
            AlphaCover = -1,
            Add = 0,
            Mul = 1,
            Distort = 2,
            Parrallax = 3,
        }

        //特殊材质效果，比如冰，玉
        public enum MaterialType
        {
            Ice,
        }


        //小模块，最小粒度
        struct EffectConfig
        {
            public bool isFlake;
            public bool isBreath;
            public bool isHSV;
            public bool isRamp;
            public bool isFlippbook;

            public bool isDistort;
            public bool isParallax;
            public bool isAlphaCover;
            public bool isAdd;
            public bool isMul;
        }
        
        class Flow1TypeComparer : IEqualityComparer<Flow1Type>
        {
            public bool Equals(Flow1Type x, Flow1Type y) { return x == y; }
            public int GetHashCode(Flow1Type obj) { return (int)obj; }
        }
        
        class Flow2TypeComparer : IEqualityComparer<Flow2Type>
        {
            public bool Equals(Flow2Type x, Flow2Type y) { return x == y; }
            public int GetHashCode(Flow2Type obj) { return (int)obj; }
        }
       
        static Dictionary<string, EffectType> EffectTypeDict; //shader 粒度的效果
        static Dictionary<Flow1Type, EffectConfig> Flow1Config;
        static Dictionary<Flow2Type, EffectConfig> Flow2Config;
        static Dictionary<Flow2Type, EffectConfig> MaterialConfig;

        //每个shader的可行组合。
        public static readonly string[] flow1Options = Enum.GetNames(typeof(Flow1Type));
        public static readonly string[] flow2Options = Enum.GetNames(typeof(Flow2Type));
        public static readonly string[] materialOptions = Enum.GetNames(typeof(MaterialType));
        public static readonly string[] channelOptions = Enum.GetNames(typeof(ChannelType));

        public const string Weapon_Flowmap1 = "Special Weapon/Flowmap1";
        public const string Weapon_Flowmap2 = "Special Weapon/Flowmap2";
        //public const string Weapon_NewFlowmap1 = "Special Weapon/NewFlowmap1";
        //public const string Weapon_NewFlowmap2 = "Special Weapon/NewFlowmap2";
        public const string Weapon_Material = "Special Weapon/Material";


        public const string Flake0EfxKeyword = "EFX_FLAKE_0";
        public const string Flake1EfxKeyword = "EFX_FLAKE_1";
        public const string HSV0Keyword = "EFX_HSV_0";
        public const string HSV1Keyword = "EFX_HSV_1";
        public const string Flipbook0Keyword = "EFX_FLIPBOOK_0";
        public const string Flipbook1Keyword = "EFX_FLIPBOOK_1";

        public static void InitConfig()
        {
            if (EffectTypeDict != null)
                return;
            EffectTypeDict = new Dictionary<string, EffectType>()
            {
                {Weapon_Flowmap1,               EffectType.Flow1},
                {Weapon_Flowmap2,               EffectType.Flow2},
                {Weapon_Material,               EffectType.Material},
            };
            Flow1Config = new Dictionary<Flow1Type, EffectConfig>(new Flow1TypeComparer())
            {

                {Flow1Type.NoEffect, new EffectConfig               {  }},
                {Flow1Type.Breath, new EffectConfig                 { isBreath = true }},
                {Flow1Type.Flake, new EffectConfig                  { isFlake = true }},
                {Flow1Type.HSV, new EffectConfig                    { isHSV = true }},
                {Flow1Type.Ramp, new EffectConfig                   { isRamp = true }},
                {Flow1Type.Flipbook, new EffectConfig               { isFlippbook = true }},
            };
            Flow2Config = new Dictionary<Flow2Type, EffectConfig>(new Flow2TypeComparer())
            {
                {Flow2Type.AlphaCover, new EffectConfig             { isAlphaCover = true }},
                {Flow2Type.Add, new EffectConfig                    { isAdd = true }},
                {Flow2Type.Mul, new EffectConfig                    { isMul = true }},
                {Flow2Type.Distort, new EffectConfig                { isDistort = true }},
                {Flow2Type.Parrallax, new EffectConfig              { isParallax = true }},
            };
        }

        MaterialProperty effectOption = null;

        public static Color seperateLine = new Color(0.35f, 0.59f, 0.83f);

        protected override bool defaultDrawTilingOffset { get { return false; } }

        public override void FindProperties(MaterialProperty[] props)
        {
            base.FindProperties(props);
            effectOption = FindProperty("_EffectOption", props);
        }

        protected override void DoFirstTimeApply(Material material, MaterialProperty[] props)
        {
            base.DoFirstTimeApply(material, props);
        }

        public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
        {
            InitConfig();
            base.OnGUI(materialEditor, props);
        }

        public static void DrawUILine(Color color, int thickness = 5, int padding = 10)
        {
            Rect r = EditorGUILayout.GetControlRect(GUILayout.Height(padding + thickness));
            r.height = thickness;
            r.y += padding / 2;
            r.x -= 2;
            r.width += 6;
            EditorGUI.DrawRect(r, color);
        }

        protected override void DrawHeaders()
        {
            if (cullMode != null)
            {
                CullModePopup();
                MarkProperty("_cull");
            }
        }

        protected SubMode GetMaterialSubMode(float materialValue)
        {
            if (materialValue == 0.0f)
            {
                return SubMode.FlowMap;
            }
            else if (materialValue == 1.0f)
            {
                return SubMode.RidescenceClearCoat;
            }

            return SubMode.FlowMap;
        }

        protected float SubModeToMaterialValue(SubMode subMode)
        {
            switch (subMode)
            {
                case SubMode.FlowMap:
                    return 0.0f;
                case SubMode.RidescenceClearCoat:
                    return 1.0f;
                default:
                    return 0.0f;
            }
        }

        protected MaskMode GetMaterialMaskMode(float materialValue)
        {
            if(materialValue == 0.0f)
            {
                return MaskMode.SingelGradientChannel;
            }
            else if(materialValue == 1.0f)
            {
                return MaskMode.MaterialIDMode;
            }
            else if(materialValue == 2.0f)
            {
                return MaskMode.DualGradientChannels;
            }

            return MaskMode.SingelGradientChannel;
        }
        protected float MaskModeToMaterialValue(MaskMode maskMode)
        {
            switch(maskMode)
            {
                case MaskMode.SingelGradientChannel:
                    return 0.0f;
                case MaskMode.MaterialIDMode:
                    return 1.0f;
                case MaskMode.DualGradientChannels:
                    return 2.0f;
                default:
                    return 0.0f;
            }
        }
        protected void SetMaskModeShaderFeature(MaskMode maskMode, Material mat)
        {
            if(maskMode == MaskMode.MaterialIDMode)
            {
                SetKeyword(mat, "MATERIAL_ID_MODE", true);
            }
            else if (maskMode == MaskMode.DualGradientChannels)
            {
                SetKeyword(mat, "MATERIAL_ID_MODE", false);
            }
            else if (maskMode == MaskMode.SingelGradientChannel)
            {
                SetKeyword(mat, "MATERIAL_ID_MODE", false);
            }
        }

        protected bool VectorSubComponentEqual(Vector4 lhs, Vector3 rhs)
        {
            return (lhs.x == rhs.x) && (lhs.y == rhs.y) && (lhs.z == rhs.z);
        }

        protected PlanarProjectMode GetPlanarProjectMode(Vector4 projectAxisU, Vector4 projectAxisV)
        {
            if(VectorSubComponentEqual(projectAxisU, Vector3.right) && VectorSubComponentEqual(projectAxisV, Vector3.forward))
            {
                return PlanarProjectMode.XZ;
            }
            else if (VectorSubComponentEqual(projectAxisU, Vector3.right) && VectorSubComponentEqual(projectAxisV, Vector3.up))
            {
                return PlanarProjectMode.XY;
            }
            else if (VectorSubComponentEqual(projectAxisU, Vector3.up) && VectorSubComponentEqual(projectAxisV, Vector3.forward))
            {
                return PlanarProjectMode.YZ;
            }
            return PlanarProjectMode.XZ;
        }

        protected UvMode GetUvMode(float shaderValue)
        {
            if(Mathf.Abs(shaderValue - (float)UvMode.Uv0)<0.001f)
            {
                return UvMode.Uv0;
            }
            else if(Mathf.Abs(shaderValue - (float)UvMode.LocalSpaceProjection) < 0.001f)
            {
                return UvMode.LocalSpaceProjection;
            }
            else if (Mathf.Abs(shaderValue - (float)UvMode.Uv1) < 0.001f)
            {
                return UvMode.Uv1;
            }

            return UvMode.Uv0; 
        }
        protected void SetUvMode(UvMode mode, ref MaterialProperty projAxis_U, ref MaterialProperty projAxis_V )
        {
            var u = projAxis_U.vectorValue;
            var v = projAxis_V.vectorValue;
            u.w = (float)mode;  // uv mode is passed through projAxis_U.w

            if (mode == UvMode.LocalSpaceProjection)
            {
                EditorGUILayout.Space();
                GUILayout.Label(Styles.projAxisText);
                PlanarProjectMode pMode = GetPlanarProjectMode(projAxis_U.vectorValue, projAxis_V.vectorValue);
                pMode = (PlanarProjectMode)EditorGUILayout.EnumPopup(pMode);
                SetPlanarProjectModeParameters(pMode, ref u, ref v);
            }

            projAxis_U.vectorValue = u;
            projAxis_V.vectorValue = v;
        }

        protected void SetPlanarProjectModeParameters(PlanarProjectMode mode, ref Vector4 projectAxisU, ref Vector4 projectAxisV)
        {
            Vector4 originalAxisU = projectAxisU;
            Vector4 originalAxisV = projectAxisV;
            if (mode == PlanarProjectMode.XY)
            {
                projectAxisU = Vector3.right;
                projectAxisV = Vector3.up;
            }
            else if (mode == PlanarProjectMode.XZ)
            {
                projectAxisU = Vector3.right;
                projectAxisV = Vector3.forward;
            }
            else if (mode == PlanarProjectMode.YZ)
            {
                projectAxisU = Vector3.up;
                projectAxisV = Vector3.forward;
            }

            // w should not be modified.
            projectAxisU.w = originalAxisU.w;
            projectAxisV.w = originalAxisV.w;
        }

        protected override bool DrawManagedProperties(Material material, MaterialProperty[] props)
        {
            var mainMode = EffectTypeDict[material.shader.name]; //shader粒度的合并效果
            bool hasFlowmap1 = ((mainMode == EffectType.Flow1) || (mainMode == EffectType.Flow2));
            bool hasFlowmap2 = (mainMode == EffectType.Flow2);

            int indentation = 2; // align with labels of texture properties
            bool needFix = false;

            if (hasFlowmap1 && !hasFlowmap2)
            {
                var subModeValue = FindAndMarkProperty("_SubMode", props);
                SubMode subMode = GetMaterialSubMode(subModeValue.floatValue);

                GUILayout.Label(Styles.SubModeText, EditorStyles.boldLabel);
                subMode = (SubMode)EditorGUILayout.EnumPopup(subMode);
                subModeValue.floatValue = SubModeToMaterialValue(subMode);
            }

            var materialID = FindAndMarkProperty("_MaterialID", props);
            MaskMode maskMode = GetMaterialMaskMode(materialID.floatValue);
            bool materialMode = (maskMode == MaskMode.MaterialIDMode);
            bool doubleGradientMode = (maskMode == MaskMode.DualGradientChannels);

            GUILayout.Label(Styles.maskModeText, EditorStyles.boldLabel);
            maskMode = (MaskMode)EditorGUILayout.EnumPopup(maskMode);

            var ChannelIntensityProp = FindAndMarkProperty("_ChannelIntensity0", props);
            materialID.floatValue = MaskModeToMaterialValue(maskMode);
            var channelMaskProp = FindAndMarkProperty("_ChnMask0", props);
            SetMaskModeShaderFeature(maskMode, material);
            if (maskMode == MaskMode.SingelGradientChannel)
                channelMaskProp.vectorValue = new Vector4(1, 0, 0, 0);
            else if (maskMode == MaskMode.DualGradientChannels)
                channelMaskProp.vectorValue = new Vector4(1, 1, 0, 0);
            else if (maskMode == MaskMode.MaterialIDMode)
                channelMaskProp.vectorValue = new Vector4(1, 1, 1, 1);
            Vector4 channelMask = channelMaskProp.vectorValue;

            EditorGUILayout.Space();

            GUILayout.Label(Styles.flowmap1IntensityText, EditorStyles.boldLabel);
            /// Set channel intensity:
            if (hasFlowmap1)
            {
                Vector4 channelIntensity = ChannelIntensityProp.vectorValue;
                if (maskMode == MaskMode.SingelGradientChannel)
                {
                    channelIntensity.x = EditorGUILayout.Slider("Channel 0 :", ChannelIntensityProp.vectorValue.x, 0.0f, 1.0f);
                }
                else if (maskMode == MaskMode.DualGradientChannels)
                {
                    channelIntensity.x = EditorGUILayout.Slider("Channel 0 :", ChannelIntensityProp.vectorValue.x, 0.0f, 1.0f);
                    channelIntensity.y = EditorGUILayout.Slider("Channel 1 :", ChannelIntensityProp.vectorValue.y, 0.0f, 1.0f);
                }
                else if (maskMode == MaskMode.MaterialIDMode)
                {
                    channelIntensity.x = EditorGUILayout.Slider("ID 0 :", ChannelIntensityProp.vectorValue.x, 0.0f, 1.0f);
                    channelIntensity.y = EditorGUILayout.Slider("ID 1 :", ChannelIntensityProp.vectorValue.y, 0.0f, 1.0f);
                    channelIntensity.z = EditorGUILayout.Slider("ID 2 :", ChannelIntensityProp.vectorValue.z, 0.0f, 1.0f);
                    channelIntensity.w = EditorGUILayout.Slider("ID 3 :", ChannelIntensityProp.vectorValue.w, 0.0f, 1.0f);
                }
                channelIntensity.Scale(channelMask);    // mask intensity
                ChannelIntensityProp.vectorValue = channelIntensity;
            }

            /// Set Flowmap 2 channel intensity
            if (hasFlowmap2)
            {
                EditorGUILayout.Space();
                GUILayout.Label(Styles.flowmap2IntensityText, EditorStyles.boldLabel);
                var ChannelIntensity2Prop = FindAndMarkProperty("_ChannelIntensity1", props);

                Vector4 channelIntensity2 = ChannelIntensity2Prop.vectorValue;
                if (maskMode == MaskMode.SingelGradientChannel)
                {
                    channelIntensity2.x = EditorGUILayout.Slider("Channel 0 :", ChannelIntensity2Prop.vectorValue.x, 0.0f, 1.0f);
                }
                else if (maskMode == MaskMode.DualGradientChannels)
                {
                    channelIntensity2.x = EditorGUILayout.Slider("Channel 0 :", ChannelIntensity2Prop.vectorValue.x, 0.0f, 1.0f);
                    channelIntensity2.y = EditorGUILayout.Slider("Channel 1 :", ChannelIntensity2Prop.vectorValue.y, 0.0f, 1.0f);
                }
                else if (maskMode == MaskMode.MaterialIDMode)
                {
                    channelIntensity2.x = EditorGUILayout.Slider("ID 0 :", ChannelIntensity2Prop.vectorValue.x, 0.0f, 1.0f);
                    channelIntensity2.y = EditorGUILayout.Slider("ID 1 :", ChannelIntensity2Prop.vectorValue.y, 0.0f, 1.0f);
                    channelIntensity2.z = EditorGUILayout.Slider("ID 2 :", ChannelIntensity2Prop.vectorValue.z, 0.0f, 1.0f);
                    channelIntensity2.w = EditorGUILayout.Slider("ID 3 :", ChannelIntensity2Prop.vectorValue.w, 0.0f, 1.0f);
                }
                channelIntensity2.Scale(channelMask);    // mask intensity
                ChannelIntensity2Prop.vectorValue = channelIntensity2;
            }

            ///////////////////////////////////////////// UV mode Field: /////////////////////////////////////////////
            EditorGUILayout.Space();
            DrawUILine(seperateLine);

            var flowmap1Contribution = FindAndMarkProperty("_Flowmap1Contribution", props);
            Vector4 flow1ctb = flowmap1Contribution.vectorValue;
            var ProjectAxis_U = FindAndMarkProperty("_ProjectAxis_U", props);
            var ProjectAxis_V = FindAndMarkProperty("_ProjectAxis_V", props);
            var ProjectAxis_U2 = FindAndMarkProperty("_ProjectAxis_U2", props);
            var ProjectAxis_V2 = FindAndMarkProperty("_ProjectAxis_V2", props);

            //// Flowmap1 projection axis:
            if (hasFlowmap1)
            {
                UvMode uvMode = GetUvMode(ProjectAxis_U.vectorValue.w);
                GUILayout.Label(Styles.uvMode1Text, EditorStyles.boldLabel);
                uvMode = (UvMode)EditorGUILayout.EnumPopup(uvMode);

                SetUvMode(uvMode, ref ProjectAxis_U, ref ProjectAxis_V);
                if (uvMode == UvMode.LocalSpaceProjection)
                    flow1ctb.z = EditorGUILayout.Slider("Project Fadeout", flow1ctb.z, 0, 5);
                else
                    flow1ctb.z = 0.0f;
            }

            //// Flowmap2 projection axis:
            if (hasFlowmap2)
            {
                EditorGUILayout.Space();

                UvMode uvMode2 = GetUvMode(ProjectAxis_U2.vectorValue.w);
                GUILayout.Label(Styles.uvMode2Text, EditorStyles.boldLabel);
                uvMode2 = (UvMode)EditorGUILayout.EnumPopup(uvMode2);

                SetUvMode(uvMode2, ref ProjectAxis_U2, ref ProjectAxis_V2);
                if (uvMode2 == UvMode.LocalSpaceProjection)
                    flow1ctb.w = EditorGUILayout.Slider("Project Fadeout", flow1ctb.w, 0, 5);
                else
                    flow1ctb.w = 0.0f;
            }

            EditorGUILayout.Space();
            DrawUILine(seperateLine);

            /////////////////////////////////////////////  Primary properties /////////////////////////////////////////////
            GUILayout.Label(Styles.baseTitleText, EditorStyles.boldLabel);

            var albedoMap = FindAndMarkProperty("_MainTex", props);
            m_MaterialEditor.TexturePropertySingleLine(Styles.albedoMapText, albedoMap);
            {
                var format = new RequestedMapFormat();
                if (FixTexture(albedoMap.textureValue, format))
                    needFix = true;
            }

            MarkProperty("_BumpMapPakced");
            string text = "Normal Map";
            var bumpMap = FindAndMarkProperty("_BumpMapPakced", props);
            m_MaterialEditor.TexturePropertySingleLine(new GUIContent(text), bumpMap);
            {
                var format = new RequestedMapFormat();
                format.sRGB = false;
                format.mipMode = TextureImporterMipFilter.NormalGlossiness;

                if (FixTexture(bumpMap.textureValue, format))
                    needFix = true;
            }

            MarkProperty("_MetallicRoughnessMap");
            var metallicMap = FindAndMarkProperty("_MetallicRoughnessMap", props, false);
            m_MaterialEditor.TexturePropertySingleLine(Styles.metallicMapText, metallicMap);
            {
                var format = new RequestedMapFormat();
                format.sRGB = false;
                if (maskMode == MaskMode.MaterialIDMode)
                {
                    format.needAlpha = true;
                }
                if (FixTexture(metallicMap.textureValue, format))
                    needFix = true;
            }
            /////////////////////////////////////////////Over Layer/////////////////////////////////////////

            GUILayout.Label(Styles.overlayerTileText, EditorStyles.boldLabel);
            var blendScale = FindAndMarkProperty("_BlendScale", props);
            var overMetallic = FindAndMarkProperty("_OverMetallic", props);
            var overGlossiness = FindAndMarkProperty("_OverGlossiness", props);

            ///////////////////////////// mateiral Mode set albedo color ///////////////////////////////////////////
            if (maskMode == MaskMode.MaterialIDMode)
            {
                var materialColor1 = FindAndMarkProperty("_MatColor1", props);
                var materialColor2 = FindAndMarkProperty("_MatColor2", props);
                var isAlbedo1 = FindAndMarkProperty("_isAlbedo1", props);
                var isAlbedo2 = FindAndMarkProperty("_isAlbedo2", props);
                m_MaterialEditor.ShaderProperty(materialColor1, Styles.ColorText, indentation);

                bool isAlbedoColor1 = isAlbedo1.floatValue == 1.0f;
                EditorGUI.BeginChangeCheck();
                isAlbedoColor1 = EditorGUILayout.ToggleLeft("is Albedo Color?", isAlbedoColor1);
                if (EditorGUI.EndChangeCheck())
                {
                    isAlbedo1.floatValue = isAlbedoColor1 ? 1.0f : 0.0f;
                }
                if (isAlbedoColor1)
                {
                    material.SetColor("_EmmiColor1", Color.black);
                }
                else
                {
                    material.SetColor("_EmmiColor1", material.GetColor("_MatColor1"));
                }

                m_MaterialEditor.ShaderProperty(materialColor2, Styles.ColorText, indentation);

                bool isAlbedoColor2 = isAlbedo2.floatValue == 1.0f;
                EditorGUI.BeginChangeCheck();
                isAlbedoColor2 = EditorGUILayout.ToggleLeft("is Albedo Color?", isAlbedoColor2);
                if (EditorGUI.EndChangeCheck())
                {
                    isAlbedo2.floatValue = isAlbedoColor2 ? 1.0f : 0.0f;
                }
                if (isAlbedoColor2)
                {
                    material.SetColor("_EmmiColor2", Color.black);
                }
                else
                {
                    material.SetColor("_EmmiColor2", material.GetColor("_MatColor2"));
                }
            }
            m_MaterialEditor.ShaderProperty(blendScale, Styles.ScaleText, indentation);

            ///////////////////////////// PBR blending ///////////////////////////////////////////
            var blendGlossiness = FindAndMarkProperty("_blendGlossiness", props);
            var blendMetallic = FindAndMarkProperty("_blendMetallic", props);
            Vector4 blendGlossValue = blendGlossiness.vectorValue;
            Vector4 blendMetalValue = blendMetallic.vectorValue;
            if (maskMode == MaskMode.SingelGradientChannel)
            {
                EditorGUILayout.LabelField("Channel 0:", EditorStyles.boldLabel);
                EditorGUI.indentLevel += 2;
                blendGlossValue.x = EditorGUILayout.Slider("Glossiness", blendGlossValue.x, 0, 1);
                blendMetalValue.x = EditorGUILayout.Slider("Metallic", blendMetalValue.x, 0, 1);
                EditorGUI.indentLevel -= 2;
            }
            else if (maskMode == MaskMode.DualGradientChannels)
            {
                EditorGUILayout.LabelField("Channel 0:", EditorStyles.boldLabel);
                EditorGUI.indentLevel += 2;
                blendGlossValue.x = EditorGUILayout.Slider("Glossiness", blendGlossValue.x, 0, 1);
                blendMetalValue.x = EditorGUILayout.Slider("Metallic", blendMetalValue.x, 0, 1);
                EditorGUI.indentLevel -= 2;
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Channel 1:", EditorStyles.boldLabel);
                EditorGUI.indentLevel += 2;
                blendGlossValue.y = EditorGUILayout.Slider("Glossiness", blendGlossValue.y, 0, 1);
                blendMetalValue.y = EditorGUILayout.Slider("Metallic", blendMetalValue.y, 0, 1);
                EditorGUI.indentLevel -= 2;

            }
            else if (maskMode == MaskMode.MaterialIDMode)
            {
                EditorGUILayout.LabelField("ID 0:", EditorStyles.boldLabel);
                EditorGUI.indentLevel += 2;
                blendGlossValue.x = EditorGUILayout.Slider("Glossiness", blendGlossValue.x, 0, 1);
                blendMetalValue.x = EditorGUILayout.Slider("Metallic", blendMetalValue.x, 0, 1);
                EditorGUI.indentLevel -= 2;
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("ID 1:", EditorStyles.boldLabel);
                EditorGUI.indentLevel += 2;
                blendGlossValue.y = EditorGUILayout.Slider("Glossiness", blendGlossValue.y, 0, 1);
                blendMetalValue.y = EditorGUILayout.Slider("Metallic", blendMetalValue.y, 0, 1);
                EditorGUI.indentLevel -= 2;
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("ID 2:", EditorStyles.boldLabel);
                EditorGUI.indentLevel += 2;
                blendGlossValue.z = EditorGUILayout.Slider("Glossiness", blendGlossValue.z, 0, 1);
                blendMetalValue.z = EditorGUILayout.Slider("Metallic", blendMetalValue.z, 0, 1);
                EditorGUI.indentLevel -= 2;
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("ID 3:", EditorStyles.boldLabel);
                EditorGUI.indentLevel += 2;
                blendGlossValue.w = EditorGUILayout.Slider("Glossiness", blendGlossValue.w, 0, 1);
                blendMetalValue.w = EditorGUILayout.Slider("Metallic", blendMetalValue.w, 0, 1);
                EditorGUI.indentLevel -= 2;
            }

            blendGlossiness.vectorValue = blendGlossValue;
            blendMetallic.vectorValue = blendMetalValue;
            overGlossiness.floatValue = blendGlossiness.vectorValue.x;
            overMetallic.floatValue = blendMetallic.vectorValue.x;

            /////////////////////////////////////////////Main  Effect/////////////////////////////////////////
            EditorGUILayout.Space();
            DrawUILine(seperateLine);

            if (hasFlowmap1)
            {
                if (!hasFlowmap2)
                {
                    //// submode
                    var GetSubeMode = FindAndMarkProperty("_SubMode", props);
                    SubMode subModeValue = GetMaterialSubMode(GetSubeMode.floatValue);
                    GetSubeMode.floatValue = SubModeToMaterialValue(subModeValue);

                    /// Submode RidescenceClearCoat
                    if (subModeValue == SubMode.RidescenceClearCoat)
                    {
                        ///Avoid adding keywords, borrowed keywords, iridescent effects
                        material.EnableKeyword("_USEEMISSIONMASK");
                        GUILayout.Label(Styles.iridescenceTitleText, EditorStyles.boldLabel);

                        //////DetailNormal
                        var _DetailNormalMap = FindAndMarkProperty("_DetailNormalMap", props, false);
                        m_MaterialEditor.TexturePropertySingleLine(Styles.DetailNormalText, _DetailNormalMap);
                        {
                            var format = new RequestedMapFormat();
                            format.sRGB = false;
                            format.mipMode = TextureImporterMipFilter.NormalGlossiness;
                            format.needTilingOffset = true;
                            if (FixTexture(_DetailNormalMap.textureValue, format))
                                needFix = true;
                        }
                        var _DetailNormlIntensity = FindAndMarkProperty("_DetailNormlIntensity", props);
                        float DetailNormlIntensityValue = EditorGUILayout.Slider("Detail Normal Intensity", _DetailNormlIntensity.floatValue, 0, 3);
                        _DetailNormlIntensity.floatValue = DetailNormlIntensityValue;
                        var _DetailUVTilling = FindAndMarkProperty("_DetailUVTilling", props);
                        float detailNormal = EditorGUILayout.Slider("Detail Normal UV Tilling", _DetailUVTilling.floatValue, 0, 15);
                        _DetailUVTilling.floatValue = detailNormal;

                        /////////CamouflageMetalGloss  XY : Glossiness  ZW : Metallic
                        EditorGUILayout.Space();
                        EditorGUILayout.LabelField("CamouflageBlackMask:", EditorStyles.boldLabel);
                        var CamouflageBlendMetalGloss = FindAndMarkProperty("_CamouflageMetalGloss", props);
                        Vector4 CamouflageMetalGlossVec = CamouflageBlendMetalGloss.vectorValue;
                        CamouflageMetalGlossVec.x = EditorGUILayout.Slider("Glossiness", CamouflageMetalGlossVec.x, 0, 1);
                        CamouflageMetalGlossVec.z = EditorGUILayout.Slider("Metallic", CamouflageMetalGlossVec.z, 0, 1);

                        EditorGUILayout.Space(); 
                        EditorGUILayout.LabelField("CamouflageWhiteMask:", EditorStyles.boldLabel);
                        CamouflageMetalGlossVec.y = EditorGUILayout.Slider("Glossiness", CamouflageMetalGlossVec.y, 0, 1);
                        CamouflageMetalGlossVec.w = EditorGUILayout.Slider("Metallic", CamouflageMetalGlossVec.w, 0, 1);
                        CamouflageBlendMetalGloss.vectorValue = CamouflageMetalGlossVec;

                        //////CamouflageColor
                        EditorGUILayout.Space();
                        EditorGUILayout.LabelField("CamouflageColor:", EditorStyles.boldLabel);
                        var _CamouflageColor = FindAndMarkProperty("_CamouflageColor", props);
                        var _CamouflageColor1 = FindAndMarkProperty("_CamouflageColor1", props);
                        var _CamouflageColor2 = FindAndMarkProperty("_CamouflageColor2", props);

                        m_MaterialEditor.ColorProperty(_CamouflageColor, "BlackMaskColor");
                        m_MaterialEditor.ColorProperty(_CamouflageColor1, "BlackMaskColor1");
                        m_MaterialEditor.ColorProperty(_CamouflageColor2, "WhiteMaskColor");

                        /////IridescenceSetting   X: IridescenceSaturate Y: IridescenceBrightness Z: IridescenceScale W : IridescenceOffset
                        EditorGUILayout.Space();
                        EditorGUILayout.LabelField("IridescenceSetting:", EditorStyles.boldLabel);
                        var _IridescenceSetting = FindAndMarkProperty("_IridescenceSetting", props);
                        Vector4 IridescenceSettingVec = _IridescenceSetting.vectorValue;
                        IridescenceSettingVec.x = EditorGUILayout.Slider("IridescenceSaturate", IridescenceSettingVec.x, 0, 1);
                        IridescenceSettingVec.y = EditorGUILayout.Slider("IridescenceBrightness", IridescenceSettingVec.y, 0, 3);
                        IridescenceSettingVec.z = EditorGUILayout.Slider("IridescenceRange", IridescenceSettingVec.z, 0, 1);
                        IridescenceSettingVec.w = EditorGUILayout.Slider("IridescenceOffset", IridescenceSettingVec.w, 0, 5);
                        _IridescenceSetting.vectorValue = IridescenceSettingVec;
                        var _IridescenceIntensity = FindAndMarkProperty("_IridescenceIntensity", props);
                        float IridescenceIntensityValue = EditorGUILayout.Slider("IridescenceIntensity", _IridescenceIntensity.floatValue, 0, 1);
                        _IridescenceIntensity.floatValue = IridescenceIntensityValue;
                    }

                    else if (subModeValue == SubMode.FlowMap)
                    {
                        GetFlowEffect(material, props, needFix, indentation, flow1ctb,  flowmap1Contribution,  hasFlowmap2);
                    }
                }
                
                else
                {
                    GetFlowEffect(material, props, needFix, indentation, flow1ctb, flowmap1Contribution, hasFlowmap2);
                }
            }

            if (hasFlowmap2)
            {
                var flowMap2 = FindAndMarkProperty("_Flowmap2", props, false);
                m_MaterialEditor.TexturePropertySingleLine(Styles.flowmapText2, flowMap2);
                {
                    var format = new RequestedMapFormat();
                    format.needTilingOffset = true;
                    if (FixTexture(flowMap2.textureValue, format))
                        needFix = true;
                }

                ////////////////////flowmap channel mode///////////////////////////////////////
                var channelR2 = FindAndMarkProperty("_FlowChannelR2", props, false);
                var channelG2 = FindAndMarkProperty("_FlowChannelG2", props, false);
                var channelB2 = FindAndMarkProperty("_FlowChannelB2", props, false);
                var channelOption2 = FindProperty("_ChannelOption2", props);

                ColorChannelLayout(channelOption2, material, channelR2, channelG2, channelB2, 2);

                m_MaterialEditor.TextureScaleOffsetProperty(flowMap2);

                var flowScale2 = FindAndMarkProperty("_FlowmapScale2", props);
                var flowSpeed2 = FindAndMarkProperty("_FlowmapSpeed2", props);

                var flowDirectionRotation2 = FindAndMarkProperty("_FlowRotation", props);
                var flowDirectionRotationSinCos2 = FindAndMarkProperty("_FlowRotationSinCos", props);
                string flowmap2UVRot = "Flowmap UV Rotation 2";
                SetTextureRotation(flowDirectionRotation2, flowDirectionRotationSinCos2, false, flowmap2UVRot);

                var flowmap2Contribution = FindAndMarkProperty("_Flowmap2Contribution", props);
                Vector4 flow2ctb = flowmap2Contribution.vectorValue;
                float flowmap2AlbedoContribution = EditorGUILayout.Slider("Albedo Contribution", flow2ctb.x, 0, 1);
                float flowmap2EmissionContribution = EditorGUILayout.Slider("Emission Contribution", flow2ctb.y, 0, 1);
                flow2ctb.x = flowmap2AlbedoContribution;
                flow2ctb.y = flowmap2EmissionContribution;
                flowmap2Contribution.vectorValue = flow2ctb;

                var flowNormalDistort2 = FindAndMarkProperty("_FlowmapNormalDistort2", props);

                m_MaterialEditor.ShaderProperty(flowScale2, Styles.ScaleText, indentation);
                m_MaterialEditor.ShaderProperty(flowSpeed2, Styles.flowSpeedText, indentation);
                m_MaterialEditor.ShaderProperty(flowNormalDistort2, Styles.NormalDistortText, indentation);

                var contentEffectOption2 = FindAndMarkProperty("_ContentEffectOption2", props, false);
                EditorGUI.BeginChangeCheck();
                var flowmap2Config = (int)contentEffectOption2.floatValue;

                flowmap2Config = EditorGUILayout.Popup(Styles.contentOptions, flowmap2Config, flow1Options);
                flowmap2Config = (int)Enum.Parse(typeof(Flow1Type), flow1Options[flowmap2Config]);

                if (EditorGUI.EndChangeCheck())
                {
                    m_MaterialEditor.RegisterPropertyChangeUndo(" Content Option 2 Change");
                    contentEffectOption2.floatValue = (float)flowmap2Config;
                }
                var flowmap2EffectConfig = GetSubEffectConfig(EffectType.Flow1, flowmap2Config);

                // set flake1 options:
                var flake1ptionProp = FindAndMarkProperty("_FlakeOption1", props);
                MarkFlakeCompoundEffectOption(flowmap2EffectConfig, ref flake1ptionProp);

                /// Flwomap2 breath and Flake:
                /// NOTICE: these are runtime data for flake / breath / ramp:
                Color col00 = Color.black, col01 = Color.black;
                float flakeSpeed00 = 0, flakeSpeed01 = 0;
                float flakeOffset00 = 0, flakeOffset01 = 0;
                float flakeThreshold00 = 0, flakeThreshold01 = 0;
                float flakeScale00 = 0, flakeScale01 = 1.0f;

                /// Flwomap2 Breath:
                if (flowmap2EffectConfig.isBreath)
                {
                    var flakeScale = FindAndMarkProperty("_Flow2FlakeScale", props);
                    var flakeSpeed1 = FindAndMarkProperty("_Flow2FlakeSpeed1", props);
                    var flakeOffset = FindAndMarkProperty("_Flow2FlakeOffset", props);
                    var flakeThreshold = FindAndMarkProperty("_Flow2FlakeThreshold", props);

                    GUILayout.Label(Styles.breathTitleText, EditorStyles.boldLabel);

                    m_MaterialEditor.ShaderProperty(flakeScale, Styles.ScaleText, indentation);
                    m_MaterialEditor.ShaderProperty(flakeSpeed1, Styles.SpeedText, indentation);
                    m_MaterialEditor.ShaderProperty(flakeOffset, Styles.OffsetText, indentation);//flake 2 offset
                    m_MaterialEditor.ShaderProperty(flakeThreshold, Styles.ThresholdText, indentation);//flake 2 threshold

                    flakeSpeed00 = flakeSpeed1.floatValue;
                    flakeOffset00 = flakeOffset.floatValue;
                    flakeThreshold00 = flakeThreshold.floatValue;
                    flakeScale00 = flakeScale.floatValue;
                }

                /// Flwomap2 Flake:
                if (flowmap2EffectConfig.isFlake)
                {
                    var flakeScale = FindAndMarkProperty("_Flow2FlakeScale", props);
                    var flakeSpeed1 = FindAndMarkProperty("_Flow2FlakeSpeed1", props);
                    var flakeOffset = FindAndMarkProperty("_Flow2FlakeOffset", props);
                    var flakeThreshold = FindAndMarkProperty("_Flow2FlakeThreshold", props);
                    var flakeSpeed2 = FindAndMarkProperty("_Flow2FlakeSpeed2", props);

                    GUILayout.Label(Styles.flakeTitleText, EditorStyles.boldLabel);

                    m_MaterialEditor.ShaderProperty(flakeScale, Styles.ScaleText, indentation);
                    m_MaterialEditor.ShaderProperty(flakeSpeed1, Styles.SpeedText, indentation);
                    m_MaterialEditor.ShaderProperty(flakeOffset, Styles.OffsetText, indentation);//flake 2 offset
                    m_MaterialEditor.ShaderProperty(flakeThreshold, Styles.ThresholdText, indentation);//flake 2 threshold
                    m_MaterialEditor.ShaderProperty(flakeSpeed2, Styles.SpeedText2, indentation);

                    flakeSpeed00 = flakeSpeed1.floatValue;
                    flakeSpeed01 = flakeSpeed2.floatValue;
                    flakeOffset00 = flakeOffset.floatValue;
                    flakeThreshold00 = flakeThreshold.floatValue;
                    flakeScale00 = flakeScale.floatValue;
                    flakeScale01 = 1.0f;
                }

                /// Flwomap2 Ramp:
                if (flowmap2EffectConfig.isRamp)
                {
                    GUILayout.Label(Styles.rampTitleText, EditorStyles.boldLabel);
                    var rampScale = FindAndMarkProperty("_Flow2RampScale", props);
                    var rampSpeed = FindAndMarkProperty("_Flow2RampSpeed", props);
                    var rampColor1 = FindAndMarkProperty("_Flow2RampColor1", props);
                    var rampColor2 = FindAndMarkProperty("_Flow2RampColor2", props);
                    var rampThreshold = FindAndMarkProperty("_Flow2RampThreshold", props);

                    m_MaterialEditor.ShaderProperty(rampScale, Styles.ScaleText, indentation);
                    m_MaterialEditor.ShaderProperty(rampSpeed, Styles.SpeedText, indentation);
                    m_MaterialEditor.ShaderProperty(rampColor1, Styles.ColorText, indentation);
                    m_MaterialEditor.ShaderProperty(rampColor2, Styles.ColorText, indentation);
                    m_MaterialEditor.ShaderProperty(rampThreshold, Styles.ThresholdText, indentation);

                    col00 = rampColor1.colorValue;
                    col01 = rampColor2.colorValue;
                    flakeSpeed00 = rampSpeed.floatValue;
                    flakeThreshold00 = rampThreshold.floatValue;
                    flakeScale00 = rampScale.floatValue;
                }

                /// Enable Flwomap2 Flake0 keyword:
                SetKeyword(material, Flake1EfxKeyword, flowmap2EffectConfig.isBreath || flowmap2EffectConfig.isFlake || flowmap2EffectConfig.isRamp);
                /// This set the actual shader runtime parameters for breath / flake / ramp:
                SetFlakeEfxMaterial(material, 1,
                                    col00, col01, Bool2Float(flowmap2EffectConfig.isFlake), Bool2Float(flowmap2EffectConfig.isRamp),
                                    flakeSpeed00, flakeSpeed01, flakeOffset00, flakeOffset01,
                                    flakeThreshold00, flakeThreshold01, flakeScale00, flakeScale01);

                /// Flwomap2 HSV:
                if (flowmap2EffectConfig.isHSV)
                {
                    GUILayout.Label(Styles.hsvTitleText, EditorStyles.boldLabel);
                    var hsvSpeed = FindAndMarkProperty("_Flow2HSVSpeed", props);
                    m_MaterialEditor.ShaderProperty(hsvSpeed, Styles.SpeedText, indentation);
                }
                SetKeyword(material, HSV1Keyword, flowmap2EffectConfig.isHSV);

                /// Flwomap2 Flipbook:
                if (flowmap2EffectConfig.isFlippbook)
                {
                    DrawFlipbookGUI(material, flowmap2EffectConfig.isFlippbook, props, "_FlipbookParam1");
                }
                SetKeyword(material, Flipbook1Keyword, flowmap2EffectConfig.isFlippbook);
                
            }

            ///////////////////////////////////////////// Compound Effect for flowmap2 /////////////////////////////////////////
            EditorGUILayout.Space();
            DrawUILine(seperateLine);

            if (hasFlowmap2 && !(maskMode == MaskMode.MaterialIDMode))
            {
                GUILayout.Label(Styles.subTitleText, EditorStyles.boldLabel);
                EditorGUI.BeginChangeCheck();
                var config = SubEffectPopup(mainMode);
                bool compoundEffectChanged = EditorGUI.EndChangeCheck();

                if (config.isAdd)
                {
                    GUILayout.Label(Styles.addTitleText, EditorStyles.boldLabel);
                    var addScale = FindAndMarkProperty("_AddScale", props);
                    m_MaterialEditor.ShaderProperty(addScale, Styles.ScaleText, indentation);

                    if (compoundEffectChanged)
                        addScale.floatValue = 1.0f;

                    material.SetFloat("_MulScale", 0);
                    material.SetFloat("_CoverScale", 0);
                }

                if (config.isAlphaCover)
                {
                    GUILayout.Label(Styles.alphaTitleText, EditorStyles.boldLabel);
                    var coverScale = FindAndMarkProperty("_CoverScale", props);
                    m_MaterialEditor.ShaderProperty(coverScale, Styles.ScaleText, indentation);

                    if (compoundEffectChanged)
                        coverScale.floatValue = 1.0f;

                    material.SetFloat("_MulScale", 0);
                    material.SetFloat("_AddScale", 0);
                }

                if (config.isMul)
                {
                    GUILayout.Label(Styles.mulTitleText, EditorStyles.boldLabel);
                    var mulScale = FindAndMarkProperty("_MulScale", props);
                    m_MaterialEditor.ShaderProperty(mulScale, Styles.ScaleText, indentation);

                    if (compoundEffectChanged)
                        mulScale.floatValue = 1.0f;

                    material.SetFloat("_AddScale", 0);
                    material.SetFloat("_CoverScale", 0);
                }

                if (config.isDistort)
                {
                    GUILayout.Label(Styles.distortTitleText, EditorStyles.boldLabel);
                    var flowDistort = FindAndMarkProperty("_FlowDistort", props);
                    m_MaterialEditor.ShaderProperty(flowDistort, Styles.DistortText, indentation);
                }

                if (config.isParallax)
                {
                    GUILayout.Label(Styles.parallaxTitleText, EditorStyles.boldLabel);
                    var flowParallax = FindAndMarkProperty("_FlowParallaxScale", props);
                    m_MaterialEditor.ShaderProperty(flowParallax, Styles.ParallaxText, indentation);
                }

                EditorGUILayout.Space();
                DrawUILine(seperateLine);
            }

            if (!(maskMode == MaskMode.MaterialIDMode))
            {
                GUILayout.Label(Styles.emissionTitleText, EditorStyles.boldLabel);
                var emissionTintColor = FindAndMarkProperty("_EmissionTintColor", props);
                m_MaterialEditor.ShaderProperty(emissionTintColor, Styles.EmissionTintText, indentation);
                EditorGUILayout.Space();
                DrawUILine(seperateLine);
            }

            return needFix;
        }

        /*

                protected bool DrawManagedProperties_Legacy(Material material, MaterialProperty[] props)
                {
                    var mainMode = EffectTypeDict[material.shader.name]; //shader粒度的合并效果

                    Color seperateLine = new Color(0.35f, 0.59f, 0.83f);
                    int indentation = 2; // align with labels of texture properties
                    bool needFix = false;

                    var materialID = FindAndMarkProperty("_MaterialID", props);
                    MaskMode maskMode = GetMaterialMaskMode(materialID.floatValue);
                    bool materialMode = (maskMode == MaskMode.MaterialIDMode);
                    bool doubleGradientMode = (maskMode == MaskMode.DualGradientChannels);

                    GUILayout.Label(Styles.maskModeText, EditorStyles.boldLabel);
                    maskMode = (MaskMode)EditorGUILayout.EnumPopup(maskMode);
                    //m_MaterialEditor.ShaderProperty(channelIntensity, "_ChannelMask0", 0);

                    var ChannelIntensityProp = FindAndMarkProperty("_ChannelIntensity0", props);

                    materialID.floatValue = MaskModeToMaterialValue(maskMode);
                    var channelMaskProp = FindAndMarkProperty("_ChnMask0", props);
                    SetMaskModeShaderFeature(maskMode, material);
                    if (maskMode == MaskMode.SingelGradientChannel)
                        channelMaskProp.vectorValue = new Vector4(1, 0, 0, 0);
                    else if (maskMode == MaskMode.DualGradientChannels)
                        channelMaskProp.vectorValue = new Vector4(1, 1, 0, 0);
                    else if (maskMode == MaskMode.MaterialIDMode)
                        channelMaskProp.vectorValue = new Vector4(1, 1, 1, 1);

                    Vector4 channelMask = channelMaskProp.vectorValue;

                    EditorGUILayout.Space();

                    GUILayout.Label(Styles.flowmap1IntensityText, EditorStyles.boldLabel);

                    /// Set channel intensity:
                    Vector4 channelIntensity = ChannelIntensityProp.vectorValue;
                    if (maskMode == MaskMode.SingelGradientChannel)
                    {
                        channelIntensity.x = EditorGUILayout.Slider("Channel 0 :", ChannelIntensityProp.vectorValue.x,0.0f,1.0f);
                    }
                    else if (maskMode == MaskMode.DualGradientChannels)
                    {
                        channelIntensity.x = EditorGUILayout.Slider("Channel 0 :", ChannelIntensityProp.vectorValue.x, 0.0f, 1.0f);
                        channelIntensity.y = EditorGUILayout.Slider("Channel 1 :", ChannelIntensityProp.vectorValue.y, 0.0f, 1.0f);
                    }
                    else if (maskMode == MaskMode.MaterialIDMode)
                    {
                        channelIntensity.x = EditorGUILayout.Slider("ID 0 :", ChannelIntensityProp.vectorValue.x,0.0f,1.0f);
                        channelIntensity.y = EditorGUILayout.Slider("ID 1 :", ChannelIntensityProp.vectorValue.y,0.0f,1.0f);
                        channelIntensity.z = EditorGUILayout.Slider("ID 2 :", ChannelIntensityProp.vectorValue.z,0.0f,1.0f);
                        channelIntensity.w = EditorGUILayout.Slider("ID 3 :", ChannelIntensityProp.vectorValue.w, 0.0f, 1.0f);
                    }
                    channelIntensity.Scale(channelMask);    // mask intensity
                    ChannelIntensityProp.vectorValue = channelIntensity;

                    /// Set Flowmap 2 channel intensity
                    if (mainMode == EffectType.Flow2)
                    {
                        EditorGUILayout.Space();
                        GUILayout.Label(Styles.flowmap2IntensityText, EditorStyles.boldLabel);
                        var ChannelIntensity2Prop = FindAndMarkProperty("_ChannelIntensity1", props);

                        Vector4 channelIntensity2 = ChannelIntensity2Prop.vectorValue;
                        if (maskMode == MaskMode.SingelGradientChannel)
                        {
                            channelIntensity2.x = EditorGUILayout.Slider("Channel 0 :", ChannelIntensity2Prop.vectorValue.x, 0.0f, 1.0f);
                        }
                        else if (maskMode == MaskMode.DualGradientChannels)
                        {
                            channelIntensity2.x = EditorGUILayout.Slider("Channel 0 :", ChannelIntensity2Prop.vectorValue.x, 0.0f, 1.0f);
                            channelIntensity2.y = EditorGUILayout.Slider("Channel 1 :", ChannelIntensity2Prop.vectorValue.y, 0.0f, 1.0f);
                        }
                        else if (maskMode == MaskMode.MaterialIDMode)
                        {
                            channelIntensity2.x = EditorGUILayout.Slider("ID 0 :", ChannelIntensity2Prop.vectorValue.x, 0.0f, 1.0f);
                            channelIntensity2.y = EditorGUILayout.Slider("ID 1 :", ChannelIntensity2Prop.vectorValue.y, 0.0f, 1.0f);
                            channelIntensity2.z = EditorGUILayout.Slider("ID 2 :", ChannelIntensity2Prop.vectorValue.z, 0.0f, 1.0f);
                            channelIntensity2.w = EditorGUILayout.Slider("ID 3 :", ChannelIntensity2Prop.vectorValue.w, 0.0f, 1.0f);
                        }
                        channelIntensity2.Scale(channelMask);    // mask intensity
                        ChannelIntensity2Prop.vectorValue = channelIntensity2;
                    }

                    //// UV mode Field:
                    EditorGUILayout.Space();
                    DrawUILine(seperateLine);

                    var ProjectAxis_U = FindAndMarkProperty("_ProjectAxis_U", props);
                    var ProjectAxis_V = FindAndMarkProperty("_ProjectAxis_V", props);

                    var flowmap1Contribution = FindAndMarkProperty("_Flowmap1Contribution", props);
                    Vector4 flow1ctb = flowmap1Contribution.vectorValue;

                    UvMode uvMode = ProjectAxis_U.vectorValue.w == 1.0f ? UvMode.LocalSpaceProjection : UvMode.Uv0;
                    GUILayout.Label(Styles.uvMode1Text, EditorStyles.boldLabel);
                    uvMode = (UvMode)EditorGUILayout.EnumPopup(uvMode);

                    SetUvMode(uvMode, ref ProjectAxis_U, ref ProjectAxis_V);
                    if (uvMode == UvMode.LocalSpaceProjection)
                        flow1ctb.z = EditorGUILayout.Slider("Project Fadeout", flow1ctb.z, 0, 5);
                    else
                        flow1ctb.z = 0.0f;

                    if (mainMode == EffectType.Flow2)
                    {
                        EditorGUILayout.Space();
                        var ProjectAxis_U2 = FindAndMarkProperty("_ProjectAxis_U2", props);
                        var ProjectAxis_V2 = FindAndMarkProperty("_ProjectAxis_V2", props);

                        UvMode uvMode2 = ProjectAxis_U2.vectorValue.w == 1.0f ? UvMode.LocalSpaceProjection : UvMode.Uv0;

                        GUILayout.Label(Styles.uvMode2Text, EditorStyles.boldLabel);
                        uvMode2 = (UvMode)EditorGUILayout.EnumPopup(uvMode2);

                        SetUvMode(uvMode2, ref ProjectAxis_U2, ref ProjectAxis_V2);
                        if (uvMode2 == UvMode.LocalSpaceProjection)
                            flow1ctb.w = EditorGUILayout.Slider("Project Fadeout", flow1ctb.w, 0, 5);
                        else
                            flow1ctb.w = 0.0f;
                    }

                    EditorGUILayout.Space();
                    DrawUILine(seperateLine);

                    // Primary properties
                    GUILayout.Label(Styles.baseTitleText, EditorStyles.boldLabel);

                    var albedoMap = FindAndMarkProperty("_MainTex", props);

                    m_MaterialEditor.TexturePropertySingleLine(Styles.albedoMapText, albedoMap);
                    {

                        var format = new RequestedMapFormat();
                        if (FixTexture(albedoMap.textureValue, format))
                            needFix = true;
                    }

                    MarkProperty("_BumpMapPakced");
                    string text = "Normal Map";
                    var bumpMap = FindAndMarkProperty("_BumpMapPakced", props);
                    m_MaterialEditor.TexturePropertySingleLine(new GUIContent(text), bumpMap);
                    {
                        var format = new RequestedMapFormat();
                        format.sRGB = false;
                        format.mipMode = TextureImporterMipFilter.NormalGlossiness;

                        if (FixTexture(bumpMap.textureValue, format))
                            needFix = true;
                    }

                    MarkProperty("_MetallicRoughnessMap");
                    var metallicMap = FindAndMarkProperty("_MetallicRoughnessMap", props, false);
                    m_MaterialEditor.TexturePropertySingleLine(Styles.metallicMapText, metallicMap);
                    {
                        var format = new RequestedMapFormat();
                        format.sRGB = false;
                        if (maskMode == MaskMode.MaterialIDMode)
                        {
                            format.needAlpha = true;
                        }
                        if (FixTexture(metallicMap.textureValue, format))
                            needFix = true;
                    }
                    /////////////////////////////////////////////Over Layer/////////////////////////////////////////

                    GUILayout.Label(Styles.overlayerTileText, EditorStyles.boldLabel);
                    var blendScale = FindAndMarkProperty("_BlendScale", props);
                    var overMetallic = FindAndMarkProperty("_OverMetallic", props);
                    var overGlossiness = FindAndMarkProperty("_OverGlossiness", props);

                    /////////////////////////////mateiral Mode///////////////////////////////////////////
                    if (maskMode == MaskMode.MaterialIDMode)
                    {
                        var materialColor1 = FindAndMarkProperty("_MatColor1", props);
                        var materialColor2 = FindAndMarkProperty("_MatColor2", props);
                        var isAlbedo1 = FindAndMarkProperty("_isAlbedo1", props);
                        var isAlbedo2 = FindAndMarkProperty("_isAlbedo2", props);
                        m_MaterialEditor.ShaderProperty(materialColor1, Styles.ColorText, indentation);

                        bool isAlbedoColor1 = isAlbedo1.floatValue == 1.0f;
                        EditorGUI.BeginChangeCheck();
                        isAlbedoColor1 = EditorGUILayout.ToggleLeft("is Albedo Color?", isAlbedoColor1);
                        if (EditorGUI.EndChangeCheck())
                        {
                            isAlbedo1.floatValue = isAlbedoColor1? 1.0f : 0.0f;
                        }
                        if(isAlbedoColor1)
                        {
                            material.SetColor("_EmmiColor1", Color.black);
                        }
                        else
                        {
                            material.SetColor("_EmmiColor1", material.GetColor("_MatColor1"));
                        }

                        m_MaterialEditor.ShaderProperty(materialColor2, Styles.ColorText, indentation);

                        bool isAlbedoColor2 = isAlbedo2.floatValue == 1.0f;
                        EditorGUI.BeginChangeCheck();
                        isAlbedoColor2 = EditorGUILayout.ToggleLeft("is Albedo Color?", isAlbedoColor2);
                        if (EditorGUI.EndChangeCheck())
                        {
                            isAlbedo2.floatValue = isAlbedoColor2 ? 1.0f : 0.0f;
                        }
                        if (isAlbedoColor2)
                        {
                            material.SetColor("_EmmiColor2", Color.black);
                        }
                        else
                        {
                            material.SetColor("_EmmiColor2", material.GetColor("_MatColor2"));
                        }
                    }

                    m_MaterialEditor.ShaderProperty(blendScale, Styles.ScaleText, indentation);
                    //m_MaterialEditor.ShaderProperty(overMetallic, overMetallic.displayName, indentation);
                    //m_MaterialEditor.ShaderProperty(overGlossiness, overGlossiness.displayName, indentation);

                    var blendGlossiness = FindAndMarkProperty("_blendGlossiness", props);
                    var blendMetallic = FindAndMarkProperty("_blendMetallic", props);
                    Vector4 blendGlossValue = blendGlossiness.vectorValue;
                    Vector4 blendMetalValue = blendMetallic.vectorValue;
                    if (maskMode == MaskMode.SingelGradientChannel)
                    {
                        EditorGUILayout.LabelField("Channel 0:", EditorStyles.boldLabel);
                        EditorGUI.indentLevel += 2;
                        blendGlossValue.x = EditorGUILayout.Slider("Glossiness", blendGlossValue.x, 0, 1);
                        blendMetalValue.x = EditorGUILayout.Slider("Metallic", blendMetalValue.x, 0, 1);
                        EditorGUI.indentLevel -= 2;
                    }
                    else if(maskMode == MaskMode.DualGradientChannels)
                    {
                        EditorGUILayout.LabelField("Channel 0:", EditorStyles.boldLabel);
                        EditorGUI.indentLevel += 2;
                        blendGlossValue.x = EditorGUILayout.Slider("Glossiness", blendGlossValue.x, 0, 1);
                        blendMetalValue.x = EditorGUILayout.Slider("Metallic", blendMetalValue.x, 0, 1);
                        EditorGUI.indentLevel -= 2;
                        EditorGUILayout.Space();
                        EditorGUILayout.LabelField("Channel 1:", EditorStyles.boldLabel);
                        EditorGUI.indentLevel += 2;
                        blendGlossValue.y = EditorGUILayout.Slider("Glossiness", blendGlossValue.y, 0, 1);
                        blendMetalValue.y = EditorGUILayout.Slider("Metallic", blendMetalValue.y, 0, 1);
                        EditorGUI.indentLevel -= 2;

                    }
                    else if(maskMode == MaskMode.MaterialIDMode)
                    {
                        EditorGUILayout.LabelField("ID 0:", EditorStyles.boldLabel);
                        EditorGUI.indentLevel += 2;
                        blendGlossValue.x = EditorGUILayout.Slider("Glossiness", blendGlossValue.x, 0, 1);
                        blendMetalValue.x = EditorGUILayout.Slider("Metallic", blendMetalValue.x, 0, 1);
                        EditorGUI.indentLevel -= 2;
                        EditorGUILayout.Space();
                        EditorGUILayout.LabelField("ID 1:", EditorStyles.boldLabel);
                        EditorGUI.indentLevel += 2;
                        blendGlossValue.y = EditorGUILayout.Slider("Glossiness", blendGlossValue.y, 0, 1);
                        blendMetalValue.y = EditorGUILayout.Slider("Metallic", blendMetalValue.y, 0, 1);
                        EditorGUI.indentLevel -= 2;
                        EditorGUILayout.Space();
                        EditorGUILayout.LabelField("ID 2:", EditorStyles.boldLabel);
                        EditorGUI.indentLevel += 2;
                        blendGlossValue.z = EditorGUILayout.Slider("Glossiness", blendGlossValue.z, 0, 1);
                        blendMetalValue.z = EditorGUILayout.Slider("Metallic", blendMetalValue.z, 0, 1);
                        EditorGUI.indentLevel -= 2;
                        EditorGUILayout.Space();
                        EditorGUILayout.LabelField("ID 3:", EditorStyles.boldLabel);
                        EditorGUI.indentLevel+=2;
                        blendGlossValue.w = EditorGUILayout.Slider("Glossiness", blendGlossValue.w, 0, 1);
                        blendMetalValue.w = EditorGUILayout.Slider("Metallic", blendMetalValue.w, 0, 1);
                        EditorGUI.indentLevel -= 2;
                    }

                    blendGlossiness.vectorValue = blendGlossValue;
                    blendMetallic.vectorValue = blendMetalValue;
                    overGlossiness.floatValue = blendGlossiness.vectorValue.x;
                    overMetallic.floatValue = blendMetallic.vectorValue.x;

                    /////////////////////////////////////////////Main  Effect/////////////////////////////////////////
                    EditorGUILayout.Space();
                    DrawUILine(seperateLine);

                    GUILayout.Label(Styles.flowmapTitleText, EditorStyles.boldLabel);

                    if (mainMode == EffectType.Flow1 || mainMode == EffectType.Flow2)
                    {
                        var flowMap1 = FindAndMarkProperty("_Flowmap1", props, false);
                        m_MaterialEditor.TexturePropertySingleLine(Styles.flowmapText1, flowMap1);
                        {

                            var format = new RequestedMapFormat();
                            format.needTilingOffset = true;
                            if (FixTexture(flowMap1.textureValue, format))
                                needFix = true;
                        }

                        ////////////////////flowmap channel mode///////////////////////////////////////
                        var channelR = FindAndMarkProperty("_FlowChannelR", props, false);
                        var channelG = FindAndMarkProperty("_FlowChannelG", props, false);
                        var channelB = FindAndMarkProperty("_FlowChannelB", props, false);
                        var channelOption = FindProperty("_ChannelOption", props);
                        ColorChannelLayout(channelOption,  material, channelR, channelG, channelB, 1);

                        m_MaterialEditor.TextureScaleOffsetProperty(flowMap1);
                        var flowScale1 = FindAndMarkProperty("_FlowmapScale1", props);
                        var flowSpeed1 = FindAndMarkProperty("_FlowmapSpeed1", props);
                        var flowNormalDistort1 = FindAndMarkProperty("_FlowmapNormalDistort1", props);

                        m_MaterialEditor.ShaderProperty(flowScale1, Styles.ScaleText, indentation);
                        m_MaterialEditor.ShaderProperty(flowSpeed1, Styles.flowSpeedText, indentation);
                        m_MaterialEditor.ShaderProperty(flowNormalDistort1, Styles.NormalDistortText, indentation);

                        var flowDirectionRotation1 = FindAndMarkProperty("_FlowRotation", props);
                        var flowDirectionRotationSinCos1 = FindAndMarkProperty("_FlowRotationSinCos", props);
                        Vector4 dirRot = flowDirectionRotation1.vectorValue;
                        float dirRot1 = dirRot.x;
                        float cos1 = 0;
                        float sin1 = 0;
                        dirRot1 = Rotation2DGUI(dirRot1, ref cos1, ref sin1);
                        dirRot.x = dirRot1;
                        Vector4 dirRotTri1 = flowDirectionRotationSinCos1.vectorValue;
                        dirRotTri1.x = sin1;
                        dirRotTri1.y = cos1;
                        flowDirectionRotation1.vectorValue = dirRot;
                        flowDirectionRotationSinCos1.vectorValue = dirRotTri1;

                        float flowmap1AlbedoContribution = EditorGUILayout.Slider("Albedo Contribution", flow1ctb.x, 0, 1);
                        float flowmap1EmissionContribution = EditorGUILayout.Slider("Emission Contribution", flow1ctb.y, 0, 1);
                        flow1ctb.x = flowmap1AlbedoContribution;
                        flow1ctb.y = flowmap1EmissionContribution;
                        flowmap1Contribution.vectorValue = flow1ctb;

                        if (mainMode == EffectType.Flow2)
                        {
                            var contentEffectOption1 = FindAndMarkProperty("_ContentEffectOption1", props, false);
                            EditorGUI.BeginChangeCheck();
                            var option = (int)contentEffectOption1.floatValue;

                            option = EditorGUILayout.Popup(Styles.contentOptions, option, flow1Options);
                            option = (int)Enum.Parse(typeof(Flow1Type), flow1Options[option]);

                            if (EditorGUI.EndChangeCheck())
                            {
                                m_MaterialEditor.RegisterPropertyChangeUndo(" Content Option 1 Change");
                                contentEffectOption1.floatValue = (float)option;
                            }
                            var contentConfig = GetSubEffectConfig(EffectType.Flow1, option);


                            if (contentConfig.isBreath || contentConfig.isFlake)
                            {

                                var flakeScale = FindAndMarkProperty("_Flow1FlakeScale", props);
                                var flakeSpeed1 = FindAndMarkProperty("_Flow1FlakeSpeed1", props);
                                var flakeOffset = FindAndMarkProperty("_Flow1FlakeOffset", props);
                                var flakeThreshold = FindAndMarkProperty("_Flow1FlakeThreshold", props);


                                if (contentConfig.isFlake)
                                {
                                    GUILayout.Label(Styles.flakeTitleText, EditorStyles.boldLabel);
                                }
                                else
                                {
                                    GUILayout.Label(Styles.breathTitleText, EditorStyles.boldLabel);
                                }

                                m_MaterialEditor.ShaderProperty(flakeScale, Styles.ScaleText, indentation);
                                m_MaterialEditor.ShaderProperty(flakeSpeed1, Styles.SpeedText, indentation);
                                m_MaterialEditor.ShaderProperty(flakeOffset, Styles.OffsetText, indentation);//flake 2 offset
                                m_MaterialEditor.ShaderProperty(flakeThreshold, Styles.ThresholdText, indentation);//flake 2 threshold

                                if (contentConfig.isFlake)
                                {
                                    var flakeSpeed2 = FindAndMarkProperty("_Flow1FlakeSpeed2", props);
                                    m_MaterialEditor.ShaderProperty(flakeSpeed2, Styles.SpeedText2, indentation);
                                }

                            }
                            if (contentConfig.isHSV)
                            {
                                GUILayout.Label(Styles.hsvTitleText, EditorStyles.boldLabel);
                                var hsvSpeed = FindAndMarkProperty("_Flow1HSVSpeed", props);
                                m_MaterialEditor.ShaderProperty(hsvSpeed, Styles.SpeedText, indentation);
                            }
                            SetKeyword(material, "EFX_HSV_0", contentConfig.isHSV);

                            if (contentConfig.isRamp)
                            {
                                GUILayout.Label(Styles.rampTitleText, EditorStyles.boldLabel);
                                var rampScale = FindAndMarkProperty("_Flow1RampScale", props);
                                var rampSpeed = FindAndMarkProperty("_Flow1RampSpeed", props);
                                var rampColor1 = FindAndMarkProperty("_Flow1RampColor1", props);
                                var rampColor2 = FindAndMarkProperty("_Flow1RampColor2", props);
                                var rampThreshold = FindAndMarkProperty("_Flow1RampThreshold", props);

                                m_MaterialEditor.ShaderProperty(rampScale, Styles.ScaleText, indentation);
                                m_MaterialEditor.ShaderProperty(rampSpeed, Styles.SpeedText, indentation);
                                m_MaterialEditor.ShaderProperty(rampColor1, Styles.ColorText, indentation);
                                m_MaterialEditor.ShaderProperty(rampColor2, Styles.ColorText, indentation);
                                m_MaterialEditor.ShaderProperty(rampThreshold, Styles.ThresholdText, indentation);
                            }

                            if (contentConfig.isFlippbook)
                            {
                                DrawFlipbookGUI(material, contentConfig.isFlippbook, props, "_FlipbookParam0");
                            }
                            SetKeyword(material, Flipbook0Keyword, contentConfig.isFlippbook);

                            Color col00 = Color.black, col01 = Color.black;
                            float isTwoBreath0 = Bool2Float( contentConfig.isFlake);
                            float isRamp0 = Bool2Float( contentConfig.isRamp);

                            float flakeSpeed00 = 0, flakeSpeed01 = 0;
                            float flakeOffset00 = 0, flakeOffset01 = 0;
                            float flakeThreshold00 = 0, flakeThreshold01 = 0;
                            float flakeScale00 = 0, flakeScale01 = 1.0f;

                            bool isBreath = contentConfig.isBreath;
                            bool isFlake = contentConfig.isFlake;
                            bool isRamp = contentConfig.isRamp;

                            if (isBreath)
                            {
                                var flakeScale = FindAndMarkProperty("_Flow1FlakeScale", props);
                                var flakeSpeed1 = FindAndMarkProperty("_Flow1FlakeSpeed1", props);
                                var flakeOffset = FindAndMarkProperty("_Flow1FlakeOffset", props);
                                var flakeThreshold = FindAndMarkProperty("_Flow1FlakeThreshold", props);

                                flakeSpeed00 = flakeSpeed1.floatValue;
                                flakeOffset00 = flakeOffset.floatValue;
                                flakeThreshold00 = flakeThreshold.floatValue;
                                flakeScale00 = flakeScale.floatValue;
                            }
                            if(isFlake)
                            {
                                var flakeScale = FindAndMarkProperty("_Flow1FlakeScale", props);
                                var flakeSpeed1 = FindAndMarkProperty("_Flow1FlakeSpeed1", props);
                                var flakeOffset = FindAndMarkProperty("_Flow1FlakeOffset", props);
                                var flakeThreshold = FindAndMarkProperty("_Flow1FlakeThreshold", props);
                                var flakeSpeed2 = FindAndMarkProperty("_Flow1FlakeSpeed2", props);

                                flakeSpeed00 = flakeSpeed1.floatValue;
                                flakeSpeed01 = flakeSpeed2.floatValue;
                                flakeOffset00 = flakeOffset.floatValue;
                                flakeThreshold00 = flakeThreshold.floatValue;
                                flakeScale00 = flakeScale.floatValue;
                                flakeScale01 = 1.0f;
                            }
                            if (isRamp)
                            {

                                var rampScale = FindAndMarkProperty("_Flow1RampScale", props);
                                var rampSpeed = FindAndMarkProperty("_Flow1RampSpeed", props);
                                var rampColor1 = FindAndMarkProperty("_Flow1RampColor1", props);
                                var rampColor2 = FindAndMarkProperty("_Flow1RampColor2", props);
                                var rampThreshold = FindAndMarkProperty("_Flow1RampThreshold", props);

                                col00 = rampColor1.colorValue;
                                col01 = rampColor2.colorValue;
                                flakeSpeed00 = rampSpeed.floatValue;
                                flakeThreshold00 = rampThreshold.floatValue;
                                flakeScale00 = rampScale.floatValue;
                            }

                            if (isBreath || isFlake || isRamp)
                                material.EnableKeyword("EFX_FLAKE_0");
                            else
                                material.DisableKeyword("EFX_FLAKE_0");

                            SetFlakeEfxMaterial(material, 0,
                            col00, col01, isTwoBreath0, isRamp0,
                            flakeSpeed00,  flakeSpeed01,  flakeOffset00,  flakeOffset01,
                            flakeThreshold00,  flakeThreshold01,  flakeScale00,  flakeScale01);
                        }
                    }

                    if (mainMode == EffectType.Flow2)
                    {
                        var flowMap2 = FindAndMarkProperty("_Flowmap2", props, false);

                        m_MaterialEditor.TexturePropertySingleLine(Styles.flowmapText2, flowMap2);
                        {

                            var format = new RequestedMapFormat();
                            format.needTilingOffset = true;
                            if (FixTexture(flowMap2.textureValue, format))
                                needFix = true;
                        }

                        ////////////////////flowmap channel mode///////////////////////////////////////
                        var channelR2 = FindAndMarkProperty("_FlowChannelR2", props, false);
                        var channelG2 = FindAndMarkProperty("_FlowChannelG2", props, false);
                        var channelB2 = FindAndMarkProperty("_FlowChannelB2", props, false);
                        var channelOption2 = FindProperty("_ChannelOption2", props);

                        ColorChannelLayout(channelOption2,material, channelR2, channelG2, channelB2,2);

                        m_MaterialEditor.TextureScaleOffsetProperty(flowMap2);

                        var flowScale2 = FindAndMarkProperty("_FlowmapScale2", props);
                        var flowSpeed2 = FindAndMarkProperty("_FlowmapSpeed2", props);

                        var flowDirectionRotation2 = FindAndMarkProperty("_FlowRotation", props);
                        var flowDirectionRotationSinCos2 = FindAndMarkProperty("_FlowRotationSinCos", props);
                        Vector4 dirRot = flowDirectionRotation2.vectorValue;
                        float dirRot2 = dirRot.y;
                        float cos2 = 0;
                        float sin2 = 0;
                        dirRot2 = Rotation2DGUI(dirRot2, ref cos2, ref sin2);
                        dirRot.y = dirRot2;
                        Vector4 dirRotTri1 = flowDirectionRotationSinCos2.vectorValue;
                        dirRotTri1.z = sin2;
                        dirRotTri1.w = cos2;
                        flowDirectionRotation2.vectorValue = dirRot;
                        flowDirectionRotationSinCos2.vectorValue = dirRotTri1;

                        var flowmap2Contribution = FindAndMarkProperty("_Flowmap2Contribution", props);
                        Vector4 flow2ctb = flowmap2Contribution.vectorValue;
                        float flowmap2AlbedoContribution = EditorGUILayout.Slider("Albedo Contribution", flow2ctb.x, 0, 1);
                        float flowmap2EmissionContribution = EditorGUILayout.Slider("Emission Contribution", flow2ctb.y, 0, 1);
                        flow2ctb.x = flowmap2AlbedoContribution;
                        flow2ctb.y = flowmap2EmissionContribution;
                        flowmap2Contribution.vectorValue = flow2ctb;

                        var flowNormalDistort2 = FindAndMarkProperty("_FlowmapNormalDistort2", props);

                        m_MaterialEditor.ShaderProperty(flowScale2, Styles.ScaleText, indentation);
                        m_MaterialEditor.ShaderProperty(flowSpeed2, Styles.flowSpeedText, indentation);
                        m_MaterialEditor.ShaderProperty(flowNormalDistort2, Styles.NormalDistortText, indentation);

                        var contentEffectOption2 = FindAndMarkProperty("_ContentEffectOption2", props, false);
                        EditorGUI.BeginChangeCheck();
                        var option = (int)contentEffectOption2.floatValue;

                        option = EditorGUILayout.Popup(Styles.contentOptions, option, flow1Options);
                        option = (int)Enum.Parse(typeof(Flow1Type), flow1Options[option]);

                        if (EditorGUI.EndChangeCheck())
                        {
                            m_MaterialEditor.RegisterPropertyChangeUndo(" Content Option 2 Change");
                            contentEffectOption2.floatValue = (float)option;
                        }
                        var contentConfig = GetSubEffectConfig(EffectType.Flow1, option);

                        // set flake1 options:
                        var flake1ptionProp = FindAndMarkProperty("_FlakeOption1", props);
                        MarkFlakeCompoundEffectOption(contentConfig, ref flake1ptionProp);

                        if (contentConfig.isBreath || contentConfig.isFlake)
                        {

                            var flakeScale = FindAndMarkProperty("_Flow2FlakeScale", props);
                            var flakeSpeed1 = FindAndMarkProperty("_Flow2FlakeSpeed1", props);
                            var flakeOffset = FindAndMarkProperty("_Flow2FlakeOffset", props);
                            var flakeThreshold = FindAndMarkProperty("_Flow2FlakeThreshold", props);


                            if (contentConfig.isFlake)
                            {
                                GUILayout.Label(Styles.flakeTitleText, EditorStyles.boldLabel);
                            }
                            else
                            {
                                GUILayout.Label(Styles.breathTitleText, EditorStyles.boldLabel);
                            }

                            m_MaterialEditor.ShaderProperty(flakeScale, Styles.ScaleText, indentation);
                            m_MaterialEditor.ShaderProperty(flakeSpeed1, Styles.SpeedText, indentation);
                            m_MaterialEditor.ShaderProperty(flakeOffset, Styles.OffsetText, indentation);//flake 2 offset
                            m_MaterialEditor.ShaderProperty(flakeThreshold, Styles.ThresholdText, indentation);//flake 2 threshold

                            if (contentConfig.isFlake)
                            {
                                var flakeSpeed2 = FindAndMarkProperty("_Flow2FlakeSpeed2", props);
                                m_MaterialEditor.ShaderProperty(flakeSpeed2, Styles.SpeedText2, indentation);
                            }

                        }

                        if (contentConfig.isHSV)
                        {
                            GUILayout.Label(Styles.hsvTitleText, EditorStyles.boldLabel);
                            var hsvSpeed = FindAndMarkProperty("_Flow2HSVSpeed", props);
                            m_MaterialEditor.ShaderProperty(hsvSpeed, Styles.SpeedText, indentation);
                        }
                        SetKeyword(material, "EFX_HSV_1", contentConfig.isHSV);

                        if (contentConfig.isRamp)
                        {
                            GUILayout.Label(Styles.rampTitleText, EditorStyles.boldLabel);
                            var rampScale = FindAndMarkProperty("_Flow2RampScale", props);
                            var rampSpeed = FindAndMarkProperty("_Flow2RampSpeed", props);
                            var rampColor1 = FindAndMarkProperty("_Flow2RampColor1", props);
                            var rampColor2 = FindAndMarkProperty("_Flow2RampColor2", props);
                            var rampThreshold = FindAndMarkProperty("_Flow2RampThreshold", props);

                            m_MaterialEditor.ShaderProperty(rampScale, Styles.ScaleText, indentation);
                            m_MaterialEditor.ShaderProperty(rampSpeed, Styles.SpeedText, indentation);
                            m_MaterialEditor.ShaderProperty(rampColor1, Styles.ColorText, indentation);
                            m_MaterialEditor.ShaderProperty(rampColor2, Styles.ColorText, indentation);
                            m_MaterialEditor.ShaderProperty(rampThreshold, Styles.ThresholdText, indentation);

                        }

                        if (contentConfig.isFlippbook)
                        {
                            DrawFlipbookGUI(material, contentConfig.isFlippbook, props, "_FlipbookParam1");
                        }
                        SetKeyword(material, Flipbook1Keyword, contentConfig.isFlippbook);



                        ////////////////////////////////////// Set Flake Compound Material params//////////////////////////////
                        Color col00 = Color.black, col01 = Color.black;
                        float isTwoBreath0 = Bool2Float(contentConfig.isFlake);
                        float isRamp0 = Bool2Float(contentConfig.isRamp);

                        float flakeSpeed00 = 0, flakeSpeed01 = 0;
                        float flakeOffset00 = 0, flakeOffset01 = 0;
                        float flakeThreshold00 = 0, flakeThreshold01 = 0;
                        float flakeScale00 = 0, flakeScale01 = 1.0f;

                        bool isBreath = contentConfig.isBreath;
                        bool isFlake = contentConfig.isFlake;
                        bool isRamp = contentConfig.isRamp;

                        if (isBreath)
                        {
                            var flakeScale = FindAndMarkProperty("_Flow2FlakeScale", props);
                            var flakeSpeed1 = FindAndMarkProperty("_Flow2FlakeSpeed1", props);
                            var flakeOffset = FindAndMarkProperty("_Flow2FlakeOffset", props);
                            var flakeThreshold = FindAndMarkProperty("_Flow2FlakeThreshold", props);

                            flakeSpeed00 = flakeSpeed1.floatValue;
                            flakeOffset00 = flakeOffset.floatValue;
                            flakeThreshold00 = flakeThreshold.floatValue;
                            flakeScale00 = flakeScale.floatValue;
                        }
                        if (isFlake)
                        {
                            var flakeScale = FindAndMarkProperty("_Flow2FlakeScale", props);
                            var flakeSpeed1 = FindAndMarkProperty("_Flow2FlakeSpeed1", props);
                            var flakeOffset = FindAndMarkProperty("_Flow2FlakeOffset", props);
                            var flakeThreshold = FindAndMarkProperty("_Flow2FlakeThreshold", props);
                            var flakeSpeed2 = FindAndMarkProperty("_Flow2FlakeSpeed2", props);

                            flakeSpeed00 = flakeSpeed1.floatValue;
                            flakeSpeed01 = flakeSpeed2.floatValue;
                            flakeOffset00 = flakeOffset.floatValue;
                            flakeThreshold00 = flakeThreshold.floatValue;
                            flakeScale00 = flakeScale.floatValue;
                            flakeScale01 = 1.0f;
                        }
                        if (isRamp)
                        {
                            var rampScale = FindAndMarkProperty("_Flow2RampScale", props);
                            var rampSpeed = FindAndMarkProperty("_Flow2RampSpeed", props);
                            var rampColor1 = FindAndMarkProperty("_Flow2RampColor1", props);
                            var rampColor2 = FindAndMarkProperty("_Flow2RampColor2", props);
                            var rampThreshold = FindAndMarkProperty("_Flow2RampThreshold", props);

                            col00 = rampColor1.colorValue;
                            col01 = rampColor2.colorValue;
                            flakeSpeed00 = rampSpeed.floatValue;
                            flakeThreshold00 = rampThreshold.floatValue;
                            flakeScale00 = rampScale.floatValue;
                        }

                        if (isBreath || isFlake || isRamp)
                            material.EnableKeyword("EFX_FLAKE_1");
                        else
                            material.DisableKeyword("EFX_FLAKE_1");

                        SetFlakeEfxMaterial(material, 1,
                        col00, col01, isTwoBreath0, isRamp0,
                        flakeSpeed00, flakeSpeed01, flakeOffset00, flakeOffset01,
                        flakeThreshold00, flakeThreshold01, flakeScale00, flakeScale01);
                    }

                    /////////////////////////////////////////////Sub Effect/////////////////////////////////////////
                    EditorGUILayout.Space();
                    DrawUILine(seperateLine);

                    if(!(mainMode == EffectType.Flow2 && (maskMode == MaskMode.MaterialIDMode)))
                    {
                        GUILayout.Label(Styles.subTitleText, EditorStyles.boldLabel);
                        var config = SubEffectPopup(mainMode);

                        var flakeOption0Prop = FindAndMarkProperty("_FlakeOption0", props);
                        // set flake0 options:
                        MarkFlakeCompoundEffectOption(config, ref flakeOption0Prop);

                        if(mainMode == EffectType.Flow1)
                        {
                            if (config.isBreath || config.isFlake)
                            {

                                var flakeScale = FindAndMarkProperty("_Flow1FlakeScale", props);
                                var flakeSpeed1 = FindAndMarkProperty("_Flow1FlakeSpeed1", props);
                                var flakeOffset = FindAndMarkProperty("_Flow1FlakeOffset", props);
                                var flakeThreshold = FindAndMarkProperty("_Flow1FlakeThreshold", props);


                                if (config.isFlake)
                                {
                                    GUILayout.Label(Styles.flakeTitleText, EditorStyles.boldLabel);
                                }
                                else
                                {
                                    GUILayout.Label(Styles.breathTitleText, EditorStyles.boldLabel);
                                }

                                m_MaterialEditor.ShaderProperty(flakeScale, Styles.ScaleText, indentation);
                                m_MaterialEditor.ShaderProperty(flakeSpeed1, Styles.SpeedText, indentation);
                                m_MaterialEditor.ShaderProperty(flakeOffset, Styles.OffsetText, indentation);//flake 2 offset
                                m_MaterialEditor.ShaderProperty(flakeThreshold, Styles.ThresholdText, indentation);//flake 2 threshold

                                if (config.isFlake)
                                {
                                    var flakeSpeed2 = FindAndMarkProperty("_Flow1FlakeSpeed2", props);
                                    m_MaterialEditor.ShaderProperty(flakeSpeed2, Styles.SpeedText2, indentation);
                                }

                            }

                            if (config.isHSV)
                            {
                                GUILayout.Label(Styles.hsvTitleText, EditorStyles.boldLabel);
                                var hsvSpeed = FindAndMarkProperty("_Flow1HSVSpeed", props);
                                m_MaterialEditor.ShaderProperty(hsvSpeed, Styles.SpeedText, indentation);

                            }
                            SetKeyword(material, "EFX_HSV_0", config.isHSV);

                            if (config.isRamp)
                            {
                                GUILayout.Label(Styles.rampTitleText, EditorStyles.boldLabel);
                                var rampScale = FindAndMarkProperty("_Flow1RampScale", props);
                                var rampSpeed = FindAndMarkProperty("_Flow1RampSpeed", props);
                                var rampThreshold = FindAndMarkProperty("_Flow1RampThreshold", props);

                                var rampColor1 = FindAndMarkProperty("_Flow1RampColor1", props);
                                var rampColor2 = FindAndMarkProperty("_Flow1RampColor2", props);


                                m_MaterialEditor.ShaderProperty(rampScale, Styles.ScaleText, indentation);
                                m_MaterialEditor.ShaderProperty(rampSpeed, Styles.SpeedText, indentation);
                                m_MaterialEditor.ShaderProperty(rampColor1, Styles.ColorText, indentation);
                                m_MaterialEditor.ShaderProperty(rampColor2, Styles.ColorText, indentation);
                                m_MaterialEditor.ShaderProperty(rampThreshold, Styles.ThresholdText, indentation);
                            }

                            if (config.isFlippbook)
                            {
                                DrawFlipbookGUI(material, config.isFlippbook, props, "_FlipbookParam0");
                            }
                            SetKeyword(material, Flipbook0Keyword, config.isFlippbook);

                            ////////////////////////////////////// Set Flake Compound Material params //////////////////////////////
                            Color col00 = Color.black, col01 = Color.black;
                            float isTwoBreath0 = Bool2Float(config.isFlake);
                            float isRamp0 = Bool2Float(config.isRamp);

                            float flakeSpeed00 = 0, flakeSpeed01 = 0;
                            float flakeOffset00 = 0, flakeOffset01 = 0;
                            float flakeThreshold00 = 0, flakeThreshold01 = 0;
                            float flakeScale00 = 0, flakeScale01 = 1.0f;

                            bool isBreath = config.isBreath;
                            bool isFlake = config.isFlake;
                            bool isRamp = config.isRamp;

                            if (isBreath)
                            {
                                var flakeScale = FindAndMarkProperty("_Flow1FlakeScale", props);
                                var flakeSpeed1 = FindAndMarkProperty("_Flow1FlakeSpeed1", props);
                                var flakeOffset = FindAndMarkProperty("_Flow1FlakeOffset", props);
                                var flakeThreshold = FindAndMarkProperty("_Flow1FlakeThreshold", props);

                                flakeSpeed00 = flakeSpeed1.floatValue;
                                flakeOffset00 = flakeOffset.floatValue;
                                flakeThreshold00 = flakeThreshold.floatValue;
                                flakeScale00 = flakeScale.floatValue;
                            }
                            if (isFlake)
                            {
                                var flakeScale = FindAndMarkProperty("_Flow1FlakeScale", props);
                                var flakeSpeed1 = FindAndMarkProperty("_Flow1FlakeSpeed1", props);
                                var flakeOffset = FindAndMarkProperty("_Flow1FlakeOffset", props);
                                var flakeThreshold = FindAndMarkProperty("_Flow1FlakeThreshold", props);
                                var flakeSpeed2 = FindAndMarkProperty("_Flow1FlakeSpeed2", props);

                                flakeSpeed00 = flakeSpeed1.floatValue;
                                flakeSpeed01 = flakeSpeed2.floatValue;
                                flakeOffset00 = flakeOffset.floatValue;
                                flakeThreshold00 = flakeThreshold.floatValue;
                                flakeScale00 = flakeScale.floatValue;
                                flakeScale01 = 1.0f;
                            }
                            if (isRamp)
                            {
                                var rampScale = FindAndMarkProperty("_Flow1RampScale", props);
                                var rampSpeed = FindAndMarkProperty("_Flow1RampSpeed", props);
                                var rampThreshold = FindAndMarkProperty("_Flow1RampThreshold", props);
                                var rampColor1 = FindAndMarkProperty("_Flow1RampColor1", props);
                                var rampColor2 = FindAndMarkProperty("_Flow1RampColor2", props);

                                col00 = rampColor1.colorValue;
                                col01 = rampColor2.colorValue;
                                flakeSpeed00 = rampSpeed.floatValue;
                                flakeThreshold00 = rampThreshold.floatValue;
                                flakeScale00 = rampScale.floatValue;
                            }

                            if (isBreath || isFlake || isRamp)
                                material.EnableKeyword("EFX_FLAKE_0");
                            else
                                material.DisableKeyword("EFX_FLAKE_0");

                            SetFlakeEfxMaterial(material, 0,
                            col00, col01, isTwoBreath0, isRamp0,
                            flakeSpeed00, flakeSpeed01, flakeOffset00, flakeOffset01,
                            flakeThreshold00, flakeThreshold01, flakeScale00, flakeScale01);
                            ////////////////////////////////////// Set Flake Compound //////////////////////////////
                        }

                        if (config.isAdd)
                        {
                            GUILayout.Label(Styles.addTitleText, EditorStyles.boldLabel);
                            var addScale = FindAndMarkProperty("_AddScale", props);
                            m_MaterialEditor.ShaderProperty(addScale, Styles.ScaleText, indentation);
                            material.SetFloat("_MulScale", 0);
                            material.SetFloat("_CoverScale", 0);
                        }

                        if (config.isAlphaCover)
                        {
                            GUILayout.Label(Styles.alphaTitleText, EditorStyles.boldLabel);
                            var coverScale = FindAndMarkProperty("_CoverScale", props);
                            m_MaterialEditor.ShaderProperty(coverScale, Styles.ScaleText, indentation);
                            material.SetFloat("_MulScale", 0);
                            material.SetFloat("_AddScale", 0);
                        }

                        if (config.isMul)
                        {
                            GUILayout.Label(Styles.mulTitleText, EditorStyles.boldLabel);
                            var mulScale = FindAndMarkProperty("_MulScale", props);
                            m_MaterialEditor.ShaderProperty(mulScale, Styles.ScaleText, indentation);
                            material.SetFloat("_AddScale", 0);
                            material.SetFloat("_CoverScale", 0);
                        }

                        if (config.isDistort)
                        {
                            GUILayout.Label(Styles.distortTitleText, EditorStyles.boldLabel);
                            var flowDistort = FindAndMarkProperty("_FlowDistort", props);
                            m_MaterialEditor.ShaderProperty(flowDistort, Styles.DistortText, indentation);


                        }

                        if (config.isParallax)
                        {
                            GUILayout.Label(Styles.parallaxTitleText, EditorStyles.boldLabel);
                            var flowParallax = FindAndMarkProperty("_FlowParallaxScale", props);
                            m_MaterialEditor.ShaderProperty(flowParallax, Styles.ParallaxText, indentation);
                        }

                        EditorGUILayout.Space();
                        DrawUILine(seperateLine);
                    }


                    if(!(maskMode == MaskMode.MaterialIDMode))
                    {
                        GUILayout.Label(Styles.emissionTitleText, EditorStyles.boldLabel);
                        var emissionTintColor = FindAndMarkProperty("_EmissionTintColor", props);
                        m_MaterialEditor.ShaderProperty(emissionTintColor, Styles.EmissionTintText, indentation);
                        EditorGUILayout.Space();
                        DrawUILine(seperateLine);
                    }


                    return needFix;
                }
                */

        public static float Bool2Float(bool val)
        {
            return val ? 1.0f : 0.0f;
        }

        
        public static void SetFlakeEfxMaterial(Material mat, int index, 
            Color col0, Color col1, float isTwoBreath, float isRamp, 
            float flakeSpeed0, float flakeSpeed1, float flakeOffset0, float flakeOffset1,
            float flakeThreshold0, float flakeThreshold1, float flakeScale0, float flakeScale1)
        {
            // these value is passed with vector4 property . A linear transform is required.
            col0 = col0.linear; 
            col1 = col1.linear;

            mat.SetVector("_Efx" + index + "_Data0", new Vector4(col0.r, col0.g, col0.b, isTwoBreath));
            mat.SetVector("_Efx" + index + "_Data1", new Vector4(col1.r, col1.g, col1.b, isRamp));
            mat.SetVector("_Efx" + index + "_Data2", new Vector4(flakeSpeed0, flakeSpeed1, flakeOffset0, flakeOffset1));
            mat.SetVector("_Efx" + index + "_Data3", new Vector4(flakeThreshold0, flakeThreshold1, flakeScale0, flakeScale1));
        }

        public static void SetTextureRotation(MaterialProperty directionProp, MaterialProperty directionSinCosProp, bool flowmap_1or_2, string UVRotationString)
        {
            Vector4 dirRot = directionProp.vectorValue;
            Vector4 dirRotTri = directionSinCosProp.vectorValue;
            float dirRotVal1 = dirRot.x;
            float dirRotVal2 = dirRot.y;
            float cos1 = 0;
            float sin1 = 0;
            float cos2 = 0;
            float sin2 = 0;

            if (flowmap_1or_2 == true)
            {
                dirRotVal1 = EditorGUILayout.FloatField(UVRotationString, dirRotVal1);
                dirRotVal1 = Rotation2DGUI(dirRotVal1, ref cos1, ref sin1);
                dirRotTri.x = sin1;
                dirRotTri.y = cos1;
            }
            else
            {
                dirRotVal2 = EditorGUILayout.FloatField(UVRotationString, dirRotVal2);
                dirRotVal2 = Rotation2DGUI(dirRotVal2, ref cos2, ref sin2);
                dirRotTri.z = sin2;
                dirRotTri.w = cos2;
            }
            
            dirRot.x = dirRotVal1;
            dirRot.y = dirRotVal2;
            directionProp.vectorValue = dirRot;
            directionSinCosProp.vectorValue = dirRotTri;
        }

        void MarkFlakeCompoundEffectOption(EffectConfig efxCfg, ref MaterialProperty efxOptionProp)
        {
            Vector4 flakeOption = Vector4.zero;
            if (!(efxCfg.isBreath || efxCfg.isFlake || efxCfg.isRamp))
                flakeOption.x = 1.0f;   // no effect flag.
            if (efxCfg.isFlake)
                flakeOption.y = 1.0f;   // flake (two breath) effect flag.
            if (efxCfg.isRamp)
                flakeOption.z = 1.0f;   // ramp effect flag.
            efxOptionProp.vectorValue = flakeOption;
        }

        void GetFlowEffect(Material material, MaterialProperty[] props, bool needFix, int indentation, Vector4 flow1ctb, MaterialProperty flowmap1Contribution, bool hasFlowmap2)
        {
            ///Avoid adding keywords, borrowed keywords, iridescent effects
            material.DisableKeyword("_USEEMISSIONMASK");
            GUILayout.Label(Styles.flowmapTitleText, EditorStyles.boldLabel);

            var flowMap1 = FindAndMarkProperty("_Flowmap1", props, false);
            m_MaterialEditor.TexturePropertySingleLine(Styles.flowmapText1, flowMap1);
            {
                var format = new RequestedMapFormat();
                format.needTilingOffset = true;
                if (FixTexture(flowMap1.textureValue, format))
                    needFix = true;
            }

            ////////////////////flowmap channel mode///////////////////////////////////////
            var channelR = FindAndMarkProperty("_FlowChannelR", props, false);
            var channelG = FindAndMarkProperty("_FlowChannelG", props, false);
            var channelB = FindAndMarkProperty("_FlowChannelB", props, false);
            var channelOption = FindProperty("_ChannelOption", props);
            ColorChannelLayout(channelOption, material, channelR, channelG, channelB, 1);

            m_MaterialEditor.TextureScaleOffsetProperty(flowMap1);
            var flowScale1 = FindAndMarkProperty("_FlowmapScale1", props);
            var flowSpeed1 = FindAndMarkProperty("_FlowmapSpeed1", props);
            var flowNormalDistort1 = FindAndMarkProperty("_FlowmapNormalDistort1", props);

            m_MaterialEditor.ShaderProperty(flowScale1, Styles.ScaleText, indentation);
            m_MaterialEditor.ShaderProperty(flowSpeed1, Styles.flowSpeedText, indentation);
            m_MaterialEditor.ShaderProperty(flowNormalDistort1, Styles.NormalDistortText, indentation);

            var flowDirectionRotation1 = FindAndMarkProperty("_FlowRotation", props);
            var flowDirectionRotationSinCos1 = FindAndMarkProperty("_FlowRotationSinCos", props);
            string flowmap1UVRot = "Flowmap UV Rotation 1";
            SetTextureRotation(flowDirectionRotation1, flowDirectionRotationSinCos1, true, flowmap1UVRot);

            float flowmap1AlbedoContribution = EditorGUILayout.Slider("Albedo Contribution", flow1ctb.x, 0, 1);
            float flowmap1EmissionContribution = EditorGUILayout.Slider("Emission Contribution", flow1ctb.y, 0, 1);
            flow1ctb.x = flowmap1AlbedoContribution;
            flow1ctb.y = flowmap1EmissionContribution;
            flowmap1Contribution.vectorValue = flow1ctb;

            //////////////////////////// Flowmap1 effect //////////////////////////////////////////////
            MaterialProperty flowmap1EffectOptionProp = effectOption;// for flowmap1 the effect of first flowmap saved in _EffectOption
            if (hasFlowmap2)     // for flowmap2 the effect of first flowmap saved in _ContentEffectOption1
                flowmap1EffectOptionProp = FindAndMarkProperty("_ContentEffectOption1", props, false);

            EditorGUI.BeginChangeCheck();
            var option = (int)flowmap1EffectOptionProp.floatValue;
            option = EditorGUILayout.Popup(Styles.contentOptions, option, flow1Options);
            option = (int)Enum.Parse(typeof(Flow1Type), flow1Options[option]);
            if (EditorGUI.EndChangeCheck())
            {
                m_MaterialEditor.RegisterPropertyChangeUndo(" Content Option 1 Change");
                flowmap1EffectOptionProp.floatValue = (float)option;
            }
            var flowmap1EffectConfig = GetSubEffectConfig(EffectType.Flow1, option);

            /// Flwomap1 breath and Flake:
            /// NOTICE: these are runtime data for flake / breath / ramp:
            Color col00 = Color.black, col01 = Color.black;
            float flakeSpeed00 = 0, flakeSpeed01 = 0;
            float flakeOffset00 = 0, flakeOffset01 = 0;
            float flakeThreshold00 = 0, flakeThreshold01 = 0;
            float flakeScale00 = 0, flakeScale01 = 1.0f;

            /// Flwomap1 Breath:
            if (flowmap1EffectConfig.isBreath)
            {
                var flakeScale = FindAndMarkProperty("_Flow1FlakeScale", props);
                var flakeSpeed1 = FindAndMarkProperty("_Flow1FlakeSpeed1", props);
                var flakeOffset = FindAndMarkProperty("_Flow1FlakeOffset", props);
                var flakeThreshold = FindAndMarkProperty("_Flow1FlakeThreshold", props);

                GUILayout.Label(Styles.breathTitleText, EditorStyles.boldLabel);

                m_MaterialEditor.ShaderProperty(flakeScale, Styles.ScaleText, indentation);
                m_MaterialEditor.ShaderProperty(flakeSpeed1, Styles.SpeedText, indentation);
                m_MaterialEditor.ShaderProperty(flakeOffset, Styles.OffsetText, indentation);//flake 2 offset
                m_MaterialEditor.ShaderProperty(flakeThreshold, Styles.ThresholdText, indentation);//flake 2 threshold

                flakeSpeed00 = flakeSpeed1.floatValue;
                flakeOffset00 = flakeOffset.floatValue;
                flakeThreshold00 = flakeThreshold.floatValue;
                flakeScale00 = flakeScale.floatValue;
            }

            /// Flwomap1 Flake:
            if (flowmap1EffectConfig.isFlake)
            {
                var flakeSpeed2 = FindAndMarkProperty("_Flow1FlakeSpeed2", props);
                var flakeScale = FindAndMarkProperty("_Flow1FlakeScale", props);
                var flakeSpeed1 = FindAndMarkProperty("_Flow1FlakeSpeed1", props);
                var flakeOffset = FindAndMarkProperty("_Flow1FlakeOffset", props);
                var flakeThreshold = FindAndMarkProperty("_Flow1FlakeThreshold", props);

                GUILayout.Label(Styles.flakeTitleText, EditorStyles.boldLabel);

                m_MaterialEditor.ShaderProperty(flakeSpeed2, Styles.SpeedText2, indentation);
                m_MaterialEditor.ShaderProperty(flakeScale, Styles.ScaleText, indentation);
                m_MaterialEditor.ShaderProperty(flakeSpeed1, Styles.SpeedText, indentation);
                m_MaterialEditor.ShaderProperty(flakeOffset, Styles.OffsetText, indentation);//flake 2 offset
                m_MaterialEditor.ShaderProperty(flakeThreshold, Styles.ThresholdText, indentation);//flake 2 threshold

                flakeSpeed00 = flakeSpeed1.floatValue;
                flakeSpeed01 = flakeSpeed2.floatValue;
                flakeOffset00 = flakeOffset.floatValue;
                flakeThreshold00 = flakeThreshold.floatValue;
                flakeScale00 = flakeScale.floatValue;
                flakeScale01 = 1.0f;
            }

            /// Flwomap1 Ramp:
            if (flowmap1EffectConfig.isRamp)
            {
                GUILayout.Label(Styles.rampTitleText, EditorStyles.boldLabel);
                var rampScale = FindAndMarkProperty("_Flow1RampScale", props);
                var rampSpeed = FindAndMarkProperty("_Flow1RampSpeed", props);
                var rampColor1 = FindAndMarkProperty("_Flow1RampColor1", props);
                var rampColor2 = FindAndMarkProperty("_Flow1RampColor2", props);
                var rampThreshold = FindAndMarkProperty("_Flow1RampThreshold", props);

                m_MaterialEditor.ShaderProperty(rampScale, Styles.ScaleText, indentation);
                m_MaterialEditor.ShaderProperty(rampSpeed, Styles.SpeedText, indentation);
                m_MaterialEditor.ShaderProperty(rampColor1, Styles.ColorText, indentation);
                m_MaterialEditor.ShaderProperty(rampColor2, Styles.ColorText, indentation);
                m_MaterialEditor.ShaderProperty(rampThreshold, Styles.ThresholdText, indentation);

                col00 = rampColor1.colorValue;
                col01 = rampColor2.colorValue;
                flakeSpeed00 = rampSpeed.floatValue;
                flakeThreshold00 = rampThreshold.floatValue;
                flakeScale00 = rampScale.floatValue;
            }

            /// Enable Flwomap1 Flake0 keyword:
            SetKeyword(material, Flake0EfxKeyword, flowmap1EffectConfig.isBreath || flowmap1EffectConfig.isFlake || flowmap1EffectConfig.isRamp);
            /// This set the actual shader runtime parameters for breath / flake / ramp:
            SetFlakeEfxMaterial(material, 0,
                                col00, col01, Bool2Float(flowmap1EffectConfig.isFlake), Bool2Float(flowmap1EffectConfig.isRamp),
                                flakeSpeed00, flakeSpeed01, flakeOffset00, flakeOffset01,
                                flakeThreshold00, flakeThreshold01, flakeScale00, flakeScale01);

            /// Flwomap1 HSV:
            if (flowmap1EffectConfig.isHSV)
            {
                GUILayout.Label(Styles.hsvTitleText, EditorStyles.boldLabel);
                var hsvSpeed = FindAndMarkProperty("_Flow1HSVSpeed", props);
                m_MaterialEditor.ShaderProperty(hsvSpeed, Styles.SpeedText, indentation);
            }
            SetKeyword(material, HSV0Keyword, flowmap1EffectConfig.isHSV);

            /// Flwomap1 Flipbook:
            if (flowmap1EffectConfig.isFlippbook)
            {
                DrawFlipbookGUI(material, flowmap1EffectConfig.isFlippbook, props, "_FlipbookParam0");
            }
            SetKeyword(material, Flipbook0Keyword, flowmap1EffectConfig.isFlippbook);
        }

        void ColorChannelLayout(MaterialProperty channelOption, Material material, MaterialProperty channelR, MaterialProperty channelG, MaterialProperty channelB, int ID)
        {
            EditorGUI.BeginChangeCheck();
            int mode = (int)channelOption.floatValue;

            mode = Array.IndexOf(channelOptions, ((ChannelType)mode).ToString());
            mode = EditorGUILayout.Popup(Styles.channelOptions, mode, channelOptions);
            mode = (int)Enum.Parse(typeof(ChannelType), channelOptions[mode]);

            if (EditorGUI.EndChangeCheck())
            {
                m_MaterialEditor.RegisterPropertyChangeUndo(" Channel Option Change");
                channelOption.floatValue = (float)mode;
            }

            string name = ID.ToString();
            switch ((ChannelType)channelOption.floatValue)
            {
                case ChannelType.R:

                    channelR.colorValue = EditorGUILayout.ColorField(Styles.ColorTextR, channelR.colorValue);

                    material.SetColor("_ChannelR"+ name, channelR.colorValue);
                    material.SetColor("_ChannelG"+ name, Color.black);
                    material.SetColor("_ChannelB"+ name, Color.black);
                  
                    break;
                case ChannelType.RG:

                    channelR.colorValue = EditorGUILayout.ColorField(Styles.ColorTextR, channelR.colorValue);
                    channelG.colorValue = EditorGUILayout.ColorField(Styles.ColorTextG, channelG.colorValue);

                    material.SetColor("_ChannelR" + name, channelR.colorValue);
                    material.SetColor("_ChannelG" + name, channelG.colorValue);
                    material.SetColor("_ChannelB" + name, Color.black);
                                                          
                    break;
                case ChannelType.RGB:

                    channelR.colorValue = EditorGUILayout.ColorField(Styles.ColorTextR, channelR.colorValue);
                    channelG.colorValue = EditorGUILayout.ColorField(Styles.ColorTextG, channelG.colorValue);
                    channelB.colorValue = EditorGUILayout.ColorField(Styles.ColorTextB, channelB.colorValue);

                    material.SetColor("_ChannelR" + name, channelR.colorValue);
                    material.SetColor("_ChannelG" + name, channelG.colorValue);
                    material.SetColor("_ChannelB" + name, channelB.colorValue);

                    break;
                case ChannelType.ColorMap:

                    channelR.colorValue = EditorGUILayout.ColorField(Styles.ColorText, channelR.colorValue);

                    material.SetColor("_ChannelR" + name, new Color(channelR.colorValue.r, 0, 0));
                    material.SetColor("_ChannelG" + name, new Color(0, channelR.colorValue.g, 0));
                    material.SetColor("_ChannelB" + name, new Color(0, 0, channelR.colorValue.b));

                    break;
                default:
                    break;
            }
        }

        static float Rotation2DGUI(float rad, ref float cos, ref float sin)
        {
            cos = Mathf.Cos(rad);
            sin = Mathf.Sin(rad);
            return rad;
        }


        static EffectConfig GetSubEffectConfig(EffectType effectType, int mode)
        {
            switch (effectType)
            {
                case EffectType.Flow1:
                    if (!Flow1Config.ContainsKey((Flow1Type)mode))
                        return Flow1Config[(Flow1Type)0];
                    return Flow1Config[(Flow1Type)mode];
                case EffectType.Flow2:
                    if (!Flow2Config.ContainsKey((Flow2Type)mode))
                        return Flow2Config[(Flow2Type)0];
                    return Flow2Config[(Flow2Type)mode];

            }
            return new EffectConfig();
        }
        EffectConfig SubEffectPopup(EffectType mainEffectEnum)
        {

            EditorGUI.BeginChangeCheck();
            int mode = (int)effectOption.floatValue;

            switch (mainEffectEnum)
            {
                case EffectType.Flow1:
                    mode = Array.IndexOf(flow1Options, ((Flow1Type)mode).ToString());
                    mode = EditorGUILayout.Popup(Styles.effectOptions, mode, flow1Options);
                    mode = (int)Enum.Parse(typeof(Flow1Type), flow1Options[mode]);
                    break;
                case EffectType.Flow2:
                    mode = Array.IndexOf(flow2Options, ((Flow2Type)mode).ToString());
                    mode = EditorGUILayout.Popup(Styles.effectOptions, mode, flow2Options);
                    mode = (int)Enum.Parse(typeof(Flow2Type), flow2Options[mode]);
                    break;

            }

            if (EditorGUI.EndChangeCheck())
            {
                m_MaterialEditor.RegisterPropertyChangeUndo("Option Change");
                effectOption.floatValue = (float)mode;
            }

            return GetSubEffectConfig(mainEffectEnum, mode);
        }
        
        static void SetKeyword(Material m, string keyword, bool state)
        {
            if (state)
                m.EnableKeyword(keyword);
            else
                m.DisableKeyword(keyword);
        }

        public override void AssignNewShaderToMaterial(Material material, Shader oldShader, Shader newShader)
        {
            material.SetFloat("_EffectOption", 0);
            base.AssignNewShaderToMaterial(material, oldShader, newShader);
        }

        protected void DrawFlipbookGUI(Material material, bool use, MaterialProperty[] props, string propName)
        {
            var FlipbookParam = FindAndMarkProperty(propName, props);
            Vector4 flipbookParam = FlipbookParam.vectorValue;
            if (use)
            {
                float fps = flipbookParam.z;
                int uDirFrameCount = Mathf.RoundToInt(flipbookParam.x);
                int vDirFrameCount = Mathf.RoundToInt(flipbookParam.y);
                TextureWrapMode textureWrapMode = (flipbookParam.w == 1.0f) ? TextureWrapMode.Repeat : TextureWrapMode.Clamp;
                fps = 1.0f / EditorGUILayout.FloatField("Animation Speed", 1.0f / fps);
                uDirFrameCount = EditorGUILayout.IntField("Page Count (U)", uDirFrameCount);
                vDirFrameCount = EditorGUILayout.IntField("Page Count (V)", vDirFrameCount);
                textureWrapMode = (TextureWrapMode)EditorGUILayout.EnumPopup("Wrap Mode", textureWrapMode);
                fps = Mathf.Max(fps, 0.0f);
                uDirFrameCount = Mathf.Max(uDirFrameCount, 1);
                vDirFrameCount = Mathf.Max(vDirFrameCount, 1);
                flipbookParam.x = uDirFrameCount;
                flipbookParam.y = vDirFrameCount;
                flipbookParam.z = fps;
                flipbookParam.w = (textureWrapMode == TextureWrapMode.Repeat) ? 1.0f : 0.0f;
            }
            else
            {
                flipbookParam.x = 1.0f;
                flipbookParam.y = 1.0f;
                flipbookParam.z = 1.0f;
                flipbookParam.w = 1.0f;
            }
            FlipbookParam.vectorValue = flipbookParam;
        }

        private static class Styles
        {


            public static GUIContent albedoMapText = new GUIContent("Albedo");

            public static GUIContent metallicMapText = new GUIContent("Metallic", "AO (R) and Metallic (B), (G) and (A) are foir ");
            public static GUIContent flowmapText1 = new GUIContent("FLOWMAP ");
            public static GUIContent flowmapText2 = new GUIContent("FLOWMAP 2");
            public static GUIContent flowSpeedText = new GUIContent("Speed", "flowSpeed(X,Y), tilling(Z,W)");


            public static GUIContent SpeedText = new GUIContent("Speed");
            public static GUIContent ScaleText = new GUIContent("Intensity");
            public static GUIContent SpeedText2 = new GUIContent("Speed2");
            public static GUIContent OffsetText = new GUIContent("offset");
            public static GUIContent ThresholdText = new GUIContent("threshold");

            public static GUIContent PowerText = new GUIContent("Power");
            public static GUIContent DistortText = new GUIContent("Distort(XY)");
            public static GUIContent ParallaxText = new GUIContent("Parallax");
            public static GUIContent ColorText = new GUIContent("Color");
            public static GUIContent ColorTextR = new GUIContent("Color(channel R)");
            public static GUIContent ColorTextG = new GUIContent("Color(channel G)");
            public static GUIContent ColorTextB = new GUIContent("Color(channel B)");

            public static GUIContent NormalDistortText = new GUIContent("NormalDistort");

            public static GUIContent DetailNormalText = new GUIContent("DetailNormal");




            public static GUIContent EmissionTintText = new GUIContent("EmissionTintColor");



            public static string effectOptions = "Effect Options";
            public static string channelOptions = "Channel Options";
            public static string contentOptions = "Content Options";


            public static string baseTitleText = "Base Settings";
            public static string SubModeText = "Sub Mode";
            public static string maskModeText = "Mask Mode";
            public static string flowmap1IntensityText = "Flowmap 1 intensity";
            public static string flowmap2IntensityText = "Flowmap 2 intensity";
            public static string uvMode1Text = "Flowmap 1 UV Mode";
            public static string uvMode2Text = "Flowmap 2 UV Mode";
            public static string projAxisText = "Project Axis";
            public static string overlayerTileText = "Blend Settings";
            public static string flowmapTitleText = "Flowmap Settings";
            public static string breathTitleText = "Breath Settings";
            public static string flakeTitleText = "Flake Settings";
            public static string hsvTitleText = "HSV Settings";
            public static string rampTitleText = "Ramp Settings";
            public static string subTitleText = "Sub Effect Settings";
            public static string iridescenceTitleText = "Iridescence Settings";


            public static string addTitleText = "Add Settings";
            public static string alphaTitleText = "Alpha Cover Settings";
            public static string mulTitleText = "Multiply Settings";
            public static string distortTitleText = "Distort Settings";
            public static string parallaxTitleText = "Parallax Settings";





            public static string emissionTitleText = "Emission Settings";





            public static GUIContent todLightMapText = new GUIContent("TOD LightMap", "Packed Man-Made lights irradiance(RGB) and Sky GI radiosity(A)");
            public static GUIContent skySoIntesnityText = new GUIContent("Sky Specular Occlusion", "The Intensity that outdoor skylight intensity affect on specular occlusion. Default value is 1(fully affected)");
            public static GUIContent manMadeLightIntensityText = new GUIContent("Man-Made lights Intensity Scale", "Man-Made lights Intensity. Default value is 2.56");
            public static GUIContent manMadeLightSOText = new GUIContent("Man-Made lights Specular Occlusion", "The Intensity that indoor man-made light intensity affect on specular occlusion. Default value is 0(fully disabled)");
            public static GUIContent smoothnessText = new GUIContent("Smoothness", "Smoothness value");
            public static GUIContent highlightsText = new GUIContent("Specular Highlights", "Specular Highlights");
            public static GUIContent reflectionsText = new GUIContent("Reflections", "Glossy Reflections");
            public static GUIContent simpleDynmIBLspecText = new GUIContent("Use Simple Dynamic IBL", "Use Simple Dynamic IBL");
            public static GUIContent normalMapText = new GUIContent("Normal Map", "Normal Map");
            public static GUIContent normalMapScale = new GUIContent("Normal Map Scale", "Normal Map Scale");
            public static GUIContent bentNormalMapText = new GUIContent("Bent Normal Map", "Normal Map");
            public static GUIContent heightMapText = new GUIContent("Height Map", "Height Map (G)");
            public static GUIContent occlusionText = new GUIContent("Occlusion", "Occlusion (G)");
            public static GUIContent emissionText = new GUIContent("Emission", "Emission (RGB)");

            public static GUIContent detailMaskText = new GUIContent("Detail Mask", "Mask for Secondary Maps (A)");
            public static GUIContent detailAlbedoText = new GUIContent("Detail Albedo x2", "Albedo (RGB) multiplied by 2");
            public static GUIContent detailNormalMapText = new GUIContent("Detail Normal Map", "Detail Normal Map");
            public static GUIContent detailNormalMapScaleText = new GUIContent("Detail Normal UV Scale", "Detail Normal UV Scale");
            public static GUIContent detailNormalPowerText = new GUIContent("Detail Normal Power", "Detail Normal Power");

            public static GUIContent topAlbedoText = new GUIContent("Albedo", "Albedo (RGB)");
            public static GUIContent topNormalMapText = new GUIContent("Normal Map", "Normal Map");
            public static GUIContent topNormalMapWithAlbedoText = new GUIContent("Normal Map With Albedo", "Normal Map");

            public static GUIContent absorptionText = new GUIContent("Absorption", "Absorption");
            public static GUIContent absorptionColorText = new GUIContent("Absorption Color", "Absorption Color");
            public static GUIContent absorptionColorAtDistanceText = new GUIContent("Absorption Color At Distance", "Absorption Color At Distance");
            public static GUIContent transmittanceText = new GUIContent("Transmittance", "Transmittance");
            public static GUIContent specularText = new GUIContent("Specular", "Specular");
            public static GUIContent simpleBlendingScaleText = new GUIContent("SimpleBlendingScale", "SimpleBlendingScale");
            public static GUIContent simpleBlendingRoughnessScaleText = new GUIContent("SimpleBlendingRoughnessScale", "SimpleBlendingRoughnessScale");

            public static GUIContent thicknessText = new GUIContent("Thickness", "Thickness");
            public static GUIContent dampText = new GUIContent("Damp", "Damp");
            public static GUIContent normalDampText = new GUIContent("Normal Damp", "Normal Damp");
            public static GUIContent hardnessText = new GUIContent("Hardness", "Hardness");
            public static GUIContent slopeThresholdText = new GUIContent("Slope Threshold", "Slope Threshold");
            public static GUIContent overGravityText = new GUIContent("Gravity", "Gravity");

            public static GUIContent customIBLMapText = new GUIContent("Custom IBL", "IBL cubemap");
            public static GUIContent colorBoostLegacyText = new GUIContent("Color Boost In Legacy", "Boost factor in legacy mode");

            public static GUIContent rimMapText = new GUIContent("Rim Map", "Rim Map");







            public static string layer1TitleText = "Outer Layer";
            public static string layer2TitleText = "Inner Layer";
            public static string multLayerFallbackSectionTitleText = "Fallback Parameters";

            public static GUIContent emissiveWarning = new GUIContent("Emissive value is animated but the material has not been configured to support emissive. Please make sure the material itself has some amount of emissive.");

            public static readonly string[] blendNames = Enum.GetNames(typeof(BlendMode));
            public static readonly string[] cullNames = Enum.GetNames(typeof(CullMode));
        }
 


    }
# endif
} // namespace UnityEditor