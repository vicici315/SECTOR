﻿// Unity built-in shader source. Copyright (c) 2016 Unity Technologies. MIT license (see license.txt)

using System;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Rendering;

namespace UnityEditor
{
    internal class CFStandardShaderGUI : CFShaderGUIBase
    {
#if USE_CUSTOM_UNITY


        public enum AlbedoMode
        {
            RGB,
            WithAlpha,
            WithHeightmap,
        }

        public enum NormalMode
        {
            Normal,
            PackRoughness,
            PackAlbedo,
            BentNormal
        }

        public enum MaskMode
        {
            AoRoughnessMetallic,
            AoMetallic,
            AoMetallicWith4ColorMask
        }

        public enum MainMode
        {
            Dynamic,
            StaticSingle,
            StaticDouble,
            StaticMultLayer,
            Foliage
        }

        public enum KeywordSet
        {
            _DETAIL_LERP
        }

        public enum DynamicMode
        {
            Color = 300,
            Opaque = 0,
            Cutout = 1,
            Transparent = 2,
            TransparentPhysical = 3,
            DetailLerp = 5,
            AdvanceDetail = 501,
            Emission = 20,
            EmissionMask = 21,
            TransparentEmmision = 502,
            TransparentEmmisionDetailNormalmap = 503,
            CharacterWithAddLight = 8,
            Scene = 7,
            //CutoutHair = 4,
            //SSSLutSkin = 6,
            //Classic = 100,
            //ClassicCutout = 101,
            //Legacy = 200,
            //LegacyHair = 201,
            //Breakable = 400,
            //BreakableCutout = 401,
            EmissionDetailLerp = 500,
        }

        public enum FoliageMode
        {
            StaticFoliage = 0,
            StaticGrass = 1,
            BrFoliage = 500,
            BrBillBoard = 501,
            BrGrass = 502,
            BrGrassBillBoard = 503,
            LobbyFoliage = 600,
        }

        public enum StaticSingleMode
        {
            Opaque = 0,
            AlbedoTintMask = 11,
            AlbedoTintVertex = 12,
            Cutout = 1,
            Transparent = 2,
            TransparentPhysical = 3,
            AoMetallic = 4,
            TransparentTintVertex = 5,
            DetailNormal = 10,
            Emission = 20,
            EmissionCutout = 21,
            Color = 300,
            TOD = 400,
            TODCutoff = 402,
            VertexAOnoLightmap = 403,
            TODalbedoTintMask = 404
            //TODMetallicInNormal = 401,
            //ColorTransparent = 301,
        }
        public enum StaticDoubleMode
        {
            HeightmapFull = 0,
            //Heightmap = 1,
            //Heightmap_Albedo = 2,
            //Heightmap_NormalRoughness = 3,
            //Heightmap_NormalAlbedo = 4,
            Gravity = 10,
            TODGravity = 13,
            GravityRock = 11,
            TODGravityRock = 12,
            GravityVertexAOnoLightmap = 14,
            GravityRockRoughness = 15
        }
        
        class DynamicModeComparer : IEqualityComparer<DynamicMode>
        {
            public bool Equals(DynamicMode x, DynamicMode y) { return x == y; }
            public int GetHashCode(DynamicMode obj) { return (int)obj; }
        }
        
        class StaticSingleModeComparer : IEqualityComparer<StaticSingleMode>
        {
            public bool Equals(StaticSingleMode x, StaticSingleMode y) { return x == y; }
            public int GetHashCode(StaticSingleMode obj) { return (int)obj; }
        }
        
        class StaticDoubleModeComparer : IEqualityComparer<StaticDoubleMode>
        {
            public bool Equals(StaticDoubleMode x, StaticDoubleMode y) { return x == y; }
            public int GetHashCode(StaticDoubleMode obj) { return (int)obj; }
        }
        
        class StaticMultLayerModeComparer : IEqualityComparer<StaticMultLayerMode>
        {
            public bool Equals(StaticMultLayerMode x, StaticMultLayerMode y) { return x == y; }
            public int GetHashCode(StaticMultLayerMode obj) { return (int)obj; }
        }
        
        class FoliageModeComparer : IEqualityComparer<FoliageMode>
        {
            public bool Equals(FoliageMode x, FoliageMode y) { return x == y; }
            public int GetHashCode(FoliageMode obj) { return (int)obj; }
        }

        public enum StaticMultLayerMode
        {
            Opaque = 0,
        }

        struct ShaderConfig
        {
            public string keyword;
            public BlendMode blendMode;
            public bool debugOnly;
            public bool isPreZ;

            public bool useAlbedoTint;
            public bool tintOverrideAlbedoTexture;
            public bool canUseAlbedoMaskTint;
            public bool multiplyAoOnAlbedo;
            public bool noAlbedoMap;
            public bool hasAlpha;
            //public bool hasAlphaMap;
            public bool hasAlphaTilingOffset;
            //
            public bool hasAlphaAsEmission;
            public bool hasCutout;
            public bool hasSeparateCutoutShadow;
            public bool canUseCutoutShadow;
            public bool lowTierCustomShadowIntensity;
            // public bool isWindVertexColored;
            // public bool isGrassWave;
            public bool isWindWave;
            public bool allowAlbedoMicroOcc;

            public bool isGrassVertexInteractive;
            public bool isGrassFragmentInteractive;

            public bool isClassicTexture;
            public bool hasNormalMap;
            public bool hasNormalMapAlpha;
            public bool hasNormalMapScale;
            public bool isNormalWithAo;
            public bool hasBentNormalMap;
            public bool hasMetallicMap;
            public bool hasMetallicInNormalMapAlpha;

            public bool hasEmission;
            public bool hasEmissionMap;
            public bool threeChannelEmission;
            public bool FourChannelEmission;

            public bool hasDetail;
            public bool allowDetail;
            public bool hasDetailAlbedo;
            public bool hasDetailNormal;
            public bool hasAdvanceDetail;

            public bool hasTopLayer;
            public bool hasHeightMap;
            public bool isAlphaHeightMap;
            public bool hasTopLayerAlbedoMap;
            public bool hasTopLayerNormalMap;
            public bool isTopLayerNormalAlbedo;


            public bool useAlbedoTint2;
            public bool isClassicTexture2;
            public bool noAlbedoMap2;
            public bool hasNormalMap2;
            public bool hasMetallicMap2;


            public bool isLegacySubMode;
            public bool hasTranslucency;
            public bool foliage;
            public bool foliageBillboard;
            public bool grass;
            //public bool hasRimMap;

            public bool hasTodLightmap;
        }

        static Dictionary<string, MainMode> MainModeDict;
        static Dictionary<DynamicMode, ShaderConfig> DynamicConfig;
        static Dictionary<StaticSingleMode, ShaderConfig> StaticSingleConfig;
        static Dictionary<StaticDoubleMode, ShaderConfig> StaticDoubleConfig;
        static Dictionary<StaticMultLayerMode, ShaderConfig> StaticMultLayerConfig;
        static Dictionary<FoliageMode, ShaderConfig > FoliageConfig;
        static List<string> SubModeKeywords;

        public static readonly string[] dynamicModeNames = Enum.GetNames(typeof(DynamicMode));
        public static readonly string[] staticSingleModeNames = Enum.GetNames(typeof(StaticSingleMode));
        public static readonly string[] staticDoubleModeNames = Enum.GetNames(typeof(StaticDoubleMode));
        public static readonly string[] staticMultLayerModeNames = Enum.GetNames(typeof(StaticMultLayerMode));
        public static readonly string[] foliageModeNames = Enum.GetNames(typeof(FoliageMode));

        bool m_DebugShowDirectLighting1 = true;
        bool m_DebugShowDirectLighting2 = true;
        bool m_DebugEnableEvnLighting1 = true;
        bool m_DebugEnableEvnLighting2 = true;

        public const string CODStandard_Static              = "CODStandard Static";
        public const string CODStandard_Dynamic             = "CODStandard Dynamic";
        public const string CODStandard_Dynamic_Dissolve    = "CODStandard Dynamic Dissolve";
        public const string CODStandard_Dynamic_BurnOut     = "CODStandard Dynamic Burn Out";
        public const string CODStandard_Dynamic_Outline     = "CODStandard Dynamic Outline";
        public const string CODStandard_OverLayer           = "CODStandard Static Double Layer";
        public const string CODStandard_Foliage             = "CODStandard Foliage";
        public const string CODStandard_Terrain             = "CODStandard Terrain";
        public const string CODStandard_Road                = "CODStandard Road";
        public const string CODStandard_Skin                = "CODStandard Skin";
        //public const string CODStandard_Breakable           = "CODStandard Breakable";
        public const string CODStandard_TwoLayer            = "CODStandard TwoLayer";

        public const string CODStandard_IceLake = "CODStandard IceLake";

        public const string CODStandard_Sticker = "CODStandard StickerShell";
        public const string CODStandard_Fur = "CODStandard_Fur";

        public static void InitConfig()
        {
            if (MainModeDict != null)
                return;
            MainModeDict = new Dictionary<string, MainMode>()
            {
                {CODStandard_Static,            MainMode.StaticSingle},
                {CODStandard_OverLayer,         MainMode.StaticDouble},
                {CODStandard_Dynamic,           MainMode.Dynamic},
                {CODStandard_Dynamic_Dissolve,  MainMode.Dynamic},
                //{CODStandard_Breakable,         MainMode.Dynamic},
                {CODStandard_TwoLayer,          MainMode.StaticMultLayer},
                {CODStandard_Dynamic_Outline,   MainMode.Dynamic},
                {CODStandard_Foliage,           MainMode.Foliage},
                {CODStandard_Road,              MainMode.StaticSingle},
            };
            
            DynamicConfig = new Dictionary<DynamicMode, ShaderConfig>(new DynamicModeComparer())
            {
                {DynamicMode.Color, new ShaderConfig()                  { keyword = "_DYNAMIC_COLOR", useAlbedoTint = true }},
                {DynamicMode.Opaque, new ShaderConfig()                 { keyword = "_DYNAMIC_OPAQUE", hasNormalMap = true, hasMetallicMap = true, allowDetail = true, hasDetailAlbedo = true, hasBentNormalMap = true}},
                {DynamicMode.Cutout, new ShaderConfig()                 { keyword = "_DYNAMIC_CUTOUT", blendMode = BlendMode.Cutout, hasAlpha = true, hasCutout = true, hasNormalMap = true, hasMetallicMap = true ,allowDetail = true, hasDetailAlbedo = true}},
                {DynamicMode.Transparent, new ShaderConfig()            { keyword = "_DYNAMIC_TRANSPARENT", blendMode = BlendMode.AlphaBlend, hasAlpha = true, hasNormalMap = true, hasMetallicMap = true ,allowDetail = true, hasDetailAlbedo = true}},
                {DynamicMode.TransparentPhysical, new ShaderConfig()    { keyword = "_DYNAMIC_TRANSPARENT", blendMode = BlendMode.Transparent, hasAlpha = true, hasNormalMap = true, hasMetallicMap = true }},
                {DynamicMode.TransparentEmmision, new ShaderConfig()    { keyword = "_DYNAMIC_TRANSPARENT_EMISSION", blendMode = BlendMode.AlphaBlend, hasAlpha = true, hasNormalMap = true,  hasEmission = true, hasEmissionMap = true , threeChannelEmission = true}},
                {DynamicMode.TransparentEmmisionDetailNormalmap, new ShaderConfig()    { keyword = "_DYNAMIC_TRANSPARENT_EMISSION_DETAIL_NORMALMAP", blendMode = BlendMode.AlphaBlend, hasAlpha = true, hasNormalMap = true,  hasEmission = true, hasEmissionMap = true , threeChannelEmission = true, useAlbedoTint = true, hasDetail = true, hasDetailNormal = true}},
                {DynamicMode.CharacterWithAddLight, new ShaderConfig()  { keyword = "_DYNAMIC_OPAQUE_CHARACTER_ADDLIGHT", hasNormalMap = true, hasMetallicMap = true, allowDetail = true, hasDetailAlbedo = true, hasBentNormalMap = true}},
                {DynamicMode.Scene, new ShaderConfig()                  { keyword = "_DYNAMIC_SCENE",hasNormalMap = true, hasMetallicMap = true, allowDetail = true, hasDetailAlbedo = true}},
				{DynamicMode.DetailLerp, new ShaderConfig()             { keyword = "_DYNAMIC_DETAIL_LERP",         hasNormalMap = true, hasMetallicMap = true, hasDetail = true, hasDetailAlbedo = true, hasAlphaAsEmission = true}}, //hasAlpha = true
				{DynamicMode.AdvanceDetail, new ShaderConfig()          { keyword = "_DYNAMIC_ADVANCE_DETAIL_LERP", hasNormalMap = true, hasMetallicMap = true, hasDetail = true, hasDetailAlbedo = true, hasAdvanceDetail = true}}, //hasAlpha = true
				{DynamicMode.EmissionDetailLerp, new ShaderConfig()     { keyword = "_DYNAMIC_EMISSION_DETAIL_LERP", hasNormalMap = true, hasEmission = true, hasMetallicMap = true, hasEmissionMap = true , hasDetail = true, hasDetailAlbedo = true}},
                {DynamicMode.Emission, new ShaderConfig()               { keyword = "_DYNAMIC_EMISSION", hasNormalMap = true, hasEmission = true, hasMetallicMap = true, hasEmissionMap = true , allowDetail = true, hasDetailAlbedo = true}},
                {DynamicMode.EmissionMask, new ShaderConfig()           { keyword = "_DYNAMIC_EMISSION_MASK", hasNormalMap = true, hasEmission = true, hasMetallicMap = true , hasEmissionMap = false}},
                //{DynamicMode.SSSLutSkin, new ShaderConfig()             { keyword = "_DYNAMIC_SSSLUT_SKIN", hasNormalMap = true}}
                //{DynamicMode.Legacy, new ShaderConfig()                 { keyword = "_DYNAMIC_LEGACY", isLegacySubMode = true }},
                //{DynamicMode.Classic, new ShaderConfig()                { keyword = "_DYNAMIC_OPAQUE_CLASSIC", isClassicTexture = true, hasNormalMap = true, hasMetallicMap = true }},
                //{DynamicMode.ClassicCutout, new ShaderConfig()          { keyword = "_DYNAMIC_OPAQUE_CLASSIC_CUTOUT", blendMode = BlendMode.Cutout, hasAlpha = true, hasCutout = true, isClassicTexture = true, hasNormalMap = true, hasMetallicMap = true }},
                //{DynamicMode.CutoutHair, new ShaderConfig()             { keyword = "_DYNAMIC_CUTOUT_HAIR", blendMode = BlendMode.Cutout, hasAlpha = true, hasAlphaMap = true, hasAlphaTilingOffset = true, hasCutout = true, hasNormalMap = true, hasMetallicMap = true }},
                //{DynamicMode.LegacyHair, new ShaderConfig() { keyword = "_DYNAMIC_LEGACY_HAIR", blendMode = BlendMode.Cutout, hasAlpha = true, hasAlphaMap = true, hasAlphaTilingOffset = true, hasCutout = true, isLegacySubMode = true }},
                //{DynamicMode.Breakable, new ShaderConfig() { keyword = "_DYNAMIC_BREAKABLE", blendMode = BlendMode.Opaque, hasRimMap = true, hasNormalMap = true, hasAlpha = true }},
                //{DynamicMode.BreakableCutout, new ShaderConfig() { keyword = "_DYNAMIC_BREAKABLE_CUTOUT", blendMode = BlendMode.Cutout, hasCutout = true, hasAlpha = true }},
            };

            FoliageConfig = new Dictionary<FoliageMode, ShaderConfig>(new FoliageModeComparer())
            {
                {FoliageMode.BrFoliage, new ShaderConfig() { keyword = "_FOLIAGE", isPreZ = true, blendMode = BlendMode.Cutout, hasAlpha = true, hasCutout = true ,hasNormalMap = false, hasMetallicMap = false, hasSeparateCutoutShadow = true, canUseCutoutShadow = true, isWindWave = true, isGrassVertexInteractive = true, foliage = true ,hasTranslucency = true}},
                {FoliageMode.BrBillBoard, new ShaderConfig() { keyword = "_BILLBOARD", isPreZ = false, blendMode = BlendMode.Cutout, hasAlpha = true, hasCutout = true, hasNormalMap = false, hasMetallicMap = false, hasSeparateCutoutShadow = true, canUseCutoutShadow = true, foliage = true , foliageBillboard = true }},
                {FoliageMode.BrGrass, new ShaderConfig() { keyword = "_GRASS", isPreZ = true, blendMode = BlendMode.Cutout, hasAlpha = true, hasCutout = true, hasNormalMap = false, hasMetallicMap = false, hasSeparateCutoutShadow = true, canUseCutoutShadow = true, foliage = true ,isWindWave = true, isGrassVertexInteractive = true, isGrassFragmentInteractive = true, grass = true, hasTranslucency = true }},
                {FoliageMode.BrGrassBillBoard, new ShaderConfig() { keyword = "_GRASS_BILLBOARD", isPreZ = false, blendMode = BlendMode.Cutout, hasAlpha = true, hasCutout = true, hasNormalMap = false, hasMetallicMap = false, hasSeparateCutoutShadow = true, canUseCutoutShadow = true, foliage = true, isWindWave = false, grass = true, hasTranslucency = true }},
                {FoliageMode.StaticFoliage, new ShaderConfig() { keyword = "_STATIC_FOLIAGE", isPreZ = false, blendMode = BlendMode.Cutout, hasAlpha = true, hasCutout = true, hasNormalMap = false, hasMetallicMap = false, hasSeparateCutoutShadow = true, canUseCutoutShadow = true, foliage = true, isWindWave = false, isGrassVertexInteractive = true, grass = false, hasTranslucency = true }},
                {FoliageMode.StaticGrass, new ShaderConfig() { keyword = "_STATIC_GRASS", isPreZ = false, blendMode = BlendMode.Cutout, hasAlpha = true, hasCutout = true, hasNormalMap = false, hasMetallicMap = false, /*hasSeparateCutoutShadow = true,*/ canUseCutoutShadow = true, foliage = true, isWindWave = true, isGrassVertexInteractive = true, isGrassFragmentInteractive = true, grass = true, hasTranslucency = true }},
                {FoliageMode.LobbyFoliage, new ShaderConfig() { keyword = "_LOBBY_FOLIAGE", isPreZ = false, blendMode = BlendMode.Cutout, hasAlpha = true, hasCutout = true ,hasNormalMap = true, hasMetallicMap = false, hasSeparateCutoutShadow = true, canUseCutoutShadow = true,  foliage = true, isWindWave = true, isGrassVertexInteractive = true, hasTranslucency = true}},
            };

            StaticSingleConfig = new Dictionary<StaticSingleMode, ShaderConfig>(new StaticSingleModeComparer())
            {
                {StaticSingleMode.Opaque, new ShaderConfig() { keyword = "_STATIC_OPAQUE", hasNormalMap = true, allowAlbedoMicroOcc = true }},
                {StaticSingleMode.AlbedoTintMask, new ShaderConfig() { keyword = "_STATIC_ALBEDOTINTMASK", hasNormalMap = true, canUseAlbedoMaskTint = true, hasNormalMapAlpha = true}},
                {StaticSingleMode.AlbedoTintVertex, new ShaderConfig() { keyword = "_STATIC_ALBEDOTINTVERTEX", hasNormalMap = true }},
                {StaticSingleMode.Cutout, new ShaderConfig() { keyword = "_STATIC_CUTOUT", blendMode = BlendMode.Cutout, hasNormalMap = true, hasAlpha = true, hasCutout = true, canUseCutoutShadow = true }},
                {StaticSingleMode.Transparent, new ShaderConfig() { keyword = "_STATIC_TRANSPARENT", blendMode = BlendMode.AlphaBlend, hasNormalMap = true, hasAlpha = true }},
                {StaticSingleMode.TransparentPhysical, new ShaderConfig() { keyword = "_STATIC_TRANSPARENT", blendMode = BlendMode.Transparent, hasNormalMap = true, hasAlpha = true }},
                {StaticSingleMode.TransparentTintVertex, new ShaderConfig() { keyword = "_STATIC_TRANSPARENT_ALBEDOTINTVERTEX", blendMode = BlendMode.AlphaBlend, hasNormalMap = true, hasAlpha = true }},
                {StaticSingleMode.AoMetallic, new ShaderConfig() { keyword = "_STATIC_OPAQUE_WITH_METALLIC", hasNormalMap = true, hasMetallicMap = true }},
                {StaticSingleMode.Emission, new ShaderConfig() { keyword = "_STATIC_EMISSION", hasNormalMap = true, hasEmission = true, hasEmissionMap = true }},
                {StaticSingleMode.EmissionCutout, new ShaderConfig() { keyword = "_STATIC_EMISSION_CUTOUT", blendMode = BlendMode.Cutout, hasNormalMap = true, hasAlpha = true, hasCutout = true, hasEmission = true, hasEmissionMap = true }},
                {StaticSingleMode.Color, new ShaderConfig() { keyword = "_STATIC_COLOR", useAlbedoTint = true, noAlbedoMap = true }},
                {StaticSingleMode.TOD, new ShaderConfig() { keyword = "_STATIC_TOD", lowTierCustomShadowIntensity = true, hasNormalMap = true , hasTodLightmap = true }},
                {StaticSingleMode.TODCutoff, new ShaderConfig() { keyword = "_STATIC_TOD_CUTOUT",lowTierCustomShadowIntensity = true,  blendMode = BlendMode.Cutout,  hasNormalMap = true , hasAlpha = true,  hasCutout = true, canUseCutoutShadow = true , hasTodLightmap = true }},
                {StaticSingleMode.TODalbedoTintMask, new ShaderConfig() { keyword = "_STATIC_TOD_ALBEDOTINTMASK",lowTierCustomShadowIntensity = true,  hasNormalMap = true , hasTodLightmap = true, canUseAlbedoMaskTint = true, hasNormalMapAlpha = true, }},
                {StaticSingleMode.VertexAOnoLightmap, new ShaderConfig() { keyword = "_STATIC_VERTEX_AO_NO_LM",  hasNormalMap = true }}
                //{StaticSingleMode.DetailNormal, new ShaderConfig() { keyword = "_STATIC_WITH_DETAIL_NORMAL", hasNormalMap = true, hasDetail = true, hasDetailNormal = true, hasNormalMapScale = true }},
                //{StaticSingleMode.ColorTransparent, new ShaderConfig() { keyword = "_STATIC_COLORTRANSPARENT", blendMode = BlendMode.Fade, useAlbedoTint = true, noAlbedoMap = true }},
                //{StaticSingleMode.TODMetallicInNormal, new ShaderConfig() { keyword = "_STATIC_TOD_METALLIC",lowTierCustomShadowIntensity = true,  hasNormalMap = true , hasTodLightmap = true , hasMetallicInNormalMapAlpha = true, hasNormalMapAlpha = true}},
            };

            StaticDoubleConfig = new Dictionary<StaticDoubleMode, ShaderConfig>(new StaticDoubleModeComparer())
            {
                {StaticDoubleMode.HeightmapFull, new ShaderConfig() { keyword = "_STATIC_DOUBLE_HEIGHTMAP_FULL", debugOnly = true, hasTopLayer = true, hasNormalMap = true, hasHeightMap = true, hasTopLayerAlbedoMap = true, hasTopLayerNormalMap = true }},
                {StaticDoubleMode.Gravity, new ShaderConfig() { keyword = "_STATIC_DOUBLE_GRAVITY",hasTopLayer = true, hasNormalMap = true, hasTopLayerNormalMap = true, isTopLayerNormalAlbedo = true }},
                {StaticDoubleMode.TODGravity, new ShaderConfig() { keyword = "_STATIC_DOUBLE_TOD_GRAVITY",hasTopLayer = true, hasNormalMap = true, hasTopLayerNormalMap = true, isTopLayerNormalAlbedo = true, hasTodLightmap = true  }},
                {StaticDoubleMode.GravityRock, new ShaderConfig() { keyword = "_STATIC_DOUBLE_GRAVITY_ROCK",multiplyAoOnAlbedo = true, tintOverrideAlbedoTexture = true,hasTopLayer = true, hasNormalMap = true, hasTopLayerAlbedoMap = true, hasDetail = true, hasDetailNormal = true, hasNormalMapScale = true, isNormalWithAo = true }},
                {StaticDoubleMode.GravityRockRoughness, new ShaderConfig() { keyword = "_STATIC_DOUBLE_GRAVITY_ROCK_ROUGHNESS",multiplyAoOnAlbedo = true, tintOverrideAlbedoTexture = true,hasTopLayer = true, hasNormalMap = true, hasTopLayerAlbedoMap = true, hasDetail = true, hasDetailNormal = true, hasNormalMapScale = true, isNormalWithAo = false }},
                {StaticDoubleMode.TODGravityRock, new ShaderConfig() { keyword = "_STATIC_DOUBLE_TOD_GRAVITY_ROCK",multiplyAoOnAlbedo = true, tintOverrideAlbedoTexture = true,hasTopLayer = true, hasNormalMap = true, hasTopLayerAlbedoMap = true, hasDetail = false, hasDetailNormal = false, hasNormalMapScale = true, isNormalWithAo = true, hasTodLightmap = true }},
                {StaticDoubleMode.GravityVertexAOnoLightmap, new ShaderConfig() { keyword = "_STATIC_DOUBLE_GRAVITY_VERTEX_AO_NO_LM",hasTopLayer = true, hasNormalMap = true, hasTopLayerNormalMap = true, isTopLayerNormalAlbedo = true}}
                //{StaticDoubleMode.Heightmap_NormalAlbedo, new ShaderConfig() { keyword = "_STATIC_DOUBLE_HEIGHTMAP_NORMALALBEDO",hasTopLayer = true, hasAlpha = true, isAlphaHeightMap = true, hasNormalMap = true, hasTopLayerNormalMap = true, isTopLayerNormalAlbedo = true }},
                //{StaticDoubleMode.Heightmap_NormalRoughness, new ShaderConfig() { keyword = "_STATIC_DOUBLE_HEIGHTMAP_NORMALROUGHNESS",hasTopLayer = true, hasAlpha = true, isAlphaHeightMap = true, hasNormalMap = true, hasTopLayerNormalMap = true }},
                //{StaticDoubleMode.Heightmap_Albedo, new ShaderConfig() { keyword = "_STATIC_DOUBLE_HEIGHTMAP_ALBEDO",hasTopLayer = true, hasAlpha = true, isAlphaHeightMap = true, hasNormalMap = true, hasTopLayerAlbedoMap = true }},
                //{StaticDoubleMode.Heightmap, new ShaderConfig() { keyword = "_STATIC_DOUBLE_HEIGHTMAP",hasTopLayer = true, hasAlpha = true, isAlphaHeightMap = true, hasNormalMap = true }},
            };

            StaticMultLayerConfig = new Dictionary<StaticMultLayerMode, ShaderConfig>(new StaticMultLayerModeComparer())
            {
                {StaticMultLayerMode.Opaque, new ShaderConfig() { keyword = "_STATIC_OPAQUE", useAlbedoTint = true, hasNormalMap = true, isClassicTexture = true, useAlbedoTint2 = true, hasNormalMap2 = true, isClassicTexture2 = true }},
            };

            SubModeKeywords = new List<string>();
            foreach (var item in DynamicConfig)
            {
                if (!SubModeKeywords.Contains(item.Value.keyword))
                {
                    SubModeKeywords.Add(item.Value.keyword);
                }
            }
            foreach (var item in StaticSingleConfig)
            {
                if (!SubModeKeywords.Contains(item.Value.keyword))
                {
                    SubModeKeywords.Add(item.Value.keyword);
                }
            }
            foreach (var item in StaticDoubleConfig)
            {
                if (!SubModeKeywords.Contains(item.Value.keyword))
                {
                    SubModeKeywords.Add(item.Value.keyword);
                }
            }
            foreach (var item in StaticMultLayerConfig)
            {
                if (!SubModeKeywords.Contains(item.Value.keyword))
                {
                    SubModeKeywords.Add(item.Value.keyword);
                }
            }
            foreach (var item in FoliageConfig)
            {
                if (!SubModeKeywords.Contains(item.Value.keyword))
                {
                    SubModeKeywords.Add(item.Value.keyword);
                }
            }
        }

        private static class Styles
        {
            public static GUIContent uvSetLabel = new GUIContent("UV Set");

            public static GUIContent albedoText = new GUIContent("Albedo", "Albedo (RGB) and Transparency (A)");
            public static GUIContent aoOnAlbedoText = new GUIContent("AO Albedo multiply", "intensity that Ao multiplied on Albedo");
            public static GUIContent lowTierOverlayColorText = new GUIContent("Low Tier Overlay Color", "Overlayer Color used in Low quality shader");
            public static GUIContent maskedTintText = new GUIContent("Paint Color", "Color for masked area (Normal alpha).");
            public static GUIContent albedoAsMicroOccText = new GUIContent("Fake Micro Occ", "Fake micro occlusion with albedo luminance");
            public static GUIContent albedoMoLowText = new GUIContent("Fake Micro Occ Black", "Albedo luminance value which represents occlusion value zero");
            public static GUIContent albedoMoHighText = new GUIContent("Fake Micro Occ White", "Albedo luminance value which represents occlusion value one");
            public static GUIContent alphaText = new GUIContent("Alpha", "Transparency (R)");
            public static GUIContent alphaCutoffText = new GUIContent("Alpha Cutoff", "Threshold for alpha cutoff");
            public static GUIContent vaoIntensityText = new GUIContent("AO Intensity", "Strength of vertex ao");
            public static GUIContent billboardIntensityText = new GUIContent("Directi Lighting Intensity", "Strength of direct lighting");
            public static GUIContent minAoIntensityText = new GUIContent("Albedo to Min Ao Value", "Albedo luminance below this value will be regarded as 0");
            public static GUIContent maxAoIntensityText = new GUIContent("Albedo to Max Ao Value", "Albedo luminance above this value will be regarded as 1");
            public static GUIContent directSoftenText = new GUIContent("Direct Lighting soften", "Soften Direct Lighting");
            public static GUIContent daoIntensityText = new GUIContent("Direct Lighting AO Intensity", "Strength of ao apply on Direct Lighting.");
            public static GUIContent grassRootAOText = new GUIContent("Grass Root AO", "Grass Root AO.");
            public static GUIContent grassHorizongtalAOText = new GUIContent("Grass AOin Horizontal Direction", "Grass AO in Horizongtal direction.");
            public static GUIContent grassMaxAOText = new GUIContent("Grass Max AO multiplier", "Max AO of grass.");

            public static GUIContent windWaveSpeed = new GUIContent("Wind Wave Speed", "Wind wave speed.");
            public static GUIContent windWaveFrequency = new GUIContent("Wind Wave Frequency", "Wind wave frequency.");
            public static GUIContent windWavePower = new GUIContent("Wind Wave Power", "Wind wave intensity.");
            public static GUIContent windWaveFadeDistance = new GUIContent("Wind Wave Fade Distance", "Wind wave fade out distance.");
            public static GUIContent windWaveDirection = new GUIContent("Wind Wave Direction", "Wind wave forward direction");

            public static GUIContent grassVertexInteractiveIntensity = new GUIContent("Vetrex Interactive Intensity", "Vetrex Interactive Intensity");
            public static GUIContent grassVertexInteractiveCenterForce = new GUIContent("Vetrex Interactive Center Force", "Vetrex Interactive Center Force");
            public static GUIContent grassFragmentInteractiveIntensity = new GUIContent("Fragment Interactive Intensity", "Fragment Interactive Intensity");

            public static GUIContent specularMapText = new GUIContent("Specular", "Specular (RGB) and Roughness (A)");
            public static GUIContent metallicMapText = new GUIContent("Metallic", "AO (R) and Metallic (B), (G) and (A) are foir ");
            public static GUIContent todLightMapText = new GUIContent("TOD LightMap", "Packed Man-Made lights irradiance(RGB) and Sky GI radiosity(A)");
            public static GUIContent skySoIntesnityText = new GUIContent("Sky Specular Occlusion", "The Intensity that outdoor skylight intensity affect on specular occlusion. Default value is 1(fully affected)");
            public static GUIContent manMadeLightIntensityText = new GUIContent("Man-Made lights Intensity Scale", "Man-Made lights Intensity. Default value is 2.56");
            public static GUIContent manMadeLightSOText = new GUIContent("Man-Made lights Specular Occlusion", "The Intensity that indoor man-made light intensity affect on specular occlusion. Default value is 0(fully disabled)");
            public static GUIContent smoothnessText = new GUIContent("Smoothness", "Smoothness value");
            public static GUIContent highlightsText = new GUIContent("Specular Highlights", "Specular Highlights");
            public static GUIContent reflectionsText = new GUIContent("Reflections", "Glossy Reflections");
            public static GUIContent simpleDynmIBLspecText = new GUIContent("Use Simple Dynamic IBL", "Use Simple Dynamic IBL");
            public static GUIContent normalMapText = new GUIContent("Normal Map", "Normal Map");
            public static GUIContent normalMapScale = new GUIContent("Normal Map Scale", "Normal Map Scale");
            public static GUIContent bentNormalMapText = new GUIContent("Bent Normal Map", "Normal Map");
            public static GUIContent heightMapText = new GUIContent("Height Map", "Height Map (G)");
            public static GUIContent occlusionText = new GUIContent("Occlusion", "Occlusion (G)");
            public static GUIContent emissionText = new GUIContent("Emission", "Emission (RGB)");

            public static GUIContent detailMaskText = new GUIContent("Detail Mask", "Mask for Secondary Maps (A)");
            public static GUIContent detailAlbedoText = new GUIContent("Detail Albedo x2", "Albedo (RGB) multiplied by 2");
            public static GUIContent detailNormalMapText = new GUIContent("Detail Normal Map", "Detail Normal Map");
            public static GUIContent detailNormalMapScaleText = new GUIContent("Detail Normal UV Scale", "Detail Normal UV Scale");
            public static GUIContent detailNormalPowerText = new GUIContent("Detail Normal Power", "Detail Normal Power");

            public static GUIContent topAlbedoText = new GUIContent("Albedo", "Albedo (RGB)");
            public static GUIContent topNormalMapText = new GUIContent("Normal Map", "Normal Map");
            public static GUIContent topNormalMapWithAlbedoText = new GUIContent("Normal Map With Albedo", "Normal Map");

            public static GUIContent absorptionText = new GUIContent("Absorption", "Absorption");
            public static GUIContent absorptionColorText = new GUIContent("Absorption Color", "Absorption Color");
            public static GUIContent absorptionColorAtDistanceText = new GUIContent("Absorption Color At Distance", "Absorption Color At Distance");
            public static GUIContent transmittanceText = new GUIContent("Transmittance", "Transmittance");
            public static GUIContent specularText = new GUIContent("Specular", "Specular");
            public static GUIContent simpleBlendingScaleText = new GUIContent("SimpleBlendingScale", "SimpleBlendingScale");
            public static GUIContent simpleBlendingRoughnessScaleText = new GUIContent("SimpleBlendingRoughnessScale", "SimpleBlendingRoughnessScale");

            public static GUIContent thicknessText = new GUIContent("Thickness", "Thickness");
            public static GUIContent dampText = new GUIContent("Damp", "Damp");
            public static GUIContent normalDampText = new GUIContent("Normal Damp", "Normal Damp");
            public static GUIContent hardnessText = new GUIContent("Hardness", "Hardness");
            public static GUIContent slopeThresholdText = new GUIContent("Slope Threshold", "Slope Threshold");
            public static GUIContent lowOverThresholdText = new GUIContent("Low Over Threshold", "Low Over Threshold");
            public static GUIContent overGravityText = new GUIContent("Gravity", "Gravity");

            public static GUIContent customIBLMapText = new GUIContent("Custom IBL", "IBL cubemap");
            public static GUIContent colorBoostLegacyText = new GUIContent("Color Boost In Legacy", "Boost factor in legacy mode");

            public static GUIContent rimMapText = new GUIContent("Rim Map", "Rim Map");

            public static string primaryMapsText = "Main Maps";
            public static string topMapsText = "Top Layer Maps";
            public static string detailMapsText = "Detail Maps";
            public static string legacyText = "Legacy Map Options";
            public static string forwardText = "Forward Rendering Options";
            public static string emissionTitleText = "Emission Options";
            public static string detailText = "Detail Options";
            public static string subMode = "Sub Mode";
            public static string debugOnlyText = "Debug Only Mode!!!!!!";

            public static string layer1TitleText = "Outer Layer";
            public static string layer2TitleText = "Inner Layer";
            public static string multLayerFallbackSectionTitleText = "Fallback Parameters";

            public static string UVRotation = "UV Rotation";
            public static string EmissionChannel = "Emission Channel From Normal-A";

            public static GUIContent emissiveWarning = new GUIContent("Emissive value is animated but the material has not been configured to support emissive. Please make sure the material itself has some amount of emissive.");
        }

        MaterialProperty subMode = null;
        MaterialProperty custom_IBLCubemap = null;

        ColorPickerHDRConfig m_ColorPickerHDRConfig = new ColorPickerHDRConfig(0f, 99f, 1 / 99f, 3f);

        bool bHaseDetail = false;

        protected override bool defaultDrawTilingOffset { get { return false; } }

        public override void FindProperties(MaterialProperty[] props)
        {
            base.FindProperties(props);
            subMode = FindProperty("_SubMode", props);
            custom_IBLCubemap = FindProperty("custom_IBLCubemap", props, false);
        }


        // tmp:

        protected override void DoFirstTimeApply(Material material, MaterialProperty[] props)
        {
            if (material.GetFloat("_Mode") >= 0)
            {
                material.SetFloat("_SubMode", material.GetFloat("_Mode"));
                material.SetFloat("_Mode", -1);
            }
            var oriBumpMap = FindProperty("_BumpMap", props, false);
            if (oriBumpMap != null && oriBumpMap.textureValue != null)
            {
                material.SetTexture("_BumpMapPakced", oriBumpMap.textureValue);
                oriBumpMap.textureValue = null;
            }
            UpdateCustomSH(material);
            base.DoFirstTimeApply(material, props);
        }

        public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
        {
            InitConfig();
            base.OnGUI(materialEditor, props);
        }

        private void UpdateCustomSH(Material material)
        {
            if (custom_IBLCubemap == null)
                return;
            Cubemap cubemap = custom_IBLCubemap.textureValue as Cubemap;
            if (cubemap == null)
                return;

            SphericalHarmonicsL2 sh = new SphericalHarmonicsL2();
            sh.Clear();
            sh.AddCubemapLight(cubemap);

            var coef = sh.GetShaderConstantsFromNormalizedSH();

            material.SetVector("custom_SHAr", coef[0]);
            material.SetVector("custom_SHAg", coef[1]);
            material.SetVector("custom_SHAb", coef[2]);
            material.SetVector("custom_SHBr", coef[3]);
            material.SetVector("custom_SHBg", coef[4]);
            material.SetVector("custom_SHBb", coef[5]);
            material.SetVector("custom_SHC", coef[6]);
        }



        public static void RefreshCustomSH(Material material)
        {
            Cubemap cubemap = material.GetTexture("custom_IBLCubemap") as Cubemap;

            if (cubemap == null)
                return;

            SphericalHarmonicsL2 sh = new SphericalHarmonicsL2();
            sh.Clear();
            sh.AddCubemapLight(cubemap);

            var coef = sh.GetShaderConstantsFromNormalizedSH();

            material.SetVector("custom_SHAr", coef[0]);
            material.SetVector("custom_SHAg", coef[1]);
            material.SetVector("custom_SHAb", coef[2]);
            material.SetVector("custom_SHBr", coef[3]);
            material.SetVector("custom_SHBg", coef[4]);
            material.SetVector("custom_SHBb", coef[5]);
            material.SetVector("custom_SHC", coef[6]);
        }


        float m_CoverageBoost = -1;
        protected override void DrawHeaders()
        {
        }
        protected override bool DrawManagedProperties(Material material, MaterialProperty[] props)
        {
            var mainMode = MainModeDict[material.shader.name];
            var config = SubModePopup(mainMode);
            //BlendModePopup();
            CullModePopup();
            int indentation = 2; // align with labels of texture properties
            bool needFix = false;
            bool isMultLayerShader = mainMode == MainMode.StaticMultLayer;

            // Primary properties
            GUILayout.Label(isMultLayerShader ? Styles.layer1TitleText : Styles.primaryMapsText, EditorStyles.boldLabel);
            var albedoMap = FindAndMarkProperty("_MainTex", props);
            var alphaCutoff = FindAndMarkProperty("_Cutoff", props);
            var albedoColor = FindAndMarkProperty("_Color", props);
            MarkProperty("_AlbedoAsMicroOcc");
            MarkProperty("_AlbedoMoLow");
            MarkProperty("_AlbedoMoHigh");
            if (!config.noAlbedoMap || showAllProperties)
            {
                m_MaterialEditor.TexturePropertySingleLine(Styles.albedoText, albedoMap, config.useAlbedoTint ? albedoColor : null);
                {
                    AlbedoMode albedoMode = AlbedoMode.RGB;
                    var format = new RequestedMapFormat();
                    format.allowAniso = mainMode != MainMode.Dynamic;

                    if (config.hasAlpha)
                    {
                        format.needAlpha = true;

                        if (config.isAlphaHeightMap)
                            albedoMode = AlbedoMode.WithHeightmap;
                        else
                            albedoMode = AlbedoMode.WithAlpha;
                        if (config.hasCutout && albedoMap.textureValue != null)
                        {
                            format.preserveCoverage = true;
                            format.cutoutAlpha = alphaCutoff.floatValue;

                            if (m_CoverageBoost < 0)
                            {
                                var texImport = AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(albedoMap.textureValue)) as TextureImporter;
                                if (texImport)
                                {
                                    m_CoverageBoost = texImport.alphaTestCoverageBoostInMip;
                                }
                            }

                            m_CoverageBoost = EditorGUILayout.Slider("Boost Coverage", m_CoverageBoost, 0, 4.0f);
                            format.boostCoverage = m_CoverageBoost;
                        }
                    }
                    else
                    {
                        albedoMode = AlbedoMode.RGB;
                    }

                    if (FixTexture(albedoMap.textureValue, format))
                        needFix = true;
                    DrawTextureSimpleInfo(albedoMap.textureValue, albedoMode.ToString());
                }

                var albedoAsMicroOcc = FindAndMarkProperty("_AlbedoAsMicroOcc", props, false);
                var albedoMoLow = FindAndMarkProperty("_AlbedoMoLow", props, albedoAsMicroOcc != null);
                var albedoMoHigh = FindAndMarkProperty("_AlbedoMoHigh", props, albedoAsMicroOcc != null);
                if (albedoAsMicroOcc != null && config.allowAlbedoMicroOcc)
                {
                    m_MaterialEditor.ShaderProperty(albedoAsMicroOcc, Styles.albedoAsMicroOccText);
                    if (!albedoAsMicroOcc.hasMixedValue)
                    {
                        bool useAlbedoMicroOcc = albedoAsMicroOcc.floatValue != 0;
                        if (useAlbedoMicroOcc)
                        {
                            m_MaterialEditor.ShaderProperty(albedoMoLow, Styles.albedoMoLowText);
                            m_MaterialEditor.ShaderProperty(albedoMoHigh, Styles.albedoMoHighText);
                        }
                    }
                }
            }
            if (config.useAlbedoTint || showAllProperties)
            {
                m_MaterialEditor.ShaderProperty(albedoColor, Styles.albedoText);
            }

            if(config.multiplyAoOnAlbedo)
            {
                var aoOnAlbedo = FindAndMarkProperty("_AoAlbedoMultiplier", props, false);
                m_MaterialEditor.ShaderProperty(aoOnAlbedo, Styles.aoOnAlbedoText);
            }


            MarkProperty("_PaintColor");
            if (config.canUseAlbedoMaskTint || showAllProperties)
            {
                var maskedAlbedoColor = FindAndMarkProperty("_PaintColor", props, false);
                m_MaterialEditor.ShaderProperty(maskedAlbedoColor, Styles.maskedTintText);
            }
            if (!config.useAlbedoTint)
            {
                albedoColor.colorValue = Color.white;
            }
            var alphaMap = FindAndMarkProperty("_AlphaMap", props, false);
            //if ((config.hasAlphaMap || showAllProperties) && alphaMap != null)
            //{
            //    m_MaterialEditor.TexturePropertySingleLine(Styles.alphaText, alphaMap);

            //    var format = new RequestedMapFormat();
            //    if (FixTexture(alphaMap.textureValue, format))
            //        needFix = true;
            //    DrawTextureSimpleInfo(alphaMap.textureValue, "Alpha");

            //    if (config.hasAlphaTilingOffset || showAllProperties)
            //    {
            //        m_MaterialEditor.TextureScaleOffsetProperty(alphaMap);
            //    }
            //}


            MarkProperty("_CustomShadowIntensity");
            if(config.lowTierCustomShadowIntensity)
            {
                var customMainlightIntensityShadowMap = FindAndMarkProperty("_CustomShadowIntensity", props, false);
                m_MaterialEditor.ShaderProperty(customMainlightIntensityShadowMap,"Low Tier Shadow Intensity");
            }

            MarkProperty("_AdvancedShadow");
            MarkProperty("_UseCutoffShadow");
            MarkProperty("_CutoffShadow");
            if (config.hasCutout || showAllProperties)
            {
                m_MaterialEditor.ShaderProperty(alphaCutoff, Styles.alphaCutoffText.text, MaterialEditor.kMiniTextureFieldLabelIndentLevel + 1);
                var advancedShadow = FindAndMarkProperty("_AdvancedShadow", props, false);
                if (config.canUseCutoutShadow || (showAllProperties && advancedShadow != null))
                {
                    EditorGUI.indentLevel = MaterialEditor.kMiniTextureFieldLabelIndentLevel + 1;
                    bool useAdvancedShadow = advancedShadow.floatValue == 1;
                    bool newUseAdvancedShadow = EditorGUILayout.Toggle("Use Cutout Shadow", useAdvancedShadow);
                    if (newUseAdvancedShadow != useAdvancedShadow)
                    {
                        advancedShadow.floatValue = newUseAdvancedShadow ? 1.0f : 0.0f;
                    }

                    if (newUseAdvancedShadow && config.hasSeparateCutoutShadow)
                    {
                        var useCutoffShadow = FindAndMarkProperty("_UseCutoffShadow", props);
                        var cutoffShadow = FindAndMarkProperty("_CutoffShadow", props);
                        bool oldUseSeparateCutoutShadow = useCutoffShadow.floatValue == 1;
                        bool useSeparateCutoutShadow = EditorGUILayout.Toggle("Use Separate Shadow Cutout Value", oldUseSeparateCutoutShadow);
                        if (useSeparateCutoutShadow != oldUseSeparateCutoutShadow)
                        {
                            useCutoffShadow.floatValue = useSeparateCutoutShadow ? 1.0f : 0.0f;
                        }
                        if (useSeparateCutoutShadow)
                        {
                            m_MaterialEditor.ShaderProperty(cutoffShadow, "Shadow Cutoff", MaterialEditor.kMiniTextureFieldLabelIndentLevel + 1);
                        }
                        else
                        {
                            if (cutoffShadow.floatValue != alphaCutoff.floatValue)
                                cutoffShadow.floatValue = alphaCutoff.floatValue;
                        }
                    }
                    EditorGUI.indentLevel = 0;
                }
            }

            bool hasRoughnessMap = false;

            //var rimMap = FindAndMarkProperty("_CutRimTex", props, false);
            //if ((config.hasRimMap || showAllProperties) && rimMap != null)
            //{
            //    m_MaterialEditor.TexturePropertySingleLine(Styles.rimMapText, rimMap);
            //    {
            //        AlbedoMode albedoMode = AlbedoMode.RGB;
            //        var format = new RequestedMapFormat();
            //        format.allowAniso = mainMode != MainMode.Dynamic;

            //        if (config.hasAlpha && !config.hasAlphaMap)
            //        {
            //            format.needAlpha = true;

            //            if (config.isAlphaHeightMap)
            //                albedoMode = AlbedoMode.WithHeightmap;
            //            else
            //                albedoMode = AlbedoMode.WithAlpha;
            //        }
            //        else
            //        {
            //            albedoMode = AlbedoMode.RGB;
            //        }

            //        if (FixTexture(rimMap.textureValue, format))
            //            needFix = true;
            //        DrawTextureSimpleInfo(rimMap.textureValue, albedoMode.ToString());
            //    }
            //}

            MarkProperty("_GrassVertexProperties");
            MarkProperty("_FoliageVertexProperties");
            MarkProperty("_FoliageBillboardProperties");

            MarkProperty("_ENABLE_GRASS_VERTEX_INTERACTIVE");
            MarkProperty("_ENABLE_GRASS_FRAGMENT_INTERACTIVE");
            MarkProperty("_GrassInteractionVertexIntensity");
            MarkProperty("_GrassInteractionVertexCenterForce");
            MarkProperty("_GrassInteractionFragmentIntensity");

            MarkProperty("_ENABLE_WIND_WAVE");
            MarkProperty("_WindWaveNoiseMap");
            MarkProperty("_WindWaveSpeed");
            MarkProperty("_WindWaveFrequency");
            MarkProperty("_WindWavePower");
            MarkProperty("_WindWaveDirection");
            MarkProperty("_WindFadeDistance");

            if (config.foliage)
            {
                var grassVertexInteractive = FindAndMarkProperty("_ENABLE_GRASS_VERTEX_INTERACTIVE", props, false);
                var grassFragmentInteractive = FindAndMarkProperty("_ENABLE_GRASS_FRAGMENT_INTERACTIVE", props, false);
                var grassVertexInteractiveIntensity = FindAndMarkProperty("_GrassInteractionVertexIntensity", props, false);
                var grassVertexInteractiveCenterForce = FindAndMarkProperty("_GrassInteractionVertexCenterForce", props, false);
                var grassFragmentInteractiveIntensity = FindAndMarkProperty("_GrassInteractionFragmentIntensity", props, false);

                var windWave = FindAndMarkProperty("_ENABLE_WIND_WAVE", props, false);


                if (config.isWindWave && windWave != null)
                {
                    bool isWindWave = EditorGUILayout.Toggle("WindWave", windWave.floatValue > 0f);
                    windWave.floatValue = isWindWave ? 1f : 0f;

                    if (isWindWave)
                    {
                        // wind simulator
                        EditorGUILayout.BeginVertical("box");
                        {
                            EditorGUILayout.LabelField("Wind Simulator", EditorStyles.boldLabel);

                            Vector4 windData = Shader.GetGlobalVector("_GlobalFoliageWindData");
                            float windSpeed = windData.w;
                            Vector3 windDir = new Vector3(windData.x, windData.y, windData.z);
                            float windLevel = AtmosphericScattering.WindSpeedToLevel(windSpeed);
                            windLevel = EditorGUILayout.Slider("Level", windLevel, 0, 12);
                            windSpeed = AtmosphericScattering.WindLevelToSpeed(windLevel);

                            if (windDir == Vector3.zero)
                            {
                                windDir = Vector3.forward;
                            }

                            windDir = EditorGUILayout.Vector3Field("Direction", windDir);
                            windDir.Normalize();

                            windData.x = windDir.x;
                            windData.y = windDir.y;
                            windData.z = windDir.z;
                            windData.w = windSpeed;

                            Shader.SetGlobalVector("_GlobalFoliageWindData", windData);
                        }
                        EditorGUILayout.EndVertical();


                        if (config.grass)   // grass setting for wind
                        {
                            EditorGUI.indentLevel++;

                            var _GrassSwingParam0 = FindAndMarkProperty("_GrassSwingParam0", props, false);
                            var _GrassSwingParam1 = FindAndMarkProperty("_GrassSwingParam1", props, false);
                            var _GrassSwingIntensity = FindAndMarkProperty("_GrassSwingIntensity", props, false);
                            var _GrassSwingFreq = FindAndMarkProperty("_GrassSwingFreq", props, false);
                            var _GrassSwingScale = FindAndMarkProperty("_GrassSwingScale", props, false);

                            var GrassSwingParam0 = _GrassSwingParam0.vectorValue;
                            var GrassSwingParam1 = _GrassSwingParam1.vectorValue;
                            var GrassSwingIntensity = _GrassSwingIntensity.vectorValue;
                            var GrassSwingFreq = _GrassSwingFreq.vectorValue;
                            var GrassSwingScale = _GrassSwingScale.vectorValue;

                            // swingAngle
                            float mainTiltBaseFreq = GrassSwingParam0.x;
                            float minorTiltBaseFreq1 = GrassSwingParam0.y;
                            float minorTiltBaseFreq2 = GrassSwingParam0.z;
                            float tangentTiltBaseFreq = GrassSwingParam0.w;

                            // base freq:
                            float maxHorizontalTiltAngle = GrassSwingParam1.x;
                            float maxPushAngle = GrassSwingParam1.y;
                            // z / w is occupied by interaction
                            //float a = GrassSwingParam1.z;
                            //float b = GrassSwingParam1.w;

                            // Intensity delta:
                            float mainTiltIntensityDelta= GrassSwingIntensity.x;
                            float minorTiltIntensityDelta1 = GrassSwingIntensity.y;
                            float minorTiltIntensityDelta2 = GrassSwingIntensity.z;
                            float tangentTiltIntensityDelta = GrassSwingIntensity.w;

                            // Freq delta:
                            float mainTiltFreqDelta = GrassSwingFreq.x;
                            float minorTiltFreqDelta1 = GrassSwingFreq.y;
                            float minorTiltFreqDelta2 = GrassSwingFreq.z;
                            float tangentTiltFreqDelta = GrassSwingFreq.w;

                            // Scale:
                            float mainTiltScale = GrassSwingScale.x;
                            float minorTiltScale1 = GrassSwingScale.y;
                            float minorTiltScale2 = GrassSwingScale.z;
                            float tangentTiltScale = GrassSwingScale.w;

                            EditorGUILayout.LabelField("General Swing", EditorStyles.boldLabel);
                            EditorGUI.indentLevel++;
                            {
                                EditorGUILayout.MinMaxSlider("Tilt Angle Range", ref maxHorizontalTiltAngle, ref maxPushAngle, 0, 1.0f);
                                EditorGUILayout.Space();
                                mainTiltIntensityDelta = EditorGUILayout.Slider("Intensity Delta", mainTiltIntensityDelta, 0, 5f);
                                EditorGUILayout.Space();
                                mainTiltBaseFreq = EditorGUILayout.Slider("Frequency ", mainTiltBaseFreq, 0, 5);
                                mainTiltFreqDelta = EditorGUILayout.Slider("Frequency Delta", mainTiltFreqDelta, 0, 5);
                                EditorGUILayout.Space();
                                mainTiltScale = EditorGUILayout.Slider("Random", mainTiltScale, 0, 20);
                            }
                            EditorGUI.indentLevel--;

                            EditorGUILayout.LabelField("Minor Swing", EditorStyles.boldLabel);
                            EditorGUI.indentLevel++;
                            {
                                EditorGUILayout.LabelField("Swing 1", EditorStyles.boldLabel);
                                minorTiltIntensityDelta1 = EditorGUILayout.Slider("Intensity Delta", minorTiltIntensityDelta1, 0, 0.1f);
                                EditorGUILayout.Space();
                                minorTiltBaseFreq1 = EditorGUILayout.Slider("Base Frequency", minorTiltBaseFreq1, 0, 5);
                                minorTiltFreqDelta1 = EditorGUILayout.Slider("Delta", minorTiltFreqDelta1, 0, 5);
                                EditorGUILayout.Space();
                                minorTiltScale1 = EditorGUILayout.Slider("Random", minorTiltScale1, 0, 20);

                                EditorGUILayout.Space();
                                EditorGUILayout.LabelField("Swing 2", EditorStyles.boldLabel);
                                minorTiltIntensityDelta2 = EditorGUILayout.Slider("Intensity Delta", minorTiltIntensityDelta2, 0, 0.1f);
                                EditorGUILayout.Space();
                                minorTiltBaseFreq2 = EditorGUILayout.Slider("Base Frequency", minorTiltBaseFreq2, 0, 5);
                                minorTiltFreqDelta2 = EditorGUILayout.Slider("Delta", minorTiltFreqDelta2, 0, 5);
                                EditorGUILayout.Space();
                                minorTiltScale2 = EditorGUILayout.Slider("Random", minorTiltScale2, 0, 20);
                            }
                            EditorGUI.indentLevel--;

                            EditorGUILayout.LabelField("Tangent Swing", EditorStyles.boldLabel);
                            EditorGUI.indentLevel++;
                            {
                                tangentTiltIntensityDelta = EditorGUILayout.Slider("Intensity Delta", tangentTiltIntensityDelta, 0, 5f);
                                EditorGUILayout.Space();
                                tangentTiltBaseFreq = EditorGUILayout.Slider("Base Frequency ", tangentTiltBaseFreq, 0, 5);
                                tangentTiltFreqDelta = EditorGUILayout.Slider("Delta", tangentTiltFreqDelta, 0, 5);
                                EditorGUILayout.Space();
                                tangentTiltScale = EditorGUILayout.Slider("Random", tangentTiltScale, 0, 20);
                            }
                            EditorGUI.indentLevel--;

                            GrassSwingParam0.x  = mainTiltBaseFreq ;
                            GrassSwingParam0.y  = minorTiltBaseFreq1 ;
                            GrassSwingParam0.z  = minorTiltBaseFreq2 ;
                            GrassSwingParam0.w  = tangentTiltBaseFreq;

                            GrassSwingParam1.x = maxHorizontalTiltAngle;
                            GrassSwingParam1.y = maxPushAngle;
                            //GrassSwingParam1.z = a;
                            //GrassSwingParam1.w = b;

                            GrassSwingIntensity.x = mainTiltIntensityDelta;
                            GrassSwingIntensity.y = minorTiltIntensityDelta1;
                            GrassSwingIntensity.z = minorTiltIntensityDelta2;
                            GrassSwingIntensity.w = tangentTiltIntensityDelta;

                            GrassSwingFreq.x=  mainTiltFreqDelta ;   
                            GrassSwingFreq.y=  minorTiltFreqDelta1 ; 
                            GrassSwingFreq.z=  minorTiltFreqDelta2 ; 
                            GrassSwingFreq.w = tangentTiltFreqDelta;

                            GrassSwingScale.x=  mainTiltScale     ;
                            GrassSwingScale.y=  minorTiltScale1   ;
                            GrassSwingScale.z=  minorTiltScale2   ;
                            GrassSwingScale.w = tangentTiltScale;


                            _GrassSwingParam0.vectorValue = GrassSwingParam0;
                            _GrassSwingParam1.vectorValue = GrassSwingParam1;
                            _GrassSwingIntensity.vectorValue = GrassSwingIntensity;
                            _GrassSwingFreq.vectorValue = GrassSwingFreq;
                            _GrassSwingScale.vectorValue = GrassSwingScale;

                            EditorGUI.indentLevel--;

                        }
                        else
                        {
                            EditorGUI.indentLevel++;



                            // other foliage
                            var foliageSwingParam0 = FindAndMarkProperty("_FoliageSwingParam0", props, false);
                            var foliageSwingParam1 = FindAndMarkProperty("_FoliageSwingParam1", props, false);
                            var foliageSwingParam2 = FindAndMarkProperty("_FoliageSwingParam2", props, false);
                            var foliageSwingFreq = FindAndMarkProperty("_FoliageGeneralSwingFrequency", props, false);
                            var foliageSwingRandom = FindAndMarkProperty("_FoliageSwingRandom", props, false);

                            float rootOffset = foliageSwingParam0.vectorValue.x;  // the root offset of foliage to the original point
                            float treeHeightRcp = foliageSwingParam0.vectorValue.y;   // tree height rcp
                            float generalSwingIntensity = foliageSwingParam0.vectorValue.z;   // swing intensity by the wind
                            float leaveAndBranchesSwingIntensity = foliageSwingParam0.vectorValue.w;   // swing intensity of leave and branches

                            float minorSwingAoWeightMin = foliageSwingParam1.vectorValue.x;  // minimum Ao Intensity 
                            float minorSwingAoWeightRangeRcp = foliageSwingParam1.vectorValue.y;   // Ao weight range rcp
                            float generalSwingDrag = foliageSwingParam1.vectorValue.z;  
                            float minorSwingDrag = foliageSwingParam1.vectorValue.w;

                            float generalIntensityDelta = foliageSwingParam2.vectorValue.x;  
                            float generalFreqDelta = foliageSwingParam2.vectorValue.y;   
                            float minorIntensityDelta = foliageSwingParam2.vectorValue.z;
                            float minorFreqDelta = foliageSwingParam2.vectorValue.w;

                            float generalSwingFreq = foliageSwingFreq.vectorValue.x;    // general swing frequency of foliage
                            float minorSwingFreq_A = foliageSwingFreq.vectorValue.y;   // minor swing of branches and leaves 
                            float minorSwingFreq_B = foliageSwingFreq.vectorValue.z;
                            float minorSwingFreq_C = foliageSwingFreq.vectorValue.w;

                            float generalSwingRandom = foliageSwingRandom.vectorValue.x;
                            float minorSwingRandomq_A = foliageSwingRandom.vectorValue.y;
                            float minorSwingRandomq_B = foliageSwingRandom.vectorValue.z;
                            float minorSwingRandomq_C = foliageSwingRandom.vectorValue.w;

                            EditorGUILayout.LabelField("General Swing", EditorStyles.boldLabel);
                            EditorGUI.indentLevel++;
                            {
                                generalSwingIntensity = EditorGUILayout.Slider("Intensity", generalSwingIntensity, 0, 20);
                                generalIntensityDelta = EditorGUILayout.Slider("Delta", generalIntensityDelta, 0, 3f);
                                EditorGUILayout.Space();
                                generalSwingFreq = EditorGUILayout.Slider("Frequency", generalSwingFreq, 0, 2);
                                generalFreqDelta = EditorGUILayout.Slider("Delta", generalFreqDelta, 0, 0.5f);
                                EditorGUILayout.Space();
                                generalSwingRandom = EditorGUILayout.Slider("Random", generalSwingRandom, 0, 50);
                                EditorGUILayout.Space();

                                generalSwingDrag = EditorGUILayout.Slider("Wind Drag", generalSwingDrag, 0, 2);
                                rootOffset = EditorGUILayout.Slider("Root Offset", rootOffset, 0, 50);
                                float treeHeight = 1 / treeHeightRcp;
                                EditorGUI.BeginChangeCheck();
                                treeHeight = EditorGUILayout.Slider("Tree Height", treeHeight, 0, 50);
                                if (EditorGUI.EndChangeCheck())
                                    treeHeightRcp = 1 / treeHeight;
                            }
                            EditorGUI.indentLevel--;

                            EditorGUILayout.Space();

                            EditorGUILayout.LabelField("Minor Swing", EditorStyles.boldLabel);
                            EditorGUI.indentLevel++;
                            {
                                float range = 1 / minorSwingAoWeightRangeRcp;
                                float minWeight = minorSwingAoWeightMin;
                                float maxWeight = minWeight + range;
                                EditorGUI.BeginChangeCheck();
                                EditorGUILayout.MinMaxSlider("Ao weight Range", ref minWeight, ref maxWeight, 0, 1);
                                if (EditorGUI.EndChangeCheck())
                                {
                                    minorSwingAoWeightMin = minWeight;
                                    minorSwingAoWeightRangeRcp = 1 / (maxWeight - minWeight);
                                }

                                EditorGUILayout.Space();

                                leaveAndBranchesSwingIntensity = EditorGUILayout.Slider("Intensity", leaveAndBranchesSwingIntensity, 0, 1);

                                minorIntensityDelta = EditorGUILayout.Slider("Delta", minorIntensityDelta, 0, 1f);
                                EditorGUILayout.Space();


                                minorSwingFreq_A = EditorGUILayout.Slider("Frequency X", minorSwingFreq_A, 0, 3);
                                minorSwingFreq_B = EditorGUILayout.Slider("Frequency Y", minorSwingFreq_B, 0, 3);
                                minorSwingFreq_C = EditorGUILayout.Slider("Frequency Z", minorSwingFreq_C, 0, 3);

                                minorFreqDelta = EditorGUILayout.Slider("Delta", minorFreqDelta, 0, 5f);
                                EditorGUILayout.Space();

                                minorSwingDrag = EditorGUILayout.Slider("Wind Drag", minorSwingDrag, 0, 2);
                                EditorGUILayout.Space();

                                minorSwingRandomq_A = EditorGUILayout.Slider("Random X", minorSwingRandomq_A, -10, 10);
                                minorSwingRandomq_B = EditorGUILayout.Slider("Random Y", minorSwingRandomq_B, -10, 10);
                                minorSwingRandomq_C = EditorGUILayout.Slider("Random Z", minorSwingRandomq_C, -10, 10);
                            }
                            EditorGUI.indentLevel--;

                            Vector4 foliageSwingParam0Val = Vector4.zero;
                            foliageSwingParam0Val.x = rootOffset;
                            foliageSwingParam0Val.y = treeHeightRcp;
                            foliageSwingParam0Val.z = generalSwingIntensity;
                            foliageSwingParam0Val.w = leaveAndBranchesSwingIntensity;

                            Vector4 foliageSwingParam1Val = Vector4.zero;
                            foliageSwingParam1Val.x = minorSwingAoWeightMin;
                            foliageSwingParam1Val.y = minorSwingAoWeightRangeRcp;
                            foliageSwingParam1Val.z = generalSwingDrag;
                            foliageSwingParam1Val.w = minorSwingDrag;

                            Vector4 foliageSwingParam2Val = Vector4.zero;
                            foliageSwingParam2Val.x = generalIntensityDelta;
                            foliageSwingParam2Val.y = generalFreqDelta;
                            foliageSwingParam2Val.z = minorIntensityDelta;
                            foliageSwingParam2Val.w = minorFreqDelta;

                            Vector4 swingRandom = Vector4.zero;
                            swingRandom.x = generalSwingFreq;
                            swingRandom.y = minorSwingFreq_A;
                            swingRandom.z = minorSwingFreq_B;
                            swingRandom.w = minorSwingFreq_C;

                            Vector4 freqVal = Vector4.zero;
                            freqVal.x = generalSwingRandom ;
                            freqVal.y = minorSwingRandomq_A;
                            freqVal.z = minorSwingRandomq_B;
                            freqVal.w = minorSwingRandomq_C;

                            foliageSwingParam0.vectorValue = foliageSwingParam0Val;
                            foliageSwingParam1.vectorValue = foliageSwingParam1Val;
                            foliageSwingParam2.vectorValue = foliageSwingParam2Val;
                            foliageSwingFreq.vectorValue = swingRandom;
                            foliageSwingRandom.vectorValue = freqVal;

                            EditorGUI.indentLevel--;
                        }
                    }

                    SetKeyword(material, "_WIND_WAVE", isWindWave);
                }

                if (config.isGrassVertexInteractive && grassVertexInteractive != null)
                {
                    bool isGrassVertexInteractive = EditorGUILayout.Toggle("Vertex Interactive", grassVertexInteractive.floatValue > 0f);
                    grassVertexInteractive.floatValue = isGrassVertexInteractive ? 1f : 0f;

                    if (config.grass && isGrassVertexInteractive)
                    {
                        EditorGUILayout.LabelField("Grass Interaction", EditorStyles.boldLabel);

                        EditorGUI.indentLevel++;

                        var _GrassSwingParam1 = FindAndMarkProperty("_GrassSwingParam1", props, false);

                        var grassInteractionParamVal0 = _GrassSwingParam1.vectorValue;

                        const float tiltAngleConvert = 1.0f / 0.25f;

                        //float x = grassInteractionParamVal0.x;
                        //float y = grassInteractionParamVal0.y;

                        float maxTiltAngle = grassInteractionParamVal0.z;
                        float stiffness = grassInteractionParamVal0.w;

                        maxTiltAngle = EditorGUILayout.Slider("Max Tilt Angle", maxTiltAngle, 0, 1);
                        //stiffness = EditorGUILayout.Slider("Stiffness", stiffness, 0, 1);

                        //maxTiltAngle /= tiltAngleConvert;

                        //grassInteractionParamVal0.x = x;
                        //grassInteractionParamVal0.y = y;

                        grassInteractionParamVal0.z = maxTiltAngle;
                        grassInteractionParamVal0.w = stiffness;

                        _GrassSwingParam1.vectorValue = grassInteractionParamVal0;

                        EditorGUI.indentLevel--;
                    }

                    SetKeyword(material, "_GRASS_VERTEX_INTERACTIVE", isGrassVertexInteractive);

                    //bool isGrassVertexInteractive = EditorGUILayout.Toggle("Vertex Interactive", grassVertexInteractive.floatValue > 0f);
                    //grassVertexInteractive.floatValue = isGrassVertexInteractive ? 1f : 0f;

                    //if (isGrassVertexInteractive)
                    //{
                    //    grassVertexInteractiveIntensity.floatValue = EditorGUILayout.Slider(Styles.grassVertexInteractiveIntensity, grassVertexInteractiveIntensity.floatValue, 0f, 2f);
                    //    grassVertexInteractiveCenterForce.floatValue = EditorGUILayout.Slider(Styles.grassVertexInteractiveCenterForce, grassVertexInteractiveCenterForce.floatValue, 0f, 1f);
                    //}

                    //SetKeyword(material, "_GRASS_VERTEX_INTERACTIVE", isGrassVertexInteractive);
                }

                // if (config.isGrassFragmentInteractive && grassFragmentInteractive != null)
                // {
                //     bool isGrassFragmentInteractive = EditorGUILayout.Toggle("Fragment Interactive", grassFragmentInteractive.floatValue > 0f);
                //     grassFragmentInteractive.floatValue = isGrassFragmentInteractive ? 1f : 0f;

                //     if (isGrassFragmentInteractive)
                //     {
                //         grassFragmentInteractiveIntensity.floatValue = EditorGUILayout.Slider(Styles.grassFragmentInteractiveIntensity, grassFragmentInteractiveIntensity.floatValue, 0f, 2f);
                //     }

                //     SetKeyword(material, "_GRASS_FRAGMENT_INTERACTIVE", isGrassFragmentInteractive);
                // }

                if (config.grass)
                {
                    var grassLightingProps = FindAndMarkProperty("_GrassVertexProperties", props, false);
                    float rootAoIntensity = grassLightingProps.vectorValue.x;
                    float maxAoIntensity = grassLightingProps.vectorValue.y;
                    //float horizontalAoIntensity = grassLightingProps.vectorValue.z;
                    float aoApplyOnDirectLight = grassLightingProps.vectorValue.w;
                    rootAoIntensity = EditorGUILayout.Slider(Styles.grassRootAOText.text, rootAoIntensity, 0, 1);
                    // horizontalAoIntensity = EditorGUILayout.Slider(Styles.grassHorizongtalAOText.text, horizontalAoIntensity, 0, 1);
                    maxAoIntensity = EditorGUILayout.Slider(Styles.grassMaxAOText.text, maxAoIntensity, 0, 20);
                    aoApplyOnDirectLight = EditorGUILayout.Slider(Styles.directSoftenText.text, aoApplyOnDirectLight, 0, 1);
                    grassLightingProps.vectorValue = new Vector4(rootAoIntensity, maxAoIntensity, 0.0f, aoApplyOnDirectLight);
                }
                else if (config.foliageBillboard)
                {
                    var foliageLightingProps = FindAndMarkProperty("_FoliageBillboardProperties", props, false);
                    float albedoToMinAo = foliageLightingProps.vectorValue.x;
                    float albedoToMaxAo = foliageLightingProps.vectorValue.y;
                    float directAoIntensity = foliageLightingProps.vectorValue.z;
                    float directLightIntensity = foliageLightingProps.vectorValue.w;

                    albedoToMinAo = EditorGUILayout.Slider(Styles.minAoIntensityText.text, albedoToMinAo, 0, 1);
                    albedoToMaxAo = EditorGUILayout.Slider(Styles.maxAoIntensityText.text, albedoToMaxAo, 0.001f, 1);
                    directLightIntensity = EditorGUILayout.Slider(Styles.billboardIntensityText.text, directLightIntensity, 0.0f, 20);
                    directAoIntensity = EditorGUILayout.Slider(Styles.daoIntensityText.text, directAoIntensity, 0, 3);
                    foliageLightingProps.vectorValue = new Vector4(albedoToMinAo, albedoToMaxAo, directAoIntensity, directLightIntensity);
                }
                else
                {
                    var foliageLightingProps = FindAndMarkProperty("_FoliageVertexProperties", props, false);
                    float aoIntensity = foliageLightingProps.vectorValue.x;
                    float directSoften = foliageLightingProps.vectorValue.y;
                    float directAoIntensity = foliageLightingProps.vectorValue.z;
                    aoIntensity = EditorGUILayout.Slider(Styles.vaoIntensityText.text, aoIntensity, 0, 1);
                    directAoIntensity = EditorGUILayout.Slider(Styles.daoIntensityText.text, directAoIntensity, 0, 3);
                    directSoften = EditorGUILayout.Slider(Styles.directSoftenText.text, directSoften, 0, 1);
                    foliageLightingProps.vectorValue = new Vector4(aoIntensity, directSoften, directAoIntensity, 0.0f);

                }
            }
            //
            MarkProperty("_dlEmissionIntensity");
            MarkProperty("_dlEmissionColor");
            MarkProperty("_TimeOffset");
            MarkProperty("_TimeScale");
            if (config.hasAlphaAsEmission)
            {
                // var format = new RequestedMapFormat();
                // format.needAlpha = true;
                var emissionIntensity = FindAndMarkProperty("_dlEmissionIntensity", props, false);
                var emissionColor = FindAndMarkProperty("_dlEmissionColor", props, false);
                var TimeOffset = FindAndMarkProperty("_TimeOffset", props, false);
                var TimeScale = FindAndMarkProperty("_TimeScale", props, false);
                m_MaterialEditor.ShaderProperty(emissionIntensity, emissionIntensity.displayName, indentation);
                m_MaterialEditor.ShaderProperty(emissionColor, emissionColor.displayName, indentation);
                m_MaterialEditor.ShaderProperty(TimeOffset, TimeOffset.displayName, indentation);
                m_MaterialEditor.ShaderProperty(TimeScale, TimeScale.displayName, indentation);
            }
            MarkProperty("_Translucency");
            MarkProperty("_TranslucencyColor");
            if (config.hasTranslucency)
            {
                var translucency = FindAndMarkProperty("_Translucency", props, false);
                var translucencyColor = FindAndMarkProperty("_TranslucencyColor", props, false);
                m_MaterialEditor.ShaderProperty(translucency, translucency.displayName, indentation);
                m_MaterialEditor.ShaderProperty(translucencyColor, translucencyColor.displayName, indentation);
            }
            MarkProperty("_BumpMapPakced");
            if (config.hasNormalMap || showAllProperties)
            {
                string text = "Normal Map";
                if (config.isNormalWithAo)
                {
                    text += " with AO";
                }
                var bumpMap = FindAndMarkProperty("_BumpMapPakced", props);
                m_MaterialEditor.TexturePropertySingleLine(new GUIContent(text), bumpMap);
                {
                    NormalMode normalMode = NormalMode.Normal;
                    var format = new RequestedMapFormat();
                    format.allowAniso = mainMode != MainMode.Dynamic;
                    format.sRGB = false;
                    if (config.hasNormalMapAlpha)
                    {
                        format.needAlpha = true;
                    }
                    if (config.isClassicTexture)
                    {
                        normalMode = NormalMode.Normal;
                        format.mipMode = TextureImporterMipFilter.KaiserFilter;
                    }
                    else if (config.isNormalWithAo)
                    {
                        normalMode = NormalMode.PackRoughness;
                        format.mipMode = TextureImporterMipFilter.NormalX;
                    }
                    else
                    {
                        normalMode = NormalMode.PackRoughness;
                        hasRoughnessMap = true;
                        format.mipMode = TextureImporterMipFilter.NormalGlossiness;
                    }
                    if (FixTexture(bumpMap.textureValue, format))
                        needFix = true;
                    DrawTextureSimpleInfo(bumpMap.textureValue, "NormalMode: " + normalMode.ToString());
                }
            }

            MarkProperty("_TodLightMap");
            MarkProperty("_TodParameter");
            MarkProperty("_TodFakeShadowCoeff");
            if (config.hasTodLightmap || showAllProperties)
            {
                var todLightMap = FindAndMarkProperty("_TodLightMap", props, false);
                var todParameter = FindAndMarkProperty("_TodParameter", props, false);
                var todFakeShadowCoef = FindAndMarkProperty("_TodFakeShadowCoeff", props, false);
                m_MaterialEditor.TexturePropertySingleLine(Styles.todLightMapText, todLightMap);

                // tod parameters:
                Vector4 tod = todParameter.vectorValue;
                float skySoIntesnity = tod.x;
                float shadowBoostRange = tod.y;
                float manMadeLightSOIntesnity = tod.z;
                float shadowBoost = tod.w;

                skySoIntesnity = EditorGUILayout.Slider(Styles.skySoIntesnityText.text, skySoIntesnity, 0, 1);
                manMadeLightSOIntesnity = EditorGUILayout.Slider(Styles.manMadeLightSOText.text, manMadeLightSOIntesnity, 0, 1);

                shadowBoost = EditorGUILayout.Slider("Shadowboost", shadowBoost, 0, 3);
                shadowBoostRange = EditorGUILayout.Slider("ShadowboostRange", shadowBoostRange, 0.0001f, 5);

                tod.Set(skySoIntesnity, shadowBoostRange, manMadeLightSOIntesnity, shadowBoost);
                todParameter.vectorValue = tod;

                // fake shadow:
                Vector4 fakeShadow = todFakeShadowCoef.vectorValue;

                float minSkyAoAsShadow = fakeShadow.x;
                float shadowSharpness = fakeShadow.y;

                minSkyAoAsShadow = EditorGUILayout.Slider("min ao threshold", minSkyAoAsShadow, 0, 1);
                shadowSharpness = EditorGUILayout.Slider("shadow sharpness", shadowSharpness, 1, 15);
                fakeShadow.Set(minSkyAoAsShadow, shadowSharpness, 0,0);
                todFakeShadowCoef.vectorValue = fakeShadow;
            }

            MarkProperty("_MetallicRoughnessMap");
            if (config.hasMetallicMap || showAllProperties)
            {
                var metallicMap = FindAndMarkProperty("_MetallicRoughnessMap", props, false);
                m_MaterialEditor.TexturePropertySingleLine(Styles.metallicMapText, metallicMap);
                if (config.isClassicTexture)
                {
                    hasRoughnessMap = true;
                }
                {
                    var format = new RequestedMapFormat();
                    format.sRGB = false;
                    MaskMode maskMode;
                    if (config.isClassicTexture)
                    {
                        maskMode = MaskMode.AoRoughnessMetallic;
                    }
                    else
                    {
                        maskMode = MaskMode.AoMetallic;
                    }

                    if(config.hasAdvanceDetail)
                    {
                        maskMode = MaskMode.AoMetallicWith4ColorMask;
                        format.needAlpha = true;
                    }

                    if (FixTexture(metallicMap.textureValue, format))
                        needFix = true;
                    DrawTextureSimpleInfo(metallicMap.textureValue, "Metalic MaskMode: " + maskMode.ToString());

                    MarkProperty("_Metallic");

                    // display metallic for low quality level graphics:
                    if(config.keyword == "_STATIC_OPAQUE_WITH_METALLIC")
                    {
                        var metallic = FindAndMarkProperty("_Metallic", props, false);
                        m_MaterialEditor.ShaderProperty(metallic, "Low quality metallic", indentation);
                    }
                }
            }
            MarkProperty("_Metallic");
            if (!config.hasMetallicMap || showAllProperties)
            {
                var metallic = FindAndMarkProperty("_Metallic", props, false);
                m_MaterialEditor.ShaderProperty(metallic, Styles.metallicMapText, indentation);
            }

            /// Draw Bent normalmap Texture:
            MarkProperty("_BentNormalMap");
            if (config.hasBentNormalMap || showAllProperties)
            {
                var bentNormalMap = FindAndMarkProperty("_BentNormalMap", props, false);
                m_MaterialEditor.TexturePropertySingleLine(Styles.bentNormalMapText, bentNormalMap);
                {
                    NormalMode normalMode = NormalMode.Normal;
                    var format = new RequestedMapFormat();
                    format.allowAniso = mainMode != MainMode.Dynamic;
                    format.sRGB = false;

                    normalMode = NormalMode.BentNormal;
                    hasRoughnessMap = true;
                    format.mipMode = TextureImporterMipFilter.BoxFilter;

                    if (FixTexture(bentNormalMap.textureValue, format))
                        needFix = true;
                    DrawTextureSimpleInfo(bentNormalMap.textureValue, "NormalMode: " + normalMode.ToString());
                }
            }

            MarkProperty("_Thickness");

            MarkProperty("_Transmittance");
            MarkProperty("_Absorption");
            MarkProperty("_Specular");
            if (isMultLayerShader)
            {
                var thickness = FindAndMarkProperty("_Thickness", props, false);

                var transmittance = FindAndMarkProperty("_Transmittance", props, false);
                var absorption = FindAndMarkProperty("_Absorption", props, false);
                var specular = FindAndMarkProperty("_Specular", props, false);

                m_MaterialEditor.ShaderProperty(thickness, Styles.thicknessText, indentation);
                m_MaterialEditor.ShaderProperty(transmittance, Styles.transmittanceText, indentation);
                m_MaterialEditor.ShaderProperty(absorption, Styles.absorptionText, indentation);
                m_MaterialEditor.ShaderProperty(specular, Styles.specularText, indentation);
            }

            MarkProperty("_Glossiness");
            if (!hasRoughnessMap || showAllProperties)
            {
                var smoothness = FindAndMarkProperty("_Glossiness", props);
                m_MaterialEditor.ShaderProperty(smoothness, Styles.smoothnessText, indentation);
            }

            MarkProperty("_HeightMap");
            if (config.hasHeightMap || showAllProperties)
            {
                var heightMap = FindAndMarkProperty("_HeightMap", props, false);
                m_MaterialEditor.TexturePropertySingleLine(Styles.heightMapText, heightMap);
                {
                    var format = new RequestedMapFormat();

                    if (FixTexture(heightMap.textureValue, format))
                        needFix = true;
                    DrawTextureSimpleInfo(heightMap.textureValue, "HeightMap");
                }
            }

            // Emission for GI?
            var emissionMap = FindAndMarkProperty("_EmissionMap", props);
            MarkProperty("_EmissionColor");
            MarkProperty("_EmissionColor_1");
            MarkProperty("_EmissionColor_2");

            MarkProperty("_EmissionMaskColor_1");
            MarkProperty("_EmissionMaskColor_2");
            MarkProperty("_EmissionMaskColor_3");
            MarkProperty("_EmissionMaskColor_4");

            if (config.hasEmission || showAllProperties)
            {
                GUILayout.Label(Styles.emissionTitleText, EditorStyles.boldLabel);
                bool hadEmissionTexture = emissionMap.textureValue != null;

                // Texture and HDR color controls
                var emissionColorForRendering = FindAndMarkProperty("_EmissionColor", props);
                //
                var emissionIntensityForRendering = FindAndMarkProperty("_EmissionIntensity", props, false);

                if (config.hasEmissionMap || showAllProperties)
                {
                    m_MaterialEditor.TexturePropertyWithHDRColor(Styles.emissionText, emissionMap, emissionColorForRendering, m_ColorPickerHDRConfig, false);
                }
                else
                {
                    m_MaterialEditor.TexturePropertyWithHDRColor(Styles.emissionText, emissionMap, emissionColorForRendering, m_ColorPickerHDRConfig, false);
                    emissionMap.textureValue = null;
                }

                //
                if (emissionIntensityForRendering != null) 
                    m_MaterialEditor.ShaderProperty(emissionIntensityForRendering, emissionIntensityForRendering.displayName, indentation);

                // If texture was assigned and color was black set color to white
                float brightness = emissionColorForRendering.colorValue.maxColorComponent;
                if (emissionMap.textureValue != null && !hadEmissionTexture && brightness <= 0f)
                    emissionColorForRendering.colorValue = Color.white;

                // change the GI flag and fix it up with emissive as black if necessary
                m_MaterialEditor.LightmapEmissionFlagsProperty(MaterialEditor.kMiniTextureFieldLabelIndentLevel, true);
                if (config.hasEmissionMap)
                {
                    var format = new RequestedMapFormat();
                    if (FixTexture(emissionMap.textureValue, format))
                        needFix = true;
                    DrawTextureSimpleInfo(emissionMap.textureValue, "Emission");
                }

                if (config.FourChannelEmission)
                {
                    var UseEmissionMask = FindAndMarkProperty("_UseEmissionMask", props, false);
                    float EmissionMaskValue = UseEmissionMask.floatValue;
                    bool useEmMask = EditorGUILayout.Toggle("UseEmissionMask", EmissionMaskValue > 0);
                    UseEmissionMask.floatValue = useEmMask ? 1.0f : 0.0f;
                    //Use the EmissionMap RGBA Channel to Make Emission Mask
                    if (useEmMask == true && UseEmissionMask != null)
                    {
                        var _EmissionMaskColor_1 = FindAndMarkProperty("_EmissionMaskColor_1", props);
                        var _EmissionMaskColor_2 = FindAndMarkProperty("_EmissionMaskColor_2", props);
                        var _EmissionMaskColor_3 = FindAndMarkProperty("_EmissionMaskColor_3", props);
                        var _EmissionMaskColor_4 = FindAndMarkProperty("_EmissionMaskColor_4", props);

                        m_MaterialEditor.ColorProperty(_EmissionMaskColor_1, "EmissionMask Color 1");
                        m_MaterialEditor.ColorProperty(_EmissionMaskColor_2, "EmissionMask Color 2");
                        m_MaterialEditor.ColorProperty(_EmissionMaskColor_3, "EmissionMask Color 3");
                        m_MaterialEditor.ColorProperty(_EmissionMaskColor_4, "EmissionMask Color 4");

                        material.EnableKeyword("_USEEMISSIONMASK"); material.SetFloat("_USEEMISSIONMASK", 1);
                    }
                    else
                    {
                        material.DisableKeyword("_USEEMISSIONMASK"); material.SetFloat("_USEEMISSIONMASK", 0);
                    }
                }

                if (config.threeChannelEmission)
                {
                    var _EmissionColor_1 = FindAndMarkProperty("_EmissionColor_1", props);
                    var _EmissionColor_2 = FindAndMarkProperty("_EmissionColor_2", props);

                    m_MaterialEditor.ColorProperty(_EmissionColor_1, "Emission Color 1");
                    m_MaterialEditor.ColorProperty(_EmissionColor_2, "Emission Color 2");
                }
            }

            EditorGUI.BeginChangeCheck();
            m_MaterialEditor.TextureScaleOffsetProperty(albedoMap);
            if (EditorGUI.EndChangeCheck())
                emissionMap.textureScaleAndOffset = albedoMap.textureScaleAndOffset; // Apply the main texture scale and offset to the emission texture as well, for Enlighten's sake



            bool shouldShowDetailGUI = false;
            var detailMode = FindAndMarkProperty("_DetailMode", props, false);
            if (config.hasDetail)   // detail is mandatory
            {
                shouldShowDetailGUI = true;
            }
            else if (config.allowDetail && detailMode != null) // detail is an optional choice for this material.
            {
                float detail = detailMode.floatValue;
                bool needDetail = EditorGUILayout.Toggle("Enable Details", detail > 0);
                detailMode.floatValue = needDetail ? 1.0f : 0.0f;
                SetKeyword(material, Enum.GetName(typeof(KeywordSet), KeywordSet._DETAIL_LERP), needDetail);
                shouldShowDetailGUI = needDetail;
            }

            //Check whether open the detail category
            MarkProperty("_DetailAlbedoMap");
            MarkProperty("_BumpMapScale");
            MarkProperty("_DetailNormalMap");
            MarkProperty("_DetailNormalPower");

            MarkProperty("_CamoufalgeColCoef0");
            MarkProperty("_CamoufalgeColCoef1");
            MarkProperty("_CamoufalgeColCoef2");

            MarkProperty("_4ColColorSwitch");
            MarkProperty("_4ColDetail0");
            MarkProperty("_4ColDetail1");

            MarkProperty("_4ColCoef0");
            MarkProperty("_4ColCoef1");
            MarkProperty("_4ColCoef2");
            MarkProperty("_4ColCoef3");

            if (config.hasNormalMapScale || showAllProperties)
            {
                var bumpScale = FindAndMarkProperty("_BumpMapScale", props, false);
                m_MaterialEditor.ShaderProperty(bumpScale, Styles.normalMapScale);
            }
            if (shouldShowDetailGUI || (showAllProperties))
            {
                var detailAlbedoMap = FindAndMarkProperty("_DetailAlbedoMap", props, false);
                if (config.hasDetailAlbedo || showAllProperties)
                {
                    //Draw detail albedo texture GUI
                    m_MaterialEditor.TexturePropertySingleLine(Styles.detailAlbedoText, detailAlbedoMap);
                    {
                        var format = new RequestedMapFormat();

                        if (config.hasAdvanceDetail)
                            format.needAlpha = true;

                        if (FixTexture(detailAlbedoMap.textureValue, format))
                            needFix = true;
                        DrawTextureSimpleInfo(detailAlbedoMap.textureValue, "detailAlbedoMap");
                    }
                }

                if (config.hasDetailNormal || showAllProperties)
                {
                    //draw the detail normal map GUI
                    var detailNormalMap = FindAndMarkProperty("_DetailNormalMap", props, false);
                    m_MaterialEditor.TexturePropertySingleLine(Styles.detailNormalMapText, detailNormalMap);
                    //m_MaterialEditor.ShaderProperty(detailNormalMapScale, Styles.detailNormalMapScaleText);
                    {
                        var format = new RequestedMapFormat();
                        format.sRGB = false;
                        format.mipMode = TextureImporterMipFilter.KaiserFilter;
                        if (FixTexture(detailNormalMap.textureValue, format))
                            needFix = true;
                        DrawTextureSimpleInfo(detailNormalMap.textureValue, "detailNormalMap");
                    }
                    var detailNormalPower = FindAndMarkProperty("_DetailNormalPower", props, false);
                    m_MaterialEditor.ShaderProperty(detailNormalPower, Styles.detailNormalPowerText);
                }

                if (config.hasAdvanceDetail || showAllProperties)
                {
                    /////UV Rotation
                    GUILayout.Label(Styles.UVRotation, EditorStyles.boldLabel);
                    var CamouflageUVRotation = FindAndMarkProperty("_CamouflageUVSinCos", props);
                    var CamouflageRotation = FindAndMarkProperty("_CamouflageRotation", props);

                    string uvRot = "UV Rotation";
                    CFEffectShaderGUI.SetTextureRotation(CamouflageRotation, CamouflageUVRotation, true, uvRot);

                    ///////Emission from NormalMap-A Channel
                    GUILayout.Label(Styles.EmissionChannel, EditorStyles.boldLabel);
                    var _BumpMapHasAlpha = FindAndMarkProperty("_BumpMapHasAlpha", props);
                    bool BumpMapHasAlpha = _BumpMapHasAlpha.floatValue == 1.0f;
                    bool useBumpAlpha = EditorGUILayout.Toggle("NormalMapHasAlpha", BumpMapHasAlpha);

                    if (useBumpAlpha != BumpMapHasAlpha)
                    {
                        _BumpMapHasAlpha.floatValue = useBumpAlpha ? 1.0f : 0.0f;
                    }
                    if (BumpMapHasAlpha == true)
                    {
                        var _NormalMapAlphaEmission_1 = FindAndMarkProperty("_NormalMapAlphaEmission_1", props);
                        var _NormalMapAlphaEmission_2 = FindAndMarkProperty("_NormalMapAlphaEmission_2", props);
                        m_MaterialEditor.ColorProperty(_NormalMapAlphaEmission_1, "NormalMapAlphaEmissionColor 1");
                        m_MaterialEditor.ColorProperty(_NormalMapAlphaEmission_2, "NormalMapAlphaEmissionColor 2");

                    }

                    var _camoufalgeColCoef0 = FindAndMarkProperty("_CamoufalgeColCoef0", props, false);
                    var _camoufalgeColCoef1 = FindAndMarkProperty("_CamoufalgeColCoef1", props, false);
                    var _camoufalgeColCoef2 = FindAndMarkProperty("_CamoufalgeColCoef2", props, false);



                    if (_camoufalgeColCoef0 != null && _camoufalgeColCoef1 != null && _camoufalgeColCoef2 != null)
                    {
                        EditorGUILayout.BeginVertical("box");
                        // Create a camouflage pattern using detail map alpha channel (as mask) and four colors:

                        Color col0 = Color.black;
                        Color col1 = Color.black;
                        Color col2 = Color.black;
                        Color col3 = Color.black;

                        ShaderUniformToCamouflageColor(_camoufalgeColCoef0.vectorValue, _camoufalgeColCoef1.vectorValue, _camoufalgeColCoef2.vectorValue,
                                                        ref col0, ref col1, ref col2, ref col3);

                        EditorGUILayout.LabelField("4-Color Camouflage:", EditorStyles.boldLabel);

                        EditorGUI.BeginChangeCheck();
                        EditorGUILayout.HelpBox("4-Color Camouflage is controlled by alpha channel of DetailAlbedo map.", MessageType.None);

                        EditorGUILayout.Space();

                        col0 = EditorGUILayout.ColorField(" Mask [0] (rgb : 2  )", col0);
                        col1 = EditorGUILayout.ColorField(" Mask [1] (rgb : 98 )", col1);
                        col2 = EditorGUILayout.ColorField(" Mask [2] (rgb : 210)", col2);
                        col3 = EditorGUILayout.ColorField(" Mask [3] (rgb : 255)", col3);

                        if (EditorGUI.EndChangeCheck())
                        {
                            Vector4 _uf0 = Vector4.zero;
                            Vector4 _uf1 = Vector4.zero;
                            Vector4 _uf2 = Vector4.zero;

                            CreateCamouflageColorCombinationShaderUniform(col0, col1, col2, col3, ref _uf0, ref _uf1, ref _uf2);

                            _camoufalgeColCoef0.vectorValue = _uf0;
                            _camoufalgeColCoef1.vectorValue = _uf1;
                            _camoufalgeColCoef2.vectorValue = _uf2;
                        }

                        EditorGUILayout.EndVertical();
                        EditorGUILayout.Space();

                    }
                }

                m_MaterialEditor.TextureScaleOffsetProperty(detailAlbedoMap);

                if (config.hasAdvanceDetail || showAllProperties)
                {
                    EditorGUILayout.Space();
                    EditorGUILayout.LabelField("4 Color Blending:", EditorStyles.boldLabel);

                    EditorGUILayout.Space();

                    var _colSwitch = FindAndMarkProperty("_4ColColorSwitch", props, false);
                    var _4ColColor0 = FindAndMarkProperty("_4ColDetail0", props, false);
                    var _4ColColor1 = FindAndMarkProperty("_4ColDetail1", props, false);

                    var _4ColPbrCoef0 = FindAndMarkProperty("_4ColCoef0", props, false);
                    var _4ColPbrCoef1 = FindAndMarkProperty("_4ColCoef1", props, false);
                    var _4ColPbrCoef2 = FindAndMarkProperty("_4ColCoef2", props, false);
                    var _4ColPbrCoef3 = FindAndMarkProperty("_4ColCoef3", props, false);

                    if (_colSwitch != null && _4ColColor0 != null && _4ColColor1 != null)
                    {
                        // 4-color Pbr Coef includes:
                        // Albedo blend / roughness / roughness blend /  metallic 

                        // albedo blending are stored in other coefs for binding performance:
                        // Color[1] and Color[3] (pure color) albedo blend are stored in their alpha channel of the color value:
                        // Color[2] and Color[4] (texture color) albedo blend are stored in _colSwitch.zw;

                        float col0Blend = _4ColColor0.colorValue.a;
                        float col1Blend = _colSwitch.vectorValue.z;
                        float col2Blend = _4ColColor1.colorValue.a;
                        float col3Blend = _colSwitch.vectorValue.w;

                        Vector4 col0PbrCoef = Vector4.zero;    
                        Vector4 col1PbrCoef = Vector4.zero;
                        Vector4 col2PbrCoef = Vector4.zero;
                        Vector4 col3PbrCoef = Vector4.zero;

                        // other pbr coefs ( roughness /  roughness blend / metallic / [reserved] )are stored in colPbrCoef with a packed style to save GPU ALUs:
                        // color[1] is from _4ColCoef0;
                        // color[2] is from _4ColCoef0 + _4ColCoef1. where _4ColCoef1 = color[2] - color[1]
                        // color[3] is from _4ColCoef2;
                        // color[4] is from _4ColCoef2 + _4ColCoef3. where _4ColCoef3 = color[4] - color[3]

                        // _4ColCoef.w are reserved for future coef lerp.
                        col0PbrCoef = _4ColPbrCoef0.vectorValue;
                        col1PbrCoef = _4ColPbrCoef0.vectorValue + _4ColPbrCoef1.vectorValue;
                        col2PbrCoef = _4ColPbrCoef2.vectorValue;
                        col3PbrCoef = _4ColPbrCoef2.vectorValue + _4ColPbrCoef3.vectorValue;

                        // Group 1:
                        EditorGUILayout.BeginVertical("box");
                        {
                            EditorGUILayout.LabelField("Color Group [1]", EditorStyles.boldLabel);
                            EditorGUILayout.HelpBox("Mask rgb : 4", MessageType.None);

                            EditorGUILayout.Space();

                            EditorGUILayout.BeginVertical("box");
                            {
                                EditorGUILayout.LabelField("Color [1]", EditorStyles.boldLabel);
                                EditorGUILayout.HelpBox("Group Mask rgb : 0", MessageType.None);

                                _4ColColor0.colorValue = EditorGUILayout.ColorField("Albedo:", _4ColColor0.colorValue);
                                col0Blend = EditorGUILayout.Slider("Albedo Blend:", col0Blend, 0.0f, 1.0f);
                                col0PbrCoef.x = EditorGUILayout.Slider("Roughness:", col0PbrCoef.x, 0.0f, 1.0f);
                                col0PbrCoef.y = EditorGUILayout.Slider("Roughness Blend:", col0PbrCoef.y, 0.0f, 1.0f);
                                col0PbrCoef.z = EditorGUILayout.Slider("Metallic:", col0PbrCoef.z, 0.0f, 1.0f);
                            }
                            EditorGUILayout.EndVertical();

                            EditorGUILayout.BeginVertical("box");
                            {
                                EditorGUILayout.LabelField("Color [2]", EditorStyles.boldLabel);
                                EditorGUILayout.HelpBox("Group Mask rgb : 255", MessageType.None);
                                EditorGUILayout.LabelField("Albedo:     [From Detail Albedo Map rgb channel]", EditorStyles.boldLabel);
                                col1Blend = EditorGUILayout.Slider("Albedo Blend:", col1Blend, 0.0f, 1.0f);
                                col1PbrCoef.x = EditorGUILayout.Slider("Roughness:", col1PbrCoef.x, 0.0f, 1.0f);
                                col1PbrCoef.y = EditorGUILayout.Slider("Roughness Blend:", col1PbrCoef.y, 0.0f, 1.0f);
                                col1PbrCoef.z = EditorGUILayout.Slider("Metallic:", col1PbrCoef.z, 0.0f, 1.0f);
                            }
                            EditorGUILayout.EndVertical();
                        }
                        EditorGUILayout.EndVertical();

                        EditorGUILayout.Space();

                        // Group 2:
                        EditorGUILayout.BeginVertical("box");
                        {
                            EditorGUILayout.LabelField("Color Group [2]", EditorStyles.boldLabel);
                            EditorGUILayout.HelpBox("Mask rgb : 255", MessageType.None);

                            EditorGUILayout.Space();

                            EditorGUILayout.BeginVertical("box");
                            {
                                EditorGUILayout.LabelField("Color [3]", EditorStyles.boldLabel);
                                EditorGUILayout.HelpBox("Group Mask rgb : 0", MessageType.None);

                                _4ColColor1.colorValue = EditorGUILayout.ColorField("Albedo:", _4ColColor1.colorValue);
                                col2Blend = EditorGUILayout.Slider("Albedo Blend:", col2Blend, 0.0f, 1.0f);
                                col2PbrCoef.x = EditorGUILayout.Slider("Roughness:", col2PbrCoef.x, 0.0f, 1.0f);
                                col2PbrCoef.y = EditorGUILayout.Slider("Roughness Blend:", col2PbrCoef.y, 0.0f, 1.0f);
                                col2PbrCoef.z = EditorGUILayout.Slider("Metallic:", col2PbrCoef.z, 0.0f, 1.0f);
                            }
                            EditorGUILayout.EndVertical();

                            EditorGUILayout.BeginVertical("box");
                            {
                                EditorGUILayout.LabelField("Color [4]", EditorStyles.boldLabel);
                                EditorGUILayout.HelpBox("Group Mask rgb : 255", MessageType.None);

                                EditorGUILayout.LabelField("Albedo:     [From 4-Color Camouflage]", EditorStyles.boldLabel);
                                col3Blend = EditorGUILayout.Slider("Albedo Blend:", col3Blend, 0.0f, 1.0f);
                                col3PbrCoef.x = EditorGUILayout.Slider("Roughness:", col3PbrCoef.x, 0.0f, 1.0f);
                                col3PbrCoef.y = EditorGUILayout.Slider("Roughness Blend:", col3PbrCoef.y, 0.0f, 1.0f);
                                col3PbrCoef.z = EditorGUILayout.Slider("Metallic:", col3PbrCoef.z, 0.0f, 1.0f);
                            }
                            EditorGUILayout.EndVertical();
                        }
                        EditorGUILayout.EndVertical();

                        // asign pbr properties
                        _4ColPbrCoef0.vectorValue = col0PbrCoef;
                        _4ColPbrCoef1.vectorValue = col1PbrCoef - col0PbrCoef;
                        _4ColPbrCoef2.vectorValue = col2PbrCoef;
                        _4ColPbrCoef3.vectorValue = col3PbrCoef - col2PbrCoef;

                        Color col0 = _4ColColor0.colorValue;
                        col0.a = col0Blend;  // store albedo blend in color.a
                        _4ColColor0.colorValue = col0;

                        Color col1 = _4ColColor1.colorValue;
                        col1.a = col2Blend;  // store albedo blend in color.a
                        _4ColColor1.colorValue = col1;

                        EditorGUILayout.Space();

                        EditorGUILayout.LabelField("Color Mask Swap:", EditorStyles.boldLabel);

                        bool shouldSwitchColor01 = _colSwitch.vectorValue.x == 1.0f;
                        bool shouldSwitchColor34 = _colSwitch.vectorValue.y == 1.0f;

                        shouldSwitchColor01 = EditorGUILayout.ToggleLeft("Swap Color [1] and [2]", shouldSwitchColor01);
                        shouldSwitchColor34 = EditorGUILayout.ToggleLeft("Swap Color [3] and [4]", shouldSwitchColor34);

                        Vector4 colorSwitchVal = Vector4.zero;

                        colorSwitchVal.x = shouldSwitchColor01 ? 1.0f : 0.0f;
                        colorSwitchVal.y = shouldSwitchColor34 ? 1.0f : 0.0f;
                        colorSwitchVal.z = col1Blend;   // color[2] rgb texture albedo blend
                        colorSwitchVal.w = col3Blend;   // color[4] camouflage texture albedo blend

                        _colSwitch.vectorValue = colorSwitchVal;
                    }
                }

            }
            var overBaseColor = FindAndMarkProperty("_OverBaseColor", props, false);
            MarkProperty("_OverColor");
            MarkProperty("_OverNormalMap");
            MarkProperty("_OverMetallic");
            MarkProperty("_OverGlossiness");
            MarkProperty("_Thickness");
            MarkProperty("_SlopeThreshold");
            MarkProperty("_Damp");
            MarkProperty("_NormalDamp");
            MarkProperty("_Hardness");
            MarkProperty("_LowOverThreshold");
            if (config.hasTopLayer || (showAllProperties && overBaseColor != null))
            {
                GUILayout.Label(Styles.topMapsText, EditorStyles.boldLabel);

                if (config.tintOverrideAlbedoTexture)
                {
                    var lowTierOverrideColor = FindAndMarkProperty("_LowTierOverlayColor", props);
                    if (lowTierOverrideColor != null)
                    {
                        m_MaterialEditor.ShaderProperty(lowTierOverrideColor, Styles.lowTierOverlayColorText);
                        var aoOn = FindAndMarkProperty("_LowTierOverlayColor", props);

                        
                    }
                }

                var overColor = FindAndMarkProperty("_OverColor", props, false);
                if (config.hasTopLayerAlbedoMap || showAllProperties)
                {
                    m_MaterialEditor.TexturePropertySingleLine(Styles.topAlbedoText, overBaseColor, overColor);
                    {
                        var format = new RequestedMapFormat();
                        format.allowAniso = mainMode != MainMode.Dynamic;
                        if (FixTexture(overBaseColor.textureValue, format))
                            needFix = true;
                        DrawTextureSimpleInfo(overBaseColor.textureValue, "OverBase Albedo");
                    }
                }
                else
                {
                    m_MaterialEditor.ShaderProperty(overColor, Styles.topAlbedoText, indentation);
                }
                bool hasOverRoughnessMap = false;

                if (config.hasTopLayerNormalMap || showAllProperties)
                {
                    var overNormalMap = FindAndMarkProperty("_OverNormalMap", props, false);
                    GUIContent title = config.isTopLayerNormalAlbedo ? Styles.topNormalMapWithAlbedoText : Styles.topNormalMapText;
                    m_MaterialEditor.TexturePropertySingleLine(title, overNormalMap);
                    {
                        var format = new RequestedMapFormat();
                        format.allowAniso = mainMode != MainMode.Dynamic;
                        format.sRGB = false;
                        NormalMode overNormalMode = NormalMode.Normal;
                        if (config.isTopLayerNormalAlbedo)
                        {
                            overNormalMode = NormalMode.PackAlbedo;
                            format.mipMode = TextureImporterMipFilter.NormalX;
                        }
                        else
                        {
                            overNormalMode = NormalMode.PackRoughness;
                            format.mipMode = TextureImporterMipFilter.NormalGlossiness;
                            hasOverRoughnessMap = true;
                        }
                        if (FixTexture(overNormalMap.textureValue, format))
                            needFix = true;
                        DrawTextureSimpleInfo(overNormalMap.textureValue, overNormalMode.ToString());
                    }
                }
                var overMetallic = FindAndMarkProperty("_OverMetallic", props, false);
                m_MaterialEditor.ShaderProperty(overMetallic, Styles.metallicMapText, indentation);
                if (!hasOverRoughnessMap || showAllProperties)
                {
                    var overSmoothness = FindAndMarkProperty("_OverGlossiness", props, false);
                    m_MaterialEditor.ShaderProperty(overSmoothness, Styles.smoothnessText, indentation);
                }
                EditorGUILayout.Space();
                bool useHeightMap = config.hasHeightMap || config.isAlphaHeightMap;
                if (useHeightMap || showAllProperties)
                {
                    var thickness = FindAndMarkProperty("_Thickness", props, false);
                    m_MaterialEditor.ShaderProperty(thickness, Styles.thicknessText, indentation);
                }
                if (!useHeightMap || showAllProperties)
                {
                    var slopeThreshold = FindAndMarkProperty("_SlopeThreshold", props, false);
                    m_MaterialEditor.ShaderProperty(slopeThreshold, Styles.slopeThresholdText, indentation);
                    var damp = FindAndMarkProperty("_Damp", props, false);
                    m_MaterialEditor.ShaderProperty(damp, Styles.dampText, indentation);
                }
                var normalDamp = FindAndMarkProperty("_NormalDamp", props, false);
                m_MaterialEditor.ShaderProperty(normalDamp, Styles.normalDampText, indentation);
                var hardness = FindAndMarkProperty("_Hardness", props, false);
                m_MaterialEditor.ShaderProperty(hardness, Styles.hardnessText, indentation);
                var lowOverThreshold = FindAndMarkProperty("_LowOverThreshold", props, false);
                m_MaterialEditor.ShaderProperty(lowOverThreshold, Styles.lowOverThresholdText, indentation);

                if (config.hasTopLayerAlbedoMap || config.hasTopLayerNormalMap || showAllProperties)
                {
                    m_MaterialEditor.TextureScaleOffsetProperty(overBaseColor);
                }
            }


            MarkProperty("_Specular2");
            MarkProperty("_Color2");
            MarkProperty("_MainTex2");
            MarkProperty("_Metallic2");
            MarkProperty("_Roughness2");
            MarkProperty("_BumpMapPakced2");
            MarkProperty("_SimpleBlendingScale");
            MarkProperty("_SimpleBlendingRoughnessScale");
            if (isMultLayerShader)
            {
                var specular2 = FindAndMarkProperty("_Specular2", props, false);
                var albedoColor2 = FindAndMarkProperty("_Color2", props, false);
                var albedoMap2 = FindAndMarkProperty("_MainTex2", props, false);
                var metallic2 = FindAndMarkProperty("_Metallic2", props, false);
                var roughness2 = FindAndMarkProperty("_Roughness2", props, false);
                var bumpMap2 = FindAndMarkProperty("_BumpMapPakced2", props, false);
                var _SimpleBlendingScale = FindAndMarkProperty("_SimpleBlendingScale", props, false);
                var _SimpleBlendingRoughnessScale = FindAndMarkProperty("_SimpleBlendingRoughnessScale", props, false);

                GUILayout.Label(Styles.layer2TitleText, EditorStyles.boldLabel);

                m_MaterialEditor.TexturePropertySingleLine(Styles.topAlbedoText, albedoMap2, albedoColor2);

                if (!config.noAlbedoMap2)
                {
                    var format = new RequestedMapFormat();
                    format.allowAniso = mainMode != MainMode.Dynamic;
                    if (FixTexture(albedoMap2.textureValue, format))
                        needFix = true;
                    DrawTextureSimpleInfo(albedoMap2.textureValue, "OverBase Albedo");
                }

                bool hasOverRoughnessMap = false;
                if (config.hasNormalMap2)
                {
                    m_MaterialEditor.TexturePropertySingleLine(Styles.topNormalMapText, bumpMap2);
                    {
                        var format = new RequestedMapFormat();
                        format.allowAniso = mainMode != MainMode.Dynamic;
                        format.sRGB = false;
                        NormalMode normalMode2 = NormalMode.Normal;
                        if (config.isClassicTexture)
                        {
                            normalMode2 = NormalMode.Normal;
                        }
                        else
                        {
                            normalMode2 = NormalMode.PackRoughness;
                            hasRoughnessMap = true;
                            format.mipMode = TextureImporterMipFilter.NormalGlossiness;
                        }

                        if (FixTexture(bumpMap2.textureValue, format))
                            needFix = true;
                        DrawTextureSimpleInfo(bumpMap2.textureValue, normalMode2.ToString());
                    }
                }

                m_MaterialEditor.ShaderProperty(metallic2, Styles.metallicMapText, indentation);
                m_MaterialEditor.ShaderProperty(specular2, Styles.specularText, indentation);
                if (!hasOverRoughnessMap)
                    m_MaterialEditor.ShaderProperty(roughness2, Styles.smoothnessText, indentation);
                EditorGUILayout.Space();
                bool useHeightMap = config.hasHeightMap || config.isAlphaHeightMap;
                if (useHeightMap)
                {
                    var thickness = FindAndMarkProperty("_Thickness", props, false);
                    m_MaterialEditor.ShaderProperty(thickness, Styles.thicknessText, indentation);
                }
                //                     if (!useHeightMap)
                //                     {
                //                         m_MaterialEditor.ShaderProperty(slopeThreshold, Styles.slopeThresholdText, indentation);
                //                         m_MaterialEditor.ShaderProperty(damp, Styles.dampText, indentation);
                //                     }
                //                     m_MaterialEditor.ShaderProperty(normalDamp, Styles.normalDampText, indentation);
                //                     m_MaterialEditor.ShaderProperty(hardness, Styles.hardnessText, indentation);

                if (!config.noAlbedoMap2 || config.hasNormalMap2)
                {
                    m_MaterialEditor.TextureScaleOffsetProperty(albedoColor2);
                }


                EditorGUILayout.Space();
                GUILayout.Label(Styles.multLayerFallbackSectionTitleText, EditorStyles.boldLabel);
                m_MaterialEditor.ShaderProperty(_SimpleBlendingScale, Styles.simpleBlendingScaleText, indentation);
                m_MaterialEditor.ShaderProperty(_SimpleBlendingRoughnessScale, Styles.simpleBlendingScaleText, indentation);
            }

            MarkProperty("_LegacyFixEyeVec");
            MarkProperty("custom_IBLCubemap");
            if (custom_IBLCubemap != null && Shader.IsKeywordEnabled("_USE_CUSTOM_IBL"))
            {
                if (config.isLegacySubMode)
                {
                    custom_IBLCubemap.textureValue = null;
                }
                else
                {
                    GUILayout.Label(Styles.legacyText, EditorStyles.boldLabel);
                    bool changed = false;
                    if (custom_IBLCubemap.textureValue == null && EditorUtility.IsPersistent(material))
                    {
                        var basePath = "Assets/Shaders/CODM/Standard/Res/";
                        var path = AssetDatabase.GetAssetPath(material);
                        if (path.Contains("/Avatar"))
                        {
                            if (path.Contains("_1P"))
                            {
                                custom_IBLCubemap.textureValue = AssetDatabase.LoadMainAssetAtPath(basePath + "DefaultCharacter1P.exr") as Texture;
                            }
                            else
                            {
                                custom_IBLCubemap.textureValue = AssetDatabase.LoadMainAssetAtPath(basePath + "DefaultCharacter.exr") as Texture;
                            }
                        }
                        else
                        {
                            custom_IBLCubemap.textureValue = AssetDatabase.LoadMainAssetAtPath(basePath + "DefaultWeapon.exr") as Texture;
                        }
                        changed = true;
                    }
                    EditorGUI.BeginChangeCheck();
                    m_MaterialEditor.ShaderProperty(custom_IBLCubemap, Styles.customIBLMapText);

                    if (EditorGUI.EndChangeCheck())
                    {
                        changed = true;
                    }
                    if (changed && custom_IBLCubemap.textureValue != null && custom_IBLCubemap.textureValue is Cubemap)
                    {
                        if ((custom_IBLCubemap.textureValue as Cubemap).mipmapCount <= 1)
                            custom_IBLCubemap.textureValue = null;
                        else
                            UpdateCustomSH(material);
                    }
                    var _LegacyFixEyeVec = FindAndMarkProperty("_LegacyFixEyeVec", props, false);
                    bool oldFixEyeVec = _LegacyFixEyeVec.floatValue == 1;
                    bool fixEyeVec = EditorGUILayout.Toggle("Enable Fix Eye Direction", oldFixEyeVec);
                    if (fixEyeVec != oldFixEyeVec)
                    {
                        _LegacyFixEyeVec.floatValue = fixEyeVec ? 1.0f : 0.0f;
                    }
                }
            }

            EditorGUILayout.Space();

            MarkProperty("_ColorBoostInLegacy");
            if (config.isLegacySubMode)
            {
                var _ColorBoostInLegacy = FindAndMarkProperty("_ColorBoostInLegacy", props, false);
                m_MaterialEditor.ShaderProperty(_ColorBoostInLegacy, Styles.colorBoostLegacyText);
            }

            EditorGUILayout.Space();

            if (isMultLayerShader)
            {
                m_DebugShowDirectLighting1 = EditorGUILayout.Toggle("Outer layer direct light", m_DebugShowDirectLighting1);
                m_DebugShowDirectLighting2 = EditorGUILayout.Toggle("Inner layer direct light", m_DebugShowDirectLighting2);
                m_DebugEnableEvnLighting1 = EditorGUILayout.Toggle("Outer Env light", m_DebugEnableEvnLighting1);
                m_DebugEnableEvnLighting2 = EditorGUILayout.Toggle("Inner Env light", m_DebugEnableEvnLighting2);
                SetKeyword(material, "ENABLE_DIRECT_LAYER1", m_DebugShowDirectLighting1);
                SetKeyword(material, "ENABLE_DIRECT_LAYER2", m_DebugShowDirectLighting2);
                SetKeyword(material, "ENABLE_ENV_LIGHT1", m_DebugEnableEvnLighting1);
                SetKeyword(material, "ENABLE_ENV_LIGHT2", m_DebugEnableEvnLighting2);
            }

            return needFix;
        }



        static ShaderConfig GetSubModeConfig(MainMode mainModeEnum, int mode)
        {
            switch (mainModeEnum)
            {
                case MainMode.Dynamic:
                    if (!DynamicConfig.ContainsKey((DynamicMode)mode))
                        break;
                    return DynamicConfig[(DynamicMode)mode];
                case MainMode.StaticSingle:
                    if (!StaticSingleConfig.ContainsKey((StaticSingleMode)mode))
                        break;
                    return StaticSingleConfig[(StaticSingleMode)mode];
                case MainMode.StaticDouble:
                    if (!StaticDoubleConfig.ContainsKey((StaticDoubleMode)mode))
                        break;
                    return StaticDoubleConfig[(StaticDoubleMode)mode];
                case MainMode.StaticMultLayer:
                    if (!StaticMultLayerConfig.ContainsKey((StaticMultLayerMode)mode))
                        break;
                    return StaticMultLayerConfig[(StaticMultLayerMode)mode];
                case MainMode.Foliage:
                    if (!FoliageConfig.ContainsKey((FoliageMode)mode))
                        break;
                    return FoliageConfig[(FoliageMode)mode];
            }
            return new ShaderConfig();
        }
        ShaderConfig SubModePopup(MainMode mainModeEnum)
        {
            EditorGUI.showMixedValue = subMode.hasMixedValue;

            EditorGUI.BeginChangeCheck();
            int mode = (int)subMode.floatValue;
            var config = GetSubModeConfig(mainModeEnum, mode);
            if (config.debugOnly)
            {
                GUI.color = Color.red;
            }
            switch (mainModeEnum)
            {
                case MainMode.Dynamic:
                    mode = Array.IndexOf(dynamicModeNames, ((DynamicMode)mode).ToString());
                    //Debug.Log("11111111" + mode.ToString());
                    mode = EditorGUILayout.Popup(Styles.subMode, mode, dynamicModeNames);
                    //Debug.Log("2222222" + mode.ToString());
                    mode = (int)Enum.Parse(typeof(DynamicMode), dynamicModeNames[mode]);
                    //Debug.Log("3333333" + mode.ToString());
                    break;
                case MainMode.StaticSingle:
                    mode = Array.IndexOf(staticSingleModeNames, ((StaticSingleMode)mode).ToString());
                    mode = EditorGUILayout.Popup(Styles.subMode, mode, staticSingleModeNames);
                    mode = (int)Enum.Parse(typeof(StaticSingleMode), staticSingleModeNames[mode]);
                    break;
                case MainMode.StaticDouble:
                    mode = Array.IndexOf(staticDoubleModeNames, ((StaticDoubleMode)mode).ToString());
                    mode = EditorGUILayout.Popup(Styles.subMode, mode, staticDoubleModeNames);
                    mode = (int)Enum.Parse(typeof(StaticDoubleMode), staticDoubleModeNames[mode]);
                    break;
                case MainMode.StaticMultLayer:
                    mode = Array.IndexOf(staticMultLayerModeNames, ((StaticMultLayerMode)mode).ToString());
                    mode = EditorGUILayout.Popup(Styles.subMode, mode, staticMultLayerModeNames);
                    mode = (int)Enum.Parse(typeof(StaticMultLayerMode), staticMultLayerModeNames[mode]);
                    break;
                case MainMode.Foliage:
                    mode = Array.IndexOf(foliageModeNames, ((FoliageMode)mode).ToString());
                    mode = EditorGUILayout.Popup(Styles.subMode, mode, foliageModeNames);
                    mode = (int)Enum.Parse(typeof(FoliageMode), foliageModeNames[mode]);
                    break;
            }
            if (config.debugOnly)
            {
                GUILayout.Label(Styles.debugOnlyText, EditorStyles.boldLabel);
                GUI.color = Color.white;
            }

            if (EditorGUI.EndChangeCheck())
            {
                m_MaterialEditor.RegisterPropertyChangeUndo("Sub Mode");
                subMode.floatValue = (float)mode;
            }

            EditorGUI.showMixedValue = false;
            return GetSubModeConfig(mainModeEnum, mode);
        }

        
        public override void AssignNewShaderToMaterial(Material material, Shader oldShader, Shader newShader)
        {
            InitConfig();

            // _Emission property is lost after assigning Standard shader to the material
            // thus transfer it before assigning the new shader
            if (material.HasProperty("_Emission"))
            {
                material.SetColor("_EmissionColor", material.GetColor("_Emission"));
            }

            Texture metallicMap = null;
            //if (material.HasProperty("_ParamMap"))
            //{
            //    metallicMap = material.GetTexture("_ParamMap");
            //    material.SetFloat("_Mode", (int)DynamicMode.Classic);
            //}

            bool forceAlphaTest = false;
            if (material.HasProperty("_ALPHATEST"))
            {
                if (material.GetFloat("_ALPHATEST") > 0)
                {
                    forceAlphaTest = true;
                }
            }

            bool forceAlphaBlend = false;
            if (material.HasProperty("_ALPHABLEND"))
            {
                if (material.GetFloat("_ALPHABLEND") > 0)
                {
                    forceAlphaBlend = true;
                }
            }

            base.AssignNewShaderToMaterial(material, oldShader, newShader);

            if (material.GetTexture("_BumpMap") != null)
            {
                material.SetTexture("_BumpMapPakced", material.GetTexture("_BumpMap"));
                material.SetTexture("_BumpMap", null);
            }

            // if (metallicMap != null)
            // {
            //     material.SetTexture("_MetallicRoughnessMap", metallicMap);
            // }

            if (oldShader == null || !oldShader.name.Contains("Legacy Shaders/"))
            {
                if (material.GetFloat("_Mode") >= 0)
                {
                    material.SetFloat("_SubMode", material.GetFloat("_Mode"));
                    material.SetFloat("_Mode", -1);
                }
                if (forceAlphaTest)
                {
                    material.SetFloat("_SubMode", (float)BlendMode.Cutout);
                }
                if (forceAlphaBlend)
                {
                    material.SetFloat("_SubMode", (float)BlendMode.AlphaBlend);
                }
            }
            else
            {
                BlendMode blendMode = BlendMode.Opaque;
                if (oldShader.name.Contains("/Transparent/Cutout/"))
                {
                    blendMode = BlendMode.Cutout;
                }
                else if (oldShader.name.Contains("/Transparent/"))
                {
                    // NOTE: legacy shaders did not provide physically based transparency
                    // therefore Fade mode
                    blendMode = BlendMode.AlphaBlend;
                }
                material.SetFloat("_SubMode", (float)blendMode);
            }

            OnMaterialChanged(material);
        }

        public static void SetupMaterialWithBlendMode(Material material, BlendMode blendMode, bool isPreZ)
        {
            var defaultRenderQueue = -1;
            switch (blendMode)
            {
                case BlendMode.Opaque:
                    material.SetOverrideTag("RenderType", "");
                    material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                    material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.Zero);
                    material.SetInt("_ZWrite", 1);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                    defaultRenderQueue = -1;
                    break;
                case BlendMode.Cutout:
                    material.SetOverrideTag("RenderType", "TransparentCutout");
                    material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                    material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.Zero);
                    //material.SetInt("_ZWrite", 1);
                    if (!isPreZ)
                    {
                        material.EnableKeyword("_ALPHATEST_ON");
                    }
                    else
                    {
                        material.DisableKeyword("_ALPHATEST_ON");
                    }
                    material.SetInt("_ZTest", isPreZ ? (int)UnityEngine.Rendering.CompareFunction.Equal : (int)UnityEngine.Rendering.CompareFunction.LessEqual);
                    material.SetInt("_ZWrite", isPreZ ? 0 : 1);

                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                    defaultRenderQueue = (int)UnityEngine.Rendering.RenderQueue.AlphaTest;
                    break;
                case BlendMode.AlphaBlend:
                    material.SetOverrideTag("RenderType", "Transparent");
                    material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                    material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                    material.SetInt("_ZWrite", 0);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.EnableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
                    defaultRenderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
                    break;
                case BlendMode.Transparent:
                    material.SetOverrideTag("RenderType", "Transparent");
                    material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                    material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                    material.SetInt("_ZWrite", 0);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.EnableKeyword("_ALPHAPREMULTIPLY_ON");
                    defaultRenderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
                    break;
            }

            // 用缓存的_CustomRenderQueue数据设置renderQueue，防止自定义的renderQueue被BlendMode的设置覆盖掉。
            if (material.HasProperty("_CustomRenderQueue"))
            {
                var customRenderQueue = (int)material.GetFloat("_CustomRenderQueue");
                material.renderQueue = customRenderQueue < 0 ? defaultRenderQueue : customRenderQueue;
            }
            else
            {
                material.renderQueue = defaultRenderQueue;
            }

            if (isPreZ)
            {
                // prez pass不写深度
                material.SetInt("_ZWrite", 0);
                material.SetInt("_ZTest", (int)UnityEngine.Rendering.CompareFunction.Equal);
            }
            else
            {
                material.SetInt("_ZTest", (int)UnityEngine.Rendering.CompareFunction.LessEqual);
            }
        }

        static void SetKeyword(Material m, string keyword, bool state)
        {
            if (state)
                m.EnableKeyword(keyword);
            else
                m.DisableKeyword(keyword);
        }
        static void SetMaterialKeywords(Material material, ref ShaderConfig config)
        {
            var keywords = material.shaderKeywords;
            foreach (var keyword in keywords)
            {
                // Keep the atlasing keyword if and only if the material is a combined one.
                if (keyword == "_TEXTURE_ATLASING_ON" && material.name.StartsWith("MaterialGroup-"))
                    continue;
                if (keyword == "_ALBEDO_AS_MICRO_OCC") continue;
                if (keyword == "_GPU_SKINNING") continue;
                material.DisableKeyword(keyword); 
            }
            // Note: keywords must be based on Material value not on MaterialProperty due to multi-edit & material animation
            // (MaterialProperty value might come from renderer material property block)
            foreach (var keyword in SubModeKeywords)
            {
                SetKeyword(material, keyword, keyword == config.keyword);
            }

            if (material.HasProperty("_AdvancedShadow") && material.GetFloat("_AdvancedShadow") == 1.0f)
            {
                if (config.hasCutout)
                    SetKeyword(material, "_ALPHATEST_ON", true);
            }

            // A material's GI flag internally keeps track of whether emission is enabled at all, it's enabled but has no effect
            // or is enabled and may be modified at runtime. This state depends on the values of the current flag and emissive color.
            // The fixup routine makes sure that the material is in the correct state if/when changes are made to the mode or color.
            MaterialEditor.FixupEmissiveFlag(material);

            bool shouldEmissionBeEnabled = (material.globalIlluminationFlags & MaterialGlobalIlluminationFlags.EmissiveIsBlack) == 0;
            //SetKeyword(material, "_EMISSION", shouldEmissionBeEnabled);
        }

        public static void SetMaterialKeywords(Material material)
        {
            if (MainModeDict == null)
            {
                InitConfig();
            }
            if (MainModeDict != null && MainModeDict.ContainsKey(material.shader.name))
            {
                var mainMode = MainModeDict[material.shader.name];
                int subMode = (int)material.GetFloat("_SubMode");
                var config = GetSubModeConfig(mainMode, (int)material.GetFloat("_SubMode"));
                SetMaterialKeywords(material, ref config);
            }
        }

        public static bool IsTODMaterial(Material material)
        {
            return IsStaticSingleTOD(material) || IsStaticDoubleTOD(material);
        }

        public static bool IsStaticSingleTOD(Material material)
        {
            if (MainModeDict == null)
            {
                InitConfig();
            }
            if (MainModeDict != null && material != null && MainModeDict.ContainsKey(material.shader.name))
            {
                var mainMode = MainModeDict[material.shader.name];
                if (mainMode == MainMode.StaticSingle)
                {
                    int subMode = (int)material.GetFloat("_SubMode");
                    return
                        (StaticSingleMode)subMode == StaticSingleMode.TOD || 
                        (StaticSingleMode)subMode == StaticSingleMode.TODalbedoTintMask;
                }
            }
            return false;
        }

        public static bool IsStaticDoubleTOD(Material material)
        {
            if (MainModeDict == null)
            {
                InitConfig();
            }
            if (MainModeDict != null && material != null && MainModeDict.ContainsKey(material.shader.name))
            {
                var mainMode = MainModeDict[material.shader.name];
                if (mainMode == MainMode.StaticDouble)
                {
                    int subMode = (int)material.GetFloat("_SubMode");
                    return
                        (StaticDoubleMode)subMode == StaticDoubleMode.TODGravityRock ||
                        (StaticDoubleMode)subMode == StaticDoubleMode.TODGravity;
                }
            }
            return false;
        }

        public static bool IsEmmisiveMaterial(Material material)
        {
            if (MainModeDict == null)
            {
                InitConfig();
            }
            if (MainModeDict != null && material != null && MainModeDict.ContainsKey(material.shader.name))
            {
                var mainMode = MainModeDict[material.shader.name];
                if (mainMode == MainMode.StaticSingle)
                {
                    int subMode = (int)material.GetFloat("_SubMode");
                    return
                        (StaticSingleMode)subMode == StaticSingleMode.Emission || (StaticSingleMode)subMode == StaticSingleMode.EmissionCutout;
                }
            }
            return false;
        }

        public static int GetNoneTODSubMode(Material material)
        {
            if (MainModeDict == null)
            {
                InitConfig();
            }
            if (MainModeDict != null && material != null && MainModeDict.ContainsKey(material.shader.name))
            {
                var mainMode = MainModeDict[material.shader.name];
                int subMode = (int)material.GetFloat("_SubMode");
                if (mainMode == MainMode.StaticSingle)
                {
                    if ((StaticSingleMode)subMode == StaticSingleMode.TOD)
                        return (int)StaticSingleMode.Opaque;
                    else if ((StaticSingleMode)subMode == StaticSingleMode.TODalbedoTintMask)
                        return (int)StaticSingleMode.AlbedoTintMask;
                }
                else if (mainMode == MainMode.StaticDouble)
                {
                    if ((StaticDoubleMode)subMode == StaticDoubleMode.TODGravityRock)
                        return (int)CFStandardShaderGUI.StaticDoubleMode.GravityRock;
                    else if ((StaticDoubleMode)subMode == StaticDoubleMode.TODGravity)
                        return (int)CFStandardShaderGUI.StaticDoubleMode.Gravity;
                }
            }

            // return negative means source material is not TOD or can not find correspondent non-TOD version
            return -1;
        }

        public static bool UseVertexColor(Material material)
        {
            if (MainModeDict == null)
            {
                InitConfig();
            }
 
            if (MainModeDict != null && material != null && MainModeDict.ContainsKey(material.shader.name))
            {
                if (material.shader.name == CODStandard_Foliage)
                    return true;

                var mainMode = MainModeDict[material.shader.name];
                if (mainMode == MainMode.StaticSingle)
                {
                    int subMode = (int)material.GetFloat("_SubMode");
                    return
                        (StaticSingleMode)subMode == StaticSingleMode.VertexAOnoLightmap ||
                        (StaticSingleMode)subMode == StaticSingleMode.TransparentTintVertex ||
                        (StaticSingleMode)subMode == StaticSingleMode.AlbedoTintVertex;
                }
            }
            return false;
        }
        public static bool IsFoliage(Material material)
        {
            if (MainModeDict == null)
            {
                InitConfig();
            }
            if (MainModeDict != null && material != null && MainModeDict.ContainsKey(material.shader.name))
            {
                if (material.shader.name == CODStandard_Foliage)
                    return true;
            }
            return false;
        }

        #region FIX Texture format in batch mode, code ported from CFShasderGUIBase::FixTexture
        public static void FixMaterialTextures(Material material)
        {
            if (MainModeDict == null)
                InitConfig();

            var mainMode = MainModeDict[material.shader.name];
            int subMode = (int)material.GetFloat("_SubMode");
            var config = GetSubModeConfig(mainMode, subMode);

            var mainTex = material.GetTexture("_MainTex");
            FixTextureInBatchMode(mainTex, GetMainTexFormat(material));

            var bumpMap = material.GetTexture("_BumpMapPakced");
            FixTextureInBatchMode(bumpMap, GetBumpMapFormat(material));
        }

        static RequestedMapFormat GetMainTexFormat(Material material)
        {
            if (MainModeDict == null)
                InitConfig();

            var mainMode = MainModeDict[material.shader.name];
            int subMode = (int)material.GetFloat("_SubMode");
            var config = GetSubModeConfig(mainMode, subMode);

            var alphaCutoff = material.GetFloat("_Cutoff");

            var format = new RequestedMapFormat();
            format.allowAniso = mainMode != MainMode.Dynamic;
            format.needAlpha = config.hasAlpha;
            if (config.hasCutout)
            {
                format.preserveCoverage = true;
                format.cutoutAlpha = alphaCutoff;
            }

            return format;
        }

        static RequestedMapFormat GetBumpMapFormat(Material material)
        {
            if (MainModeDict == null)
                InitConfig();

            var mainMode = MainModeDict[material.shader.name];
            int subMode = (int)material.GetFloat("_SubMode");
            var config = GetSubModeConfig(mainMode, subMode);

            var format = new RequestedMapFormat();
            format.allowAniso = mainMode != MainMode.Dynamic;
            format.sRGB = false;

            if (config.hasNormalMapAlpha)
                format.needAlpha = true;

            if (config.isClassicTexture)
                format.mipMode = TextureImporterMipFilter.KaiserFilter;
            else if (config.isNormalWithAo)
                format.mipMode = TextureImporterMipFilter.NormalX;
            else
                format.mipMode = TextureImporterMipFilter.NormalGlossiness;

            return format;
        }

        /// <summary>
        /// See CFShasderGUIBase::FixTexture
        /// </summary>
        protected static void FixTextureInBatchMode(Texture tex, RequestedMapFormat format)
        {
            var assetPath = AssetDatabase.GetAssetPath(tex);
            var texImport = AssetImporter.GetAtPath(assetPath) as TextureImporter;
            if (!texImport) return;

            string targetUserData = "EnableCustomFormatSetting";
            bool fixUserdata = !texImport.userData.Contains(targetUserData);
            if (fixUserdata)
                texImport.userData += targetUserData;

            if (!format.allowAniso)
            {
                bool fixaniso = texImport.anisoLevel > 1;
                if (fixaniso)
                    texImport.anisoLevel = -1;
            }

            bool fixsrgb = texImport.sRGBTexture != format.sRGB;
            if (fixsrgb)
                texImport.sRGBTexture = format.sRGB;

            bool fixMip = !texImport.mipmapEnabled;
            if (fixMip && !texImport.assetPath.ToLowerInvariant().Contains("_1p.") && format.enableMipMap)
                texImport.mipmapEnabled = true;

            bool fixMipMode = texImport.mipmapFilter != format.mipMode;
            if (fixMipMode)
                texImport.mipmapFilter = format.mipMode;

            bool fixTrilinear = texImport.filterMode != FilterMode.Trilinear;
            if (fixTrilinear)
                texImport.filterMode = FilterMode.Trilinear;

            var defaultFormat = texImport.GetDefaultPlatformTextureSettings();
            var standaloneFormat = texImport.GetStandaloneFormat();
            var standalone = format.needAlpha ? FormatStandaloneAlpha : FormatStandaloneNoAlpha;
            var android = format.needAlpha ? FormatAndroidAlpha : FormatAndroidNoAlpha;
            var androidFormat = texImport.GetAndroidFormat();
            var ios = format.needAlpha ? FormatIosAlpha : FormatIosNoAlpha;
            var iosFormat = texImport.GetAppleFormat();

            var compression = TextureCompression.Mixed;
            if (androidFormat.format == android[0] && iosFormat.format == ios[0])
                compression = TextureCompression.Compressed;
            if (androidFormat.format == android[1] && iosFormat.format == ios[1])
                compression = TextureCompression.Force16;
            if (androidFormat.format == android[2] && iosFormat.format == ios[2])
                compression = TextureCompression.Force24_32;

            switch (compression)
            {
                case TextureCompression.Compressed:
                    androidFormat.format = android[0];
                    iosFormat.format = ios[0];
                    standaloneFormat.format = standalone[0];
                    break;
                case TextureCompression.Force16:
                    androidFormat.format = android[1];
                    iosFormat.format = ios[1];
                    standaloneFormat.format = standalone[1];
                    break;
                case TextureCompression.Force24_32:
                    androidFormat.format = android[2];
                    // 这里用的是astc6x6，估计是对模型和地表而言，6x6质量已经够用了。UI才需要4x4
                    iosFormat.format = ios[1];
                    standaloneFormat.format = standalone[2];
                    break;
            }
            texImport.SetPlatformTextureSettings(androidFormat);
            texImport.SetPlatformTextureSettings(iosFormat);
            texImport.SetPlatformTextureSettings(standaloneFormat);


            bool fixAndroid =
                !androidFormat.overridden ||
                !android.Contains(androidFormat.format) ||
                androidFormat.maxTextureSize != defaultFormat.maxTextureSize;
            if (fixAndroid)
            {
                androidFormat.overridden = true;
                androidFormat.compressionQuality = GetQualityFromFormat(android[0]);
                androidFormat.format = android[0];
                androidFormat.maxTextureSize = defaultFormat.maxTextureSize;
                texImport.SetPlatformTextureSettings(androidFormat);
            }
            bool fixIos =
                !iosFormat.overridden ||
                !ios.Contains(iosFormat.format) ||
                iosFormat.maxTextureSize != defaultFormat.maxTextureSize;
            if (fixIos)
            {
                iosFormat.overridden = true;
                iosFormat.compressionQuality = GetQualityFromFormat(ios[0]);
                iosFormat.format = ios[0];
                iosFormat.maxTextureSize = defaultFormat.maxTextureSize;
                texImport.SetPlatformTextureSettings(iosFormat);
            }

            bool standaloneFormatGood = standalone.Contains(standaloneFormat.format);

            bool fixStandalone =
                !standaloneFormat.overridden ||
                !standaloneFormatGood ||
                standaloneFormat.maxTextureSize != defaultFormat.maxTextureSize;
            if (fixStandalone)
            {
                standaloneFormat.overridden = true;
                standaloneFormat.compressionQuality = GetQualityFromFormat(standalone[0]);
                standaloneFormat.format = standalone[0];
                standaloneFormat.maxTextureSize = defaultFormat.maxTextureSize;
                texImport.SetPlatformTextureSettings(standaloneFormat);
            }

            texImport.SaveAndReimport();
        }
        #endregion

        public override void OnMaterialChanged(Material material)
        {
            base.OnMaterialChanged(material);
            MaterialChanged(material);
        }
        public static void MaterialChanged(Material material)
        {
            if (!MainModeDict.ContainsKey(material.shader.name))
            {
                Debug.Log(material.shader.name + " not exist!!");
            }

            var mainMode = MainModeDict[material.shader.name];
            var config = GetSubModeConfig(mainMode, (int)material.GetFloat("_SubMode"));
            if (string.IsNullOrEmpty(config.keyword))
            {
                material.SetFloat("_SubMode", 0);
                config = GetSubModeConfig(mainMode, 0);
            }

            SetupMaterialWithBlendMode(material, config.blendMode, config.isPreZ);

            SetMaterialKeywords(material, ref config);

            if (config.noAlbedoMap)
            {
                material.SetTexture("_MainTex", null);
            }
            if (!config.hasNormalMap)
            {
                material.SetTexture("_BumpMap", null);
                material.SetTexture("_BumpMapPakced", null);
            }
            if (!config.hasMetallicMap)
            {
                material.SetTexture("_MetallicRoughnessMap", null);
            }
            if (!config.hasEmissionMap)
            {
                material.SetColor("_EmissionColor", Color.black);
                material.SetTexture("_EmissionMap", null);
            }
            if (!config.hasDetailAlbedo)
            {
                material.SetTexture("_DetailAlbedoMap", null);
            }
            if (!config.hasDetailNormal)
            {
                material.SetTexture("_DetailNormalMap", null);
            }
            //if (!config.hasDetailMask)
            //{
            //    material.SetTexture("_DetailMask", null);
            //}
            if (!(config.hasHeightMap && !config.isAlphaHeightMap))
            {
                material.SetTexture("_HeightMap", null);
            }
            if (!config.hasTopLayerAlbedoMap)
            {
                material.SetTexture("_OverBaseColor", null);
            }
            //if (!config.hasRimMap)
            //{
            //    material.SetTexture("_CutRimTex", null);
            //}
            if (!config.hasTopLayerNormalMap)
            {
                material.SetTexture("_OverNormalMap", null);
            }

            if (config.noAlbedoMap2)
            {
                material.SetTexture("_MainTex2", null);
            }
            if (!config.hasNormalMap2)
            {
                material.SetTexture("_BumpMapPakced2", null);
            }
            if (!config.hasTodLightmap)
            {
                material.SetTexture("_TodLightMap", null);
                material.SetVector("_TodParameter", Vector4.zero);
                material.SetVector("_TodFakeShadowCoeff", Vector4.zero);
            }
            material.SetFloat("_Parallax", 0);
        }

    }
    public static class ShaderGUIExtend
    {
        public static TextureImporterPlatformSettings GetAndroidFormat(this TextureImporter texImport)
        {
            return texImport.GetPlatformTextureSettings("Android");
        }
        public static TextureImporterPlatformSettings GetAppleFormat(this TextureImporter texImport)
        {
            return texImport.GetPlatformTextureSettings("iPhone");
        }
        public static TextureImporterPlatformSettings GetStandaloneFormat(this TextureImporter texImport)
        {
            return texImport.GetPlatformTextureSettings("Standalone");
        }

#endif
    }
} // namespace UnityEditor