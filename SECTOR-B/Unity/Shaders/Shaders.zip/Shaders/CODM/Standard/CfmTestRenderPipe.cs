﻿using UnityEngine;
using UnityEngine.Rendering;
using System;

namespace GameEngine
{

    [ExecuteInEditMode]
    [RequireComponent(typeof(Camera))]
    public partial class CfmTestRenderPipe : MonoBehaviour
    {
        static class ShaderIDs
        {
            internal static readonly int MainTex = Shader.PropertyToID("_MainTex");
            internal static readonly int SecTex = Shader.PropertyToID("_SecTex");
            internal static readonly int _TempRT = Shader.PropertyToID("_TempRT");
            internal static readonly int _TempRT2 = Shader.PropertyToID("_TempRT2");
            internal static readonly int BloomTex = Shader.PropertyToID("_BloomTex");
        }

        public RenderTextureFormat mRTFormat = RenderTextureFormat.ARGBHalf;

        RenderpipeProfile m_Profile;
        RenderpipeProfile Profile { get { if (m_Profile == null) m_Profile = new RenderpipeProfile(); return m_Profile; } }


        [Serializable]
        public class BaseSetting
        {
            public bool enabled;
        }

        #region ACES
        bool mUseSimpleACES = true;
        public bool UseSimpleACES
        {
            get { return mUseSimpleACES; }
            set { mUseSimpleACES = value; }
        }

        [Serializable]
        public class SimpleACESSetting : BaseSetting
        {
            [Range(0.0f, 20.0f)]
            public float AdaptNum = 1f;
        }
        protected SimpleACESSetting mACESSetting { get { return Profile != null ? Profile.ACES : null; } }
        protected Material mSimpleACESMat;
#if UNITY_EDITOR
        protected Material mSimpleACESMatEditor;
#endif
        public Material GetAcesMat()
        {
            return mSimpleACESMat;
        }
        #endregion

        #region razor ACES
        protected RuntimeData mRazorACESRuntime { get { return Profile != null ? Profile.RazorTonemappingRuntimeData : RuntimeData.Default(); } }
        [Serializable]
        public struct RuntimeData
        {
            /// curve parameters for curve function (ax^2+bx) / (cx^2+dx +1)
            /// Notice: original aces curve has an "e" in it, we eliminate it with division.
            public Vector3 aces_a;
            public Vector3 aces_b;
            public Vector3 aces_c;
            public Vector3 aces_d;

            // runtime white point this point
            public Vector3 whitePoint;

            // original ACES parameters:
            public const float ACES_A = 17.9285f;
            public const float ACES_B = 0.214285f;
            public const float ACES_C = 17.3571f;
            public const float ACES_D = 4.21428f;
            public const float ACES_WHITE_POINT = 50.0f;

            public RuntimeData(Vector3 _aces_a, Vector3 _aces_b, Vector3 _aces_c, Vector3 _aces_d, Vector3 _whitePoint)
            {
                aces_a = _aces_a;
                aces_b = _aces_b;
                aces_c = _aces_c;
                aces_d = _aces_d;
                whitePoint = _whitePoint;
            }

            /// <summary>
            /// Return the original ACES parameters:
            /// </summary>
            /// <returns></returns>
            public static RuntimeData Default()
            {
                return new RuntimeData(new Vector3(ACES_A, ACES_A, ACES_A),
                                        new Vector3(ACES_B, ACES_B, ACES_B),
                                        new Vector3(ACES_C, ACES_C, ACES_C),
                                        new Vector3(ACES_D, ACES_D, ACES_D),
                                        new Vector3(ACES_WHITE_POINT, ACES_WHITE_POINT, ACES_WHITE_POINT)
                    );
            }
        }

        [Serializable]
        public class TonemappingSetting
        {
            public Vector2 toe = new Vector2(7.2f, 7.5f);
            public float shoulderAngle = 60.9f;
            public float shoulderShoot = 18.4f;
            public float toeStrength = 70.74f;
            public float toeLift = 28.8f;
            public float shoulderStrength = 97.3f;
            public float shoulderLift = 80.0f;
            public Vector2 whitePoint = new Vector2(6.0f, 1.0f);
            public float gamma = 1.0f;

            public void ConstrainParameter()
            {
                // clamp toe point:
                toe.x = Mathf.Max(toe.x, 0.0f);
                toe.y = Mathf.Clamp(toe.y, 0.0f, 100.0f);
                toeStrength = Mathf.Clamp(toeStrength, 0.1f, 99.9f);
                toeLift = Mathf.Clamp(toeLift, 0.1f, 99.9f);

                // clamp shoulder angle:
                shoulderAngle = Mathf.Clamp(shoulderAngle, 0.1f, 89.0f);
                float rad = Mathf.Deg2Rad * shoulderAngle;
                Vector2 shoulderDir = new Vector2(Mathf.Cos(rad), Mathf.Sin(rad));
                float slope = shoulderDir.y / shoulderDir.x;

                // constrain toe point:
                float toeSlope = toe.y / toe.x;
                if (slope < toeSlope)
                {
                    // make the toe slope less equal to linear part slope, this is good for fitting result.
                    toe.y = slope * toe.x;
                }
                // constrain shoulder shoot:
                shoulderShoot = Mathf.Max(shoulderShoot, 0.0f);
                shoulderStrength = Mathf.Clamp(shoulderStrength, 0.1f, 99.9f);
                shoulderLift = Mathf.Clamp(shoulderLift, 0.1f, 99.9f);
                whitePoint.x = Mathf.Clamp(whitePoint.x, 0.1f, 50.9f);
                whitePoint.y = Mathf.Clamp01(whitePoint.y);
                gamma = Mathf.Max(gamma, .01f);
            }
        }
        #endregion

        public class RenderpipeProfile
        {
            public bool changed { get; set; }
            public CfmTestRenderPipe.SimpleACESSetting ACES = new CfmTestRenderPipe.SimpleACESSetting();
            public CfmTestRenderPipe.BloomSetting Bloom = new CfmTestRenderPipe.BloomSetting();

            public CfmTestRenderPipe.TonemappingSetting RazorTonemappingSetting = new CfmTestRenderPipe.TonemappingSetting();
            public CfmTestRenderPipe.RuntimeData RazorTonemappingRuntimeData = CfmTestRenderPipe.RuntimeData.Default();

        }


        #region Bloom
        private bool mUseBloom = false;
        public bool UseBloom
        {
            get { return mUseBloom; }
            set
            {
                if (value != mUseBloom)
                {
                    mUseBloom = value;
                    if (Bloom != null)
                    {
                        Bloom.enabled = value;
                    }
                    mChanged = true;
                }
            }
        }

        [Serializable]
        public class BloomSetting : BaseSetting
        {
            public Color colorMix = new Color(1.0f, 1.0f, 1.0f, 1.0f);
            [Range(0.0f, 10.0f)]
            public float threshold = 0.25f;

            [Range(0.0f, 2.5f)]
            public float intensity = 0.75f;

            [Range(0.2f, 3.0f)]
            public float BlurSize = 1.0f;
        }

        protected BloomSetting Bloom { get { return Profile != null ? Profile.Bloom : null; } }
        protected Material mBloomMaterial;

        #endregion

        //-------------------------------------------------------------------//

        public RenderTexture mMainRT;

        protected int mWidth;
        protected int mHeight;

        enum EEffectType
        {
            //World

            //FP,
            Bloom = 8,

            //PP
            SimpleACES = 16,
        }

        enum ECommandBufferType
        {
            PostPP = 0,
            PostCount,
        }

        protected bool mUseSecRT = false;
        protected bool mRTFormatChanged = false;
        protected int mEffectFlag = 0;
        protected bool mChanged = false;
        public Camera mWorldCamera;
        protected Camera mPostprocessCamera;

        protected static CfmTestRenderPipe mInstance;
        public static CfmTestRenderPipe Instance
        {
            get
            {
                return mInstance;
            }
        }
        CommandBuffer[] mCommandBuffers = new CommandBuffer[(int)ECommandBufferType.PostCount];
        EEffectType[] mEffectTypeValues;
        void Awake()
        {
            mInstance = this;

            mPostprocessCamera = GetComponent<Camera>();
            mEffectTypeValues = Enum.GetValues(typeof(EEffectType)) as EEffectType[];
            Shader.EnableKeyword("_USE_DYNAMIC_LIGHT");
        }


        private void Start()
        {
            bool allowHDR = mSupport;
            bool allowMSAA = mSupport;

            mWorldCamera.allowHDR = allowHDR;
            mWorldCamera.allowMSAA = allowMSAA;

            mPostprocessCamera.allowHDR = false;
            mPostprocessCamera.allowMSAA = false;
        }

        CommandBuffer GetClearedCommandBuffer(ECommandBufferType type)
        {
            int index = (int)type;

            var cb = mCommandBuffers[index];
            if (cb == null)
            {
                cb = new CommandBuffer();
                cb.name = type.ToString();
                mCommandBuffers[index] = cb;
            }
            cb.Clear();
            return cb;
        }

        private void OnDestroy()
        {
            mInstance = null;
            Shader.DisableKeyword("_USE_DYNAMIC_LIGHT");
        }

        void PreDestroyRT(RenderTexture rt)
        {
            if (mWorldCamera)
            {
                if (mWorldCamera.targetTexture == rt)
                {
                    mWorldCamera.targetTexture = null;
                }
            }
        }

        void DestroyRT()
        {
            if (mMainRT != null)
            {
                PreDestroyRT(mMainRT);
                mMainRT.Release();
                DestroyObj(mMainRT);
                mMainRT = null;
            }
        }

        void DestroyObj(UnityEngine.Object obj)
        {
            if (obj != null)
            {
#if UNITY_EDITOR
                if (Application.isPlaying)
                    UnityEngine.Object.Destroy(obj);
                else
                    UnityEngine.Object.DestroyImmediate(obj);
#else
            UnityEngine.Object.Destroy(obj);
#endif
            }
        }


        private void UpdateOnePass()
        {
            bool isCurrentOnePass = Shader.IsKeywordEnabled("ONEPASS_TONEMAPPING");
            if (mUseOnePass && !isCurrentOnePass)
            {
                Shader.EnableKeyword("ONEPASS_TONEMAPPING");
                Debug.Log("SceneSetting.OpenOnepassTonemapping()");//debug
            }
            if (!mUseOnePass && isCurrentOnePass)
            {
                Shader.DisableKeyword("ONEPASS_TONEMAPPING");
                Debug.Log("SceneSetting.CloseOnepassTonemapping()");//debug
            }
#if UNITY_EDITOR
            //if (mUseOnePass)
            //{
            //    UnityEditor.SceneView.blitColorspaceMaterial = null;
            //}
            //else
            //{
            //    UnityEditor.SceneView.blitColorspaceMaterial = mSimpleACESMatEditor;
            //}
#endif
        }

        void OnEnable()
        {
            CheckSupport();
            mChanged = true;
            SetupMaterials();

            UpdateOnePass();
            if (!mSupport)
            {
                mWorldCamera.targetTexture = null;
                UpdateParam();
            }
        }

        void OnDisable()
        {
            Shader.DisableKeyword("ONEPASS_TONEMAPPING");
            Shader.SetGlobalFloat("_AdaptNum", 1);
            Shader.SetGlobalFloat("_AdaptNumGamma", 1);
            Debug.Log("SceneSetting.CloseOnepassTonemapping()");//debug
#if UNITY_EDITOR
            //UnityEditor.SceneView.blitColorspaceMaterial = null;
#endif
            if (mWorldCamera)
            {
                mWorldCamera.RemoveAllCommandBuffers();
            }

            if (mPostprocessCamera)
            {
                mPostprocessCamera.RemoveAllCommandBuffers();
            }

            DestroyRT();
        }
        
        bool UpdateRT()
        {
            int width = Screen.width;
            int height = Screen.height;

            if (mMainRT == null || mWidth != width || mHeight != height || mRTFormatChanged)
            {
                mRTFormatChanged = false;

                DestroyRT();
                mWidth = width;
                mHeight = height;
                mMainRT = CreateFullSreenRT();
                return true;
            }
            return false;
        }

        RenderTexture CreateFullSreenRT()
        {
            var rt = new RenderTexture(mWidth, mHeight, 24);
            rt.filterMode = FilterMode.Bilinear;
            rt.format = mRTFormat;

#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                rt.antiAliasing = 4;
            }
            else
#endif
            {
                rt.antiAliasing = 4;
            }

            rt.Create();
            return rt;
        }

        bool mSupport = false;
#if UNITY_EDITOR
        const RenderTextureFormat HDRFormat = RenderTextureFormat.ARGBHalf;
#else
        const RenderTextureFormat HDRFormat = RenderTextureFormat.RGB111110Float;
#endif
        protected bool mUseOnePass = false;
        void CheckRTFormat()
        {
            bool useHDR = SystemInfo.SupportsRenderTextureFormat(HDRFormat);
            mRTFormat = useHDR ? HDRFormat : RenderTextureFormat.Default;
        }


        void CheckSupport()
        {
            CheckRTFormat();
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                mSupport = mRTFormat == HDRFormat;
            }
            else
#endif
            {
                mSupport = true && mRTFormat == HDRFormat;
            }

            //mSupport = mDeviceLevel > UserSettingLevel.VeryLow && mRTFormat == HDRFormat;

            mUseSimpleACES = mSupport;

            if (mSupport)
            {
                mUseOnePass = false;
            }
            else
            {
                mUseOnePass = true;
            }
        }

        bool HasEffect()
        {
            return mEffectFlag > 0;
        }

        bool UpdateFlag()
        {
            int mOldFlag = mEffectFlag;
            
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                mUseBloom = Profile.Bloom.enabled;
            }
            else
#endif
            {
                mUseBloom = true && Profile.Bloom.enabled;
            }
            
            /*            
            if (mDeviceLevel < UserSettingLevel.High)
            {
                mUseBloom = false;
            }
            else
            {
                mUseBloom = m_Profile.Bloom.enabled;
            }*/
            mEffectFlag = 0;

            bool[] flagArr = { UseBloom, UseSimpleACES };
            for (int i = 0; i < flagArr.Length; i++)
            {
                mEffectFlag |= flagArr[i] ? 1 << (int)mEffectTypeValues[i] : 0;
            }
            return mOldFlag != mEffectFlag;
        }

        void SetupMaterials()
        {
            if (UseBloom && !mBloomMaterial)
            {
                mBloomMaterial = Resources.Load<Material>("SimpleBloom");
            }

            if (UseSimpleACES && !mSimpleACESMat)
            {
                mSimpleACESMat = Resources.Load<Material>("SimpleACES");
#if UNITY_EDITOR
                if (!Application.isPlaying)
                {
                    mSimpleACESMat = new Material(mSimpleACESMat);
                    mSimpleACESMat.shader = AssetManager.LoadShader("Hidden/PostProcess/SimpleACES In Editor");
                }
                mSimpleACESMatEditor = new Material(mSimpleACESMat);
#endif
            }
        }

        void SetupCommandBuffer()
        {
            bool effect = HasEffect();

            if (mWorldCamera)
            {
                mWorldCamera.targetTexture = effect ? mMainRT : null;

            }

            if (mPostprocessCamera)
            {
                if (mPostprocessCamera.commandBufferCount > 0)
                {
                    mPostprocessCamera.RemoveCommandBuffers(CameraEvent.BeforeImageEffects);
                }
                if (effect)
                {
                    CommandBuffer cb = GetClearedCommandBuffer(ECommandBufferType.PostPP);
                    if (UseBloom && mBloomMaterial && Bloom != null)
                    {
                        int rtW = mWidth / 4;
                        int rtH = mHeight / 4;

                        cb.GetTemporaryRT(ShaderIDs._TempRT, rtW, rtH, 0, FilterMode.Bilinear, mRTFormat, RenderTextureReadWrite.Linear);
                        cb.Blit(mMainRT, ShaderIDs._TempRT, mBloomMaterial, 0);

                        // blur
                        {
                            cb.GetTemporaryRT(ShaderIDs._TempRT2, rtW, rtH, 0, FilterMode.Bilinear, mRTFormat, RenderTextureReadWrite.Linear);
                            cb.Blit(ShaderIDs._TempRT, ShaderIDs._TempRT2, mBloomMaterial, 1);
                            cb.Blit(ShaderIDs._TempRT2, ShaderIDs._TempRT, mBloomMaterial, 2);
                            cb.ReleaseTemporaryRT(ShaderIDs._TempRT2);
                        }

                        mSimpleACESMat.EnableKeyword("_TONEMAPPING_AFTER_BLOOM");
                        cb.SetGlobalTexture(ShaderIDs.BloomTex, ShaderIDs._TempRT);
                        cb.Blit(mMainRT, BuiltinRenderTextureType.CameraTarget, mSimpleACESMat, 0);

                        cb.ReleaseTemporaryRT(ShaderIDs._TempRT);
                    }
                    else
                    {
                        if (mSimpleACESMat)
                        {
                            mSimpleACESMat.DisableKeyword("_TONEMAPPING_AFTER_BLOOM");
                            if (UseSimpleACES && mSimpleACESMat)
                            {
                                cb.Blit(mMainRT, BuiltinRenderTextureType.CameraTarget, mSimpleACESMat, 0);
                            }
                        }
                    }

                    mPostprocessCamera.AddCommandBuffer(CameraEvent.BeforeImageEffects, cb);
                }

            }
        }

        void UpdateParam()
        {
            if (!mUseOnePass)
            {
                if (UseSimpleACES && mSimpleACESMat && mACESSetting != null)
                {
                    mSimpleACESMat.SetVector("_aces_a", mRazorACESRuntime.aces_a);
                    mSimpleACESMat.SetVector("_aces_b", mRazorACESRuntime.aces_b);
                    mSimpleACESMat.SetVector("_aces_c", mRazorACESRuntime.aces_c);
                    mSimpleACESMat.SetVector("_aces_d", mRazorACESRuntime.aces_d);
                    mSimpleACESMat.SetVector("_aces_whitePoint", mRazorACESRuntime.whitePoint);
                    if (Bloom != null)
                    {
                        mSimpleACESMat.SetVector("_Parameter", new Vector4(Bloom.BlurSize * 1.5f, 0.0f, Bloom.intensity, Bloom.threshold));
                    }
#if UNITY_EDITOR
                    mSimpleACESMatEditor.SetVector("_aces_a", mRazorACESRuntime.aces_a);
                    mSimpleACESMatEditor.SetVector("_aces_b", mRazorACESRuntime.aces_b);
                    mSimpleACESMatEditor.SetVector("_aces_c", mRazorACESRuntime.aces_c);
                    mSimpleACESMatEditor.SetVector("_aces_d", mRazorACESRuntime.aces_d);
                    mSimpleACESMatEditor.SetVector("_aces_whitePoint", mRazorACESRuntime.whitePoint);
                    if (mSimpleACESMatEditor.IsKeywordEnabled("_TONEMAPPING_AFTER_BLOOM"))
                        mSimpleACESMatEditor.DisableKeyword("_TONEMAPPING_AFTER_BLOOM");
#endif
                }
            }
            else
            {
                Shader.SetGlobalVector("_aces_a", mRazorACESRuntime.aces_a);
                Shader.SetGlobalVector("_aces_b", mRazorACESRuntime.aces_b);
                Shader.SetGlobalVector("_aces_c", mRazorACESRuntime.aces_c);
                Shader.SetGlobalVector("_aces_d", mRazorACESRuntime.aces_d);
                Shader.SetGlobalVector("_aces_whitePoint", mRazorACESRuntime.whitePoint);
            }
#if UNITY_EDITOR
            if (Application.isPlaying)
            {
                Shader.SetGlobalFloat("_AdaptNum", mACESSetting.AdaptNum);
                Shader.SetGlobalFloat("_AdaptNumGamma", Mathf.Sqrt(mACESSetting.AdaptNum));
            }
            else
            {
                Shader.SetGlobalFloat("_AdaptNum", 1.0f);
                Shader.SetGlobalFloat("_AdaptNumGamma", 1.0f);
                if (mSimpleACESMat)
                {
                    mSimpleACESMat.SetFloat("_AdaptNum", 1.0f);
                    mSimpleACESMat.SetFloat("_AdaptNumGamma", Mathf.Sqrt(1.0f));
                    mSimpleACESMatEditor.SetFloat("_AdaptNum", 1.0f);
                    mSimpleACESMatEditor.SetFloat("_AdaptNumGamma", Mathf.Sqrt(1.0f));
                }
            }
#else
            Shader.SetGlobalFloat("_AdaptNum", mACESSetting.AdaptNum);
            Shader.SetGlobalFloat("_AdaptNumGamma", Mathf.Sqrt(mACESSetting.AdaptNum));
#endif

            if (UseBloom && mBloomMaterial && Bloom != null)
            {
                var bloom = Bloom;
                mBloomMaterial.SetColor("_ColorMix", bloom.colorMix);
                mBloomMaterial.SetVector("_Parameter", new Vector4(bloom.BlurSize * 1.5f, 0.0f, bloom.intensity, bloom.threshold));
                if (mSimpleACESMat)
                {
                    if (!mSimpleACESMat.IsKeywordEnabled("_TONEMAPPING_AFTER_BLOOM"))
                        mSimpleACESMat.EnableKeyword("_TONEMAPPING_AFTER_BLOOM");
                }
            }
            else
            {
                if (mSimpleACESMat)
                {
                    if (mSimpleACESMat.IsKeywordEnabled("_TONEMAPPING_AFTER_BLOOM"))
                        mSimpleACESMat.DisableKeyword("_TONEMAPPING_AFTER_BLOOM");
                }
            }
        }
#if UNITY_EDITOR
        void UpdateForEditor()
        {
            if (!Application.isPlaying)
            {
                CheckSupport();
                UpdateOnePass();
                if (!mUseSimpleACES)
                {
                    mUseSimpleACES = true;
                    mChanged = true;
                }
                if (!mWorldCamera)
                {
                    mWorldCamera = Camera.main;
                }
                UpdateParam();
            }
        }
#endif

        void Update()
        {
#if UNITY_EDITOR
            UpdateForEditor();
#endif
            if (!mPostprocessCamera || Profile == null)
            {
                return;
            }
            if (!mWorldCamera)
            {
                return;
            }

            bool needUpdate = true;
            if (mChanged)
            {
                mChanged = false;
                if (UpdateFlag())
                {
                    needUpdate = false;
                    if (HasEffect())
                    {
                        UpdateRT();
                        UpdateParam();
                    }
                    //else
                    //{
                    //    DestroyRT();
                    //}
                    SetupCommandBuffer();
                }
            }
            if (needUpdate)
            {
                if (HasEffect())
                {
                    if (UpdateRT())
                    {
                        SetupCommandBuffer();
                        UpdateParam();
                    }
                    else
                    {
                        bool forceUpdate = false;
#if UNITY_EDITOR
                        if (Profile.changed)
                        {
                            forceUpdate = true;
                            Profile.changed = false;
                        }
#endif
                        if (forceUpdate)
                            UpdateParam();
                    }
                }
            }
        }


        protected void SimpleBloom(RenderTexture from, CommandBuffer cb)
        {
        }
    }
}

