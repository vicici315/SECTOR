﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class CODMLegacy3PGUI : ShaderGUI {

	MaterialProperty color = null;
	MaterialProperty mainTex = null;
	MaterialProperty specularColor = null;
	MaterialProperty diffuseScale = null;
	MaterialProperty diffuseLerpEmissive = null;
	MaterialProperty giDiffuseScale = null;

	MaterialProperty detailAlbedoMap = null;
	MaterialProperty detailOpacity = null;

	MaterialProperty RimColor = null;
	MaterialProperty RimRange = null;
	MaterialProperty RimIntensity = null;

	bool useDetailMap = false;

	protected MaterialEditor m_MaterialEditor;

	public enum DetailBlendMode { None, Lerp , Mul }
    MaterialProperty detailBlendMode = null;
    private string[] detailBlendModeNames = new string[] { "None",  "Lerp" , "Mul"};

	public virtual void FindProperties(MaterialProperty[] props)
    {
		color = FindProperty("_Color", props, false);
		mainTex = FindProperty("_MainTex", props, false);
		specularColor = FindProperty("_SpecularColor", props, false);
		diffuseScale = FindProperty("_DiffuseScale", props, false);
		diffuseLerpEmissive = FindProperty("_DiffuseLerpEmissive", props, false);
		giDiffuseScale = FindProperty("_GIDiffuseScale", props, false);

		detailAlbedoMap = FindProperty("_DetailAlbedoMap", props, false);
		detailOpacity = FindProperty("_DetailOpacity", props, false);

		useDetailMap = (detailAlbedoMap != null);

		detailBlendMode = FindProperty("_DetialBlendMode", props, false);

		RimColor = FindProperty ("_RimColor", props, false);
		RimRange = FindProperty ("_RimRange", props, false);
		RimIntensity = FindProperty ("_RimIntensity", props, false);
	}

	public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
    {
        FindProperties(props);
        m_MaterialEditor = materialEditor;
        Material material = materialEditor.target as Material;

        ShaderPropertiesGUI(material);
        materialEditor.EnableInstancingField();
    }

	public virtual void ShaderPropertiesGUI(Material material)
    {
		EditorGUI.BeginChangeCheck();
        {
			DetailBlendPopup();
			
			m_MaterialEditor.SetDefaultGUIWidths();
			m_MaterialEditor.ColorProperty(color, "Main Color");
			m_MaterialEditor.TextureProperty(mainTex, "Main Texture");
			m_MaterialEditor.ColorProperty(specularColor, "Specular Color");

			m_MaterialEditor.RangeProperty(diffuseScale, "Diffuse Scale");
			m_MaterialEditor.RangeProperty(diffuseLerpEmissive, "Diffuse Lerp Emissive");
			m_MaterialEditor.RangeProperty(giDiffuseScale, "GI Scale");

			m_MaterialEditor.TextureProperty(detailAlbedoMap, "Detail Map");
			m_MaterialEditor.RangeProperty(detailOpacity, "Detail Opacity");

			m_MaterialEditor.ColorProperty (RimColor, "Rim Color");
			m_MaterialEditor.FloatProperty (RimRange, "Rim Range");
			m_MaterialEditor.RangeProperty (RimIntensity, "Rim Intensity");

			useDetailMap = detailAlbedoMap.textureValue != null || (DetailBlendMode)detailBlendMode.floatValue != DetailBlendMode.None;
		}

		if (EditorGUI.EndChangeCheck())
        {
			if (useDetailMap) {
				SetupMaterialDetailBlendMode(material, (DetailBlendMode)detailBlendMode.floatValue);
			} else {
				SetupMaterialDetailBlendMode(material, DetailBlendMode.None);
			}
		}
	}

	void DetailBlendPopup()
    {
        EditorGUI.showMixedValue = detailBlendMode.hasMixedValue;
        var detailBlend = (DetailBlendMode)detailBlendMode.floatValue;

        EditorGUI.BeginChangeCheck();
        detailBlend = (DetailBlendMode)EditorGUILayout.Popup("Detail Blend Mode", (int)detailBlend, detailBlendModeNames);
        if (EditorGUI.EndChangeCheck())
        {
            m_MaterialEditor.RegisterPropertyChangeUndo("Detail Blend Mode");
            detailBlendMode.floatValue = (float)detailBlend;
            Debug.Log(detailBlend);
        }
        EditorGUI.showMixedValue = false;
    }

	public static void SetupMaterialDetailBlendMode(Material material, DetailBlendMode detialBlendMode)
    {
        material.DisableKeyword("_DETAIL_LERP");
		material.DisableKeyword("_DETAIL_MUL");

        if (detialBlendMode == DetailBlendMode.None)
        {
            // 没有Detail Mode
            return;
        }

        // 下面并不影响Shader流程，但是却能够记录Shader分支变量进入Material中
        material.SetInt("_DetialBlendMode", (int)detialBlendMode);
        switch (detialBlendMode)
        {
            //case DetailBlendMode.Add:
            //    material.EnableKeyword("_DETAIL_ADD");
            //    break;
            case DetailBlendMode.Mul:
                material.EnableKeyword("_DETAIL_MUL");
                break;
            //case DetailBlendMode.MulX2:
            //    material.EnableKeyword("_DETAIL_MULX2");
            //    break;
            case DetailBlendMode.Lerp:
                material.EnableKeyword("_DETAIL_LERP");
                break;
            //case DetailBlendMode.DesaturateBlend:
            //    material.EnableKeyword("_DETAIL_DESATURATE");
            //    break;
        }
    }

}
