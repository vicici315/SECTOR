﻿using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor;
using System;
using System.Collections;

public class MSParticleGUI : ShaderGUI
{
	MaterialProperty albedoColor = null;
	MaterialProperty albedoMap = null;

	MaterialProperty maskTex = null;

	MaterialProperty twistTex = null;
	MaterialProperty twistScale = null;
    MaterialProperty twistScaleX = null;

	MaterialProperty dissoveTex = null;
	MaterialProperty dirDissove = null;
	MaterialProperty meltPlane = null;
	MaterialProperty edgeThreshold = null;
	MaterialProperty edgeOn = null;
	MaterialProperty edgeColor = null;

	MaterialProperty uvScrollSpeed = null;
	MaterialProperty uvSequenceRows = null;
	MaterialProperty uvSequenceColumns = null;
	MaterialProperty uvSequenceSpeed = null;
	MaterialProperty uvScrollMTSpeed = null;

	MaterialProperty meshOn = null;
	MaterialProperty scrAlpha = null;
    MaterialProperty fogOn = null;
	MaterialProperty mulColOnePass = null;

	MaterialProperty reverseFresnel = null;
	MaterialProperty rimColor = null;
	MaterialProperty rimPower = null;
	MaterialProperty rimIntensity = null;

    MaterialEditor m_MaterialEditor;

	public enum FeatureType {None,Mask,Twist,Dissove}
	MaterialProperty featureType = null;
	private string[] featureTypeNames = new string[] {"None","Mask","Twist","Dissove"};
	public FeatureType subModeF;

	public enum FeatureTypeUV {None,UVScroll,UVSequence}
	MaterialProperty featureTypeUV = null;
	private string[] featureTypeUVNames = new string[] {"None","UV Scroll","UV Sequence"};

	public enum FeatureTypeFresnel {None, Fresnel}
	MaterialProperty featureTypeFresnel = null;
	private string[] featureTypeFresnelNames = new string[] {"None", "Fresnel"};

	public bool hasMask = false;
	public bool hasTwist = false;
	public bool hasDissove = false;

	public bool hasUVScroll = false;
	public bool hasUVSequence = false;

	public bool hasFresnel = false;


	public enum BlendMode { Additive, AlphaBlend }
    MaterialProperty blendMode = null;
    private string[] blendNames = new string[] { "Additive", "Alpha Blend" };

    public enum CullMode { Off, Front, Back }
    MaterialProperty cullMode = null;
	private string[] cullModeNames = new string[] { "Double Side (Default)", "Cull Front", "Cull Back" };


    MaterialProperty ztestMode = null;

    public void FindProperties(MaterialProperty[] props)
    {
		albedoColor = FindProperty("_TintColor", props, false);
        albedoMap = FindProperty("_MainTex", props, false);

        blendMode = FindProperty("_Mode", props, false);
        cullMode = FindProperty("_CullMode", props, false);

		featureType = FindProperty("_SubMode", props, false);
		maskTex = FindProperty("_MaskTex", props, false);

		twistTex = FindProperty("_TwistTex", props, false);
		twistScale = FindProperty("_TwistScale", props, false);
        twistScaleX = FindProperty("_TwistScaleX", props, false);

        dissoveTex = FindProperty("_DissoveTex", props, false);
		dirDissove = FindProperty("_DirDissove", props, false);
		meltPlane = FindProperty("_MeltPlane", props, false);
		edgeThreshold = FindProperty("_EdgeThreshold", props, false);
		edgeOn = FindProperty("_EdgeOn", props, false);
		edgeColor = FindProperty("_EdgeColor", props, false);

		featureTypeUV = FindProperty("_SubModeUV", props, false);
		uvScrollSpeed = FindProperty("_UVScrollSpeed", props, false);
        uvScrollMTSpeed = FindProperty("_UVScrollMTSpeed", props, false);
		uvSequenceRows = FindProperty("_SizeX", props, false);
		uvSequenceColumns = FindProperty("_SizeY", props, false);
		uvSequenceSpeed = FindProperty("_Speed", props, false);

		featureTypeFresnel = FindProperty("_SubModeFresnel", props, false);
		reverseFresnel = FindProperty("_ReverseFresnel", props, false);
		rimColor = FindProperty("_RimColor", props, false);
		rimPower = FindProperty("_RimPower", props, false);
		rimIntensity = FindProperty("_RimIntensity", props, false);

        meshOn = FindProperty("_MeshOn", props, false);
		scrAlpha = FindProperty("_AAAAAA", props, false);
		fogOn = FindProperty("_FogOn", props, false);
		mulColOnePass = FindProperty("_mulColOnePass", props, false);

		ztestMode = FindProperty("_ZTest", props, false);
    }

    public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
    {
        FindProperties(props);
        m_MaterialEditor = materialEditor;
        Material material = materialEditor.target as Material;

        ShaderPropertiesGUI(material);
    }

	private static class Styles
	{
		public static string advancedText = "Advanced Options";
	}

    public void ShaderPropertiesGUI(Material material)
    {
        EditorGUI.BeginChangeCheck();

        BlendModePopup();
        CullModePopup();
		SubModePopup();
		SubModePopupUV();
		SubModePopupFresnel();

		EditorGUILayout.Space();
        m_MaterialEditor.ColorProperty(albedoColor, "Color");
		m_MaterialEditor.SetDefaultGUIWidths();
        m_MaterialEditor.TextureProperty(albedoMap, "Main Texture");

		bool enableDirDissove = Array.IndexOf(material.shaderKeywords, "_DIRDISSOVE") != -1;
		bool enableEdge = Array.IndexOf(material.shaderKeywords, "_USE_XEDGE") != -1;
		bool endbleMask = Array.IndexOf(material.shaderKeywords, "_MASK_ON") != -1;
		subModeF = (FeatureType)material.GetFloat("_SubMode");
		switch(subModeF)
		{
			case FeatureType.None:
				hasMask = false;
				hasTwist = false;
				hasDissove = false;
				enableDirDissove = false;
				enableEdge = false;
				endbleMask = false;
                material.SetTexture("_MaskTex", null);
                material.SetTexture("_TwistTex", null);
                material.SetTexture("_DissoveTex", null);
                break;
			case FeatureType.Mask:
				m_MaterialEditor.TextureProperty(maskTex, "Mask Texture");
				hasMask = true;
				hasTwist = false;
				hasDissove = false;
				enableDirDissove = false;
				enableEdge = false;
				endbleMask = false;
                material.SetTexture("_TwistTex", null);
                material.SetTexture("_DissoveTex", null);
                break;
			case FeatureType.Twist:
				m_MaterialEditor.TextureProperty(twistTex, "Twist Texture");
                m_MaterialEditor.RangeProperty(twistScaleX, "Twist Scale X");
				m_MaterialEditor.RangeProperty(twistScale, "Twist Scale Y");
                material.SetTexture("_DissoveTex", null);
				hasMask = false;
				hasTwist = true;
				hasDissove = false;
				enableDirDissove = false;
				enableEdge = false;
				endbleMask = EditorGUILayout.ToggleLeft("MasK Enable", endbleMask);
				if(endbleMask)
				{
					m_MaterialEditor.TextureProperty(maskTex, "Mask Texture");
				}else
                {
                    material.SetTexture("_MaskTex", null);
                }
				break;
			case FeatureType.Dissove:
                material.SetTexture("_TwistTex", null);
				hasMask = false;
				hasTwist = false;
				hasDissove = true;
				m_MaterialEditor.TextureProperty(dissoveTex, "Dissove Texture");
				m_MaterialEditor.RangeProperty(edgeThreshold, "Edge Threshold");
				m_MaterialEditor.VectorProperty(meltPlane, "Melt Plane");
				enableDirDissove = EditorGUILayout.ToggleLeft("Dir Dissove", enableDirDissove);
				enableEdge = EditorGUILayout.ToggleLeft("Edge Dissove", enableEdge);
				if(enableEdge)
				{
					m_MaterialEditor.ColorProperty(edgeColor, "Edge Color");
				}
				endbleMask = EditorGUILayout.ToggleLeft("MasK Enable", endbleMask);
				if(endbleMask)
				{
					m_MaterialEditor.TextureProperty(maskTex, "Mask Texture");
				}else
                {
                    material.SetTexture("_MaskTex", null);
                }
				break;
		}

		switch((FeatureTypeUV)material.GetFloat("_SubModeUV"))
		{
			case FeatureTypeUV.None:
				hasUVScroll = false;
				hasUVSequence = false;
				break;
			case FeatureTypeUV.UVScroll:
				hasUVScroll = true;
				hasUVSequence = false;
				break;
			case FeatureTypeUV.UVSequence:
				hasUVScroll = false;
				hasUVSequence = true;
				m_MaterialEditor.FloatProperty(uvSequenceRows, "UV Sequence Rows");
				m_MaterialEditor.FloatProperty(uvSequenceColumns, "UV Sequence Columns");
				m_MaterialEditor.FloatProperty(uvSequenceSpeed, "UV Sequence Speed");
				break;
		}
		if(hasUVScroll)
		{
			m_MaterialEditor.VectorProperty(uvScrollSpeed, "UV Mask Scroll Speed(XY)");
			m_MaterialEditor.VectorProperty(uvScrollMTSpeed, "UV MT Scroll Speed(MainTex:XY,Twist:ZW)");
		}

		switch((FeatureTypeFresnel)material.GetFloat("_SubModeFresnel"))
		{
			case FeatureTypeFresnel.None:
				hasFresnel = false;
				break;
			case FeatureTypeFresnel.Fresnel:
				hasFresnel = true;
				m_MaterialEditor.ShaderProperty(reverseFresnel, "Reverse Fresnel");
				m_MaterialEditor.ColorProperty(rimColor, "Rim Color");
				m_MaterialEditor.RangeProperty(rimPower, "Rim Power");
				m_MaterialEditor.FloatProperty(rimIntensity, "Rim Intensity");
				break;
		}

        EditorGUILayout.Space();
        GUILayout.Label(Styles.advancedText, EditorStyles.boldLabel);
        m_MaterialEditor.ShaderProperty(meshOn, "Particle On");
		m_MaterialEditor.ShaderProperty(scrAlpha, "ScrAlpha");
		m_MaterialEditor.RangeProperty(mulColOnePass, "MulColor OnePassRoute");

        bool enableFog = Array.IndexOf(material.shaderKeywords, "_Fog_ON") != -1;
        enableFog = EditorGUILayout.Toggle("Fog On", enableFog);

        if (EditorGUI.EndChangeCheck())
        {
            SetupMaterialWithBlendMode(material, (BlendMode)material.GetFloat("_Mode"));
            SetupMaterialWithCullMode(material, (CullMode)material.GetFloat("_CullMode"));
			SetKeyword(material, "_MASK", hasMask);
			SetKeyword(material, "_TWIST", hasTwist);
			SetKeyword(material, "ENABLE_DISSOLVE", hasDissove);

			SetKeyword(material, "_UVSCROLL", hasUVScroll);
			SetKeyword(material, "_UVSEQUENCE", hasUVSequence);

			SetKeyword(material, "_FRESNEL", hasFresnel);

			SetKeyword(material, "_DIRDISSOVE", enableDirDissove);
			SetKeyword(material, "_USE_XEDGE", enableEdge);
			SetKeyword(material, "_MASK_ON", endbleMask);

            SetKeyword(material, "_Fog_ON", enableFog);
        }
        
		m_MaterialEditor.RenderQueueField();
		//m_MaterialEditor.EnableInstancingField();
		//m_MaterialEditor.DoubleSidedGIField();
    }

    static void SetKeyword(Material m, string keyword, bool state)
    {
        if (state)
            m.EnableKeyword(keyword);
        else
            m.DisableKeyword(keyword);
    }

    void BlendModePopup()
    {
        EditorGUI.showMixedValue = blendMode.hasMixedValue;
        var mode = (BlendMode)blendMode.floatValue;

        EditorGUI.BeginChangeCheck();
        mode = (BlendMode)EditorGUILayout.Popup("Rendering Mode", (int)mode, blendNames);

        if (EditorGUI.EndChangeCheck())
        {
            m_MaterialEditor.RegisterPropertyChangeUndo("Rendering Mode");
            blendMode.floatValue = (float)mode;

        }

        EditorGUI.showMixedValue = false;
    }

    void CullModePopup()
    {
        EditorGUI.showMixedValue = cullMode.hasMixedValue;
        var cull = (CullMode)cullMode.floatValue;

        EditorGUI.BeginChangeCheck();
        cull = (CullMode)EditorGUILayout.Popup("Cull Mode", (int)cull, cullModeNames);
        if (EditorGUI.EndChangeCheck())
        {
            m_MaterialEditor.RegisterPropertyChangeUndo("Cull Mode");
            cullMode.floatValue = (float)cull;
        }
        EditorGUI.showMixedValue = false;
    }

	void SubModePopup()
	{
		EditorGUI.showMixedValue = featureType.hasMixedValue;
		var submode = (FeatureType)featureType.floatValue;

		EditorGUI.BeginChangeCheck();
		submode = (FeatureType)EditorGUILayout.Popup("Sub Mode", (int)submode, featureTypeNames);
		if(EditorGUI.EndChangeCheck())
		{
			m_MaterialEditor.RegisterPropertyChangeUndo("Sub Mode");
			featureType.floatValue = (float)submode;
		}
		EditorGUI.showMixedValue = false;
	}

	void SubModePopupUV()
	{
		EditorGUI.showMixedValue = featureTypeUV.hasMixedValue;
		var submodeUV = (FeatureTypeUV)featureTypeUV.floatValue;

		EditorGUI.BeginChangeCheck();
		submodeUV = (FeatureTypeUV)EditorGUILayout.Popup("Sub Mode UV", (int)submodeUV, featureTypeUVNames);
		if(EditorGUI.EndChangeCheck())
		{
			m_MaterialEditor.RegisterPropertyChangeUndo("Sub Mode UV");
			featureTypeUV.floatValue = (float)submodeUV;
		}
		EditorGUI.showMixedValue = false;
	}

	void SubModePopupFresnel()
	{
		EditorGUI.showMixedValue = featureTypeFresnel.hasMixedValue;
		var submodeFresnel = (FeatureTypeFresnel)featureTypeFresnel.floatValue;

		EditorGUI.BeginChangeCheck();
		submodeFresnel = (FeatureTypeFresnel)EditorGUILayout.Popup("Sub Mode Fresnel", (int)submodeFresnel, featureTypeFresnelNames);
		if(EditorGUI.EndChangeCheck())
		{
			m_MaterialEditor.RegisterPropertyChangeUndo("Sub Mode Fresnel");
			featureTypeFresnel.floatValue = (float)submodeFresnel;
		}
		EditorGUI.showMixedValue = false;

	}
	
    void ZTestModePopup()
    {
        EditorGUI.showMixedValue = ztestMode.hasMixedValue;
        var mode = (CompareFunction)ztestMode.floatValue;

        EditorGUI.BeginChangeCheck();
        mode = (CompareFunction)EditorGUILayout.EnumPopup("ZTest Mode", mode);

        if (EditorGUI.EndChangeCheck())
        {
            m_MaterialEditor.RegisterPropertyChangeUndo("ZTest Mode");
            ztestMode.floatValue = (float)mode;
        }

        EditorGUI.showMixedValue = false;
    }

    public static void SetupMaterialWithBlendMode(Material material, BlendMode blendMode)
    {
        switch (blendMode)
        {
			case BlendMode.Additive:
                material.SetOverrideTag("RenderType", "");
				material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.One);
                material.SetInt("_ZWrite", 0);
                //material.renderQueue = 3000;
                break;
            case BlendMode.AlphaBlend:
                material.SetOverrideTag("RenderType", "Transparent");
                material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                material.SetInt("_ZWrite", 0);
                //material.renderQueue = 3000;
                break;
        }
    }

    void SetupMaterialWithCullMode(Material material, CullMode cullMode)
    {
        switch (cullMode)
        {
            case CullMode.Back: material.SetInt("_CullMode", (int)UnityEngine.Rendering.CullMode.Back); break;
            case CullMode.Front: material.SetInt("_CullMode", (int)UnityEngine.Rendering.CullMode.Front); break;
            case CullMode.Off: material.SetInt("_CullMode", (int)UnityEngine.Rendering.CullMode.Off); break;
        }
    }
		
}
