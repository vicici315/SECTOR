﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class CODMSceneTerrainGUI : ShaderGUI 
{
	MaterialProperty BaseTexture = null;
	MaterialProperty BaseNormal = null;
	MaterialProperty BumpScale = null;
	MaterialProperty BaseMetallic = null;

	MaterialProperty VColorR = null;
	MaterialProperty Albedo1 = null;
	MaterialProperty Normal1 = null;
	MaterialProperty Metallic1 = null;

	MaterialProperty VColorG = null;
	MaterialProperty Albedo2 = null;
	MaterialProperty Metallic2 = null;
    MaterialProperty Smoothness2 = null;
    MaterialProperty SmoothnessScale2 = null;
    MaterialProperty MaskLayer2 = null;

    MaterialProperty waterHeight= null;
	MaterialProperty waterTrans = null;

    MaterialProperty albedoMult = null;
    MaterialProperty smoothMult = null;
    MaterialProperty metallicMult = null;

    MaterialProperty use_g_control_wet_ON = null;
    MaterialProperty use_g_as_base = null;
    MaterialProperty HeightBlend = null;
    MaterialProperty HeightBlendThreshold = null;


    MaterialEditor m_MaterialEditor;

	bool useAlbedo1 = false;
	bool useAlbedo2 = false;
	bool useAlbedo3 = false;
	bool useHeightBlend = false;
    bool bUse_g_control_wet_ON = false;
    bool bUse_g_as_base = false;

    public void FindProperties(MaterialProperty[] props)
	{
		HeightBlend = FindProperty("_MaskBlend",props ,false);
		HeightBlendThreshold = FindProperty("_HeightScale",props,false);

		BumpScale = FindProperty ("_BumpScale", props, false);

		VColorR = FindProperty ("_VCOLOR_R_ON", props, false);
		Albedo1 = FindProperty ("_Albedo1", props, false);
		Normal1 = FindProperty ("_Normal1", props, false);
		Metallic1 = FindProperty ("_Metallic1", props, false);

		VColorG = FindProperty ("_VCOLOR_G_ON", props, false);
		Albedo2 = FindProperty ("_Albedo2", props, false);
		Metallic2 = FindProperty ("_Metallic2", props, false);
        Smoothness2 = FindProperty("_Smoothness2", props, false);
        SmoothnessScale2 = FindProperty("_SmoothnessScale2", props, false);
        MaskLayer2 = FindProperty("_MaskLayer2", props, false);

        BaseTexture = FindProperty ("_BaseTexture", props, false);
		BaseMetallic = FindProperty ("_BaseMetallic", props, false);
		BaseNormal = FindProperty ("_BaseNormal", props, false);

		waterHeight = FindProperty ("_waterHeight", props, false);
		waterTrans = FindProperty ("_waterTrans", props, false);

        albedoMult = FindProperty("_albedoMult", props, false);
        smoothMult = FindProperty("_smoothMult", props, false);
        metallicMult = FindProperty("_metallicMult", props, false);


        use_g_control_wet_ON = FindProperty("_use_g_control_wet_ON", props, false);

        use_g_as_base = FindProperty("_use_g_as_base", props, false);

    }

	public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
	{
		FindProperties (props);
		m_MaterialEditor = materialEditor;
		Material material = materialEditor.target as Material;

		ShaderPropertiesGUI(material);
	}

	public void ShaderPropertiesGUI(Material material)
	{
		EditorGUI.BeginChangeCheck ();
		{
			m_MaterialEditor.SetDefaultGUIWidths();

			if(HeightBlend != null)
			{
				m_MaterialEditor.ShaderProperty(HeightBlend, "Height Blend(Mask in Base(a)");
				if(HeightBlend.floatValue == 1)
				{	
					m_MaterialEditor.ShaderProperty(HeightBlendThreshold, "Height Threshold");
					useHeightBlend = true;
				}
				else
				{
					useHeightBlend = false;
				}
			}
			

			

			m_MaterialEditor.RangeProperty (BumpScale, "Normal Scale");

			m_MaterialEditor.ShaderProperty (VColorR, "Vertex Color R ON");
			if(VColorR.floatValue == 1)
			{
				m_MaterialEditor.TextureProperty (Albedo1, "Tex0_Albedo(VR)");
				m_MaterialEditor.TextureProperty (Normal1, "Tex0_RG(Normal), B(Smoothness)");
				m_MaterialEditor.RangeProperty (Metallic1, "Tex0_Metallic");
				useAlbedo1 = (Albedo1.textureValue != null);
			}

			m_MaterialEditor.ShaderProperty (VColorG, "Vertex Color G ON");
			if(VColorG.floatValue == 1)
			{
				m_MaterialEditor.TextureProperty (Albedo2, "Tex1_Albedo(VG)");
				m_MaterialEditor.RangeProperty (Metallic2, "Tex1_Metallic");
                m_MaterialEditor.RangeProperty(Smoothness2, "Tex1_Smoothness");
                m_MaterialEditor.RangeProperty(SmoothnessScale2, "Smoothness Scale");
				useAlbedo2 = (Albedo2.textureValue != null);
                m_MaterialEditor.ShaderProperty(MaskLayer2, "wet layer use layer1 normal");

            }

            m_MaterialEditor.ShaderProperty (BaseTexture, "Base Texture");
			m_MaterialEditor.RangeProperty (BaseMetallic, "Base Metallic");
			m_MaterialEditor.TextureProperty (BaseNormal, "Base_RG(Normal), B(Smoothness)");

			m_MaterialEditor.ShaderProperty(waterHeight, "waterHeight");
			m_MaterialEditor.ShaderProperty(waterTrans, "waterTrans");

            m_MaterialEditor.ShaderProperty(albedoMult, "albedoMult");
            m_MaterialEditor.ShaderProperty(smoothMult, "smoothMult");
            m_MaterialEditor.ShaderProperty(metallicMult, "metallicMult");


            m_MaterialEditor.ShaderProperty(use_g_control_wet_ON, "use g control wet ON");
            m_MaterialEditor.ShaderProperty(use_g_as_base, "use g as base for VeryLow");
        }
        if (use_g_as_base.floatValue == 1)
        {
            bUse_g_as_base = true;
        }
        else {
            bUse_g_as_base = false;
        }

        if (use_g_control_wet_ON.floatValue == 1)
        {
            bUse_g_control_wet_ON = true;
        }
        else
        {
            bUse_g_control_wet_ON = false;
        }

        if (EditorGUI.EndChangeCheck())
		{
			SetKeyword (material, "_ALBEDO_VERTEX_G", useAlbedo2);
			SetKeyword (material, "_ALBEDO_VERTEX_R", useAlbedo1);
			SetKeyword (material, "_ALBEDO_VERTEX_B", useAlbedo3);
			SetKeyword (material, "MASK_BLEND",useHeightBlend);

            SetKeyword(material, "_use_g_control_wet_ON", bUse_g_control_wet_ON);
            SetKeyword(material, "_use_g_as_base", bUse_g_as_base);
        }
	}

	static void SetKeyword(Material m, string keyword, bool state)
	{
		if (state)
			m.EnableKeyword (keyword);
		else
			m.DisableKeyword (keyword);
	}
}
