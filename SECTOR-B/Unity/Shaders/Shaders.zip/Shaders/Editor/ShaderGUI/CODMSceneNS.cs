﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System;

public class CODMSceneNS : ShaderGUI 
{
	MaterialProperty MainColor = null;
	MaterialProperty SpecularColor = null;
	MaterialProperty Shininess = null;
	MaterialProperty MainTexture = null;
	MaterialProperty Brigthness = null;
	MaterialProperty DefualtNormal = null;
	MaterialProperty BumpFactor = null;
	MaterialProperty Detail = null;
	MaterialProperty DetailDiffuse = null;
	MaterialProperty DetailNormal = null;
	MaterialProperty DetailUV = null;
	MaterialProperty DetailPower = null;
	MaterialProperty Reflection = null;
	MaterialProperty ReflectLevel = null;
	MaterialProperty ReflectRoughness = null;
	MaterialProperty Saturation = null;
	MaterialProperty DeteleSaturation = null;
	MaterialProperty AddSaturation = null;

	MaterialEditor m_MaterialEditor;

	bool useDefualtNormal = false;
	bool useDetailNormal = false;

	public void FindProperties(MaterialProperty[] props)
	{
		MainColor = FindProperty ("_Color", props, false);
		SpecularColor = FindProperty ("_SpecColor", props, false);
		Shininess = FindProperty ("_Gloss", props, false);
		MainTexture = FindProperty ("_MainTex", props, false);
		Brigthness = FindProperty ("_Brigthness", props, false);
		DefualtNormal = FindProperty ("_DefaultNormal", props, false);
		BumpFactor = FindProperty ("_BumpFactor", props, false);
		Detail = FindProperty ("_DETAIL_ON", props, false);
		DetailDiffuse = FindProperty ("_DetailDiffuse", props, false);
		DetailNormal = FindProperty ("_DetailNormal", props, false);
		DetailUV = FindProperty ("_DetailTextureUV", props, false);
		DetailPower = FindProperty ("_DetailNormalPower", props, false);
		Reflection = FindProperty ("_REFL_ON", props, false);
		ReflectLevel = FindProperty ("_ReflectLevel", props, false);
		ReflectRoughness = FindProperty ("_Roughness", props, false);
		Saturation = FindProperty ("_Satu", props, false);
		DeteleSaturation = FindProperty ("_SaturationD", props, false);
		AddSaturation = FindProperty ("_SaturationA", props, false);
	}

	public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
	{
		FindProperties (props);
		m_MaterialEditor = materialEditor;
		Material material = materialEditor.target as Material;

		ShaderPropertiesGUI(material);
		materialEditor.EnableInstancingField();
	}

//    [MenuItem("Assets/RefreshAllMat")]
//    public static void RefreshAllMat()
//    {
//        var shader = Shader.Find("CODM/Scene/Realtime_Diffuse_NS");
//        var guids = AssetDatabase.FindAssets("t:Material", new string[] { "Assets/Scenes" });
//        if(guids == null)
//        {
//            return;
//        }
//        using (var scopedProgressBar = new ScopedProgressBar())
//        {
//            for (int i = 0; i < guids.Length; i++)
//            {
//                var guid = guids[i];
//                var prefab = AssetDatabase.GUIDToAssetPath(guid);
//                float progress = (i + 1) / (float)guids.Length;
//                string title = string.Format("RefreshAllMat {0}/{1}", (i + 1), guids.Length);
//                ScopedProgressBar.Display(title, prefab, progress);
//                var mat = AssetDatabase.LoadAssetAtPath<Material>(prefab);
//                if(mat && mat.shader == shader)
//                {
//                    bool useDefualtNormal = (mat.GetTexture("_DefaultNormal") != null);
//                    SetKeyword(mat, "_DEFAULTNORMAL", useDefualtNormal);    
//                    float v = mat.GetFloat("_DETAIL_ON");
//                    if(v == 1)
//                    {
//                        bool useDetailNormal = (mat.GetTexture("_DetailNormal") != null);
//                        SetKeyword(mat, "_DETAILNORMAL", useDetailNormal);
//                    }                  
//                }
//            }
//            AssetDatabase.SaveAssets();
//        }
//    }

	public void ShaderPropertiesGUI(Material material)
	{
		EditorGUI.BeginChangeCheck ();
		{
			m_MaterialEditor.SetDefaultGUIWidths();
			m_MaterialEditor.ColorProperty (MainColor, "Main Color");
			m_MaterialEditor.ColorProperty (SpecularColor, "Specular Color");
			m_MaterialEditor.RangeProperty (Shininess, "Shininess");
			m_MaterialEditor.TextureProperty (MainTexture, "Main Texture");
			m_MaterialEditor.RangeProperty (Brigthness, "Brigthness");
			m_MaterialEditor.TextureProperty (DefualtNormal, "Normal Specular");
			useDefualtNormal = (DefualtNormal.textureValue != null);
			m_MaterialEditor.RangeProperty (BumpFactor, "Bump Scale");
			m_MaterialEditor.ShaderProperty (Detail, "Detail is ON or OFF");
			if(Detail.floatValue == 1)
			{
				m_MaterialEditor.TextureProperty (DetailDiffuse, "Detail Diffuse");
				m_MaterialEditor.TextureProperty (DetailNormal, "Detail Normal");
				useDetailNormal = (DetailNormal.textureValue != null);
				m_MaterialEditor.FloatProperty (DetailUV, "Detail Texture UV");
				m_MaterialEditor.RangeProperty (DetailPower, "Detail Normal Power");
			}
			m_MaterialEditor.ShaderProperty (Reflection, "Reflection is ON or OFF");
			if (Reflection.floatValue == 1) 
			{
				m_MaterialEditor.RangeProperty (ReflectLevel, "Reflection Level");
				m_MaterialEditor.RangeProperty (ReflectRoughness, "Reflection Roughness");
			}
			m_MaterialEditor.ShaderProperty (Saturation, "Saturation is ON or OFF");
			if (Saturation.floatValue == 1)
			{
				m_MaterialEditor.RangeProperty (DeteleSaturation, "Delete Saturation");
				m_MaterialEditor.RangeProperty (AddSaturation, "Add Saturation");
			}
		}


		if (EditorGUI.EndChangeCheck())
		{
			SetKeyword (material, "_DEFAULTNORMAL", useDefualtNormal);
			SetKeyword (material, "_DETAILNORMAL", useDetailNormal);
		}
	}

	static void SetKeyword(Material m, string keyword, bool state)
	{
		if (state)
			m.EnableKeyword (keyword);
		else
			m.DisableKeyword (keyword);
	}
}
