﻿using UnityEngine;
using UnityEditor;

public class CODMLegacy3PStrokeGUI : CODMLegacy3PGUI
{
    private MaterialProperty rimColor = null;
    private MaterialProperty rimThreshold = null;
    private MaterialProperty rimFactor = null;
    private MaterialProperty brightness = null;


    public override void FindProperties(MaterialProperty[] props)
    {
        base.FindProperties(props);
        rimColor = FindProperty("_RimColor", props, false);
        rimThreshold = FindProperty("_RimThreshold", props, false);
        rimFactor = FindProperty("_RimFactor", props, false);
        brightness = FindProperty("_Brightness", props, false);
    }

    public override void ShaderPropertiesGUI(Material material)
    {
        base.ShaderPropertiesGUI(material);
        m_MaterialEditor.ColorProperty(rimColor, "Rim Color");
        m_MaterialEditor.RangeProperty(rimThreshold, "Rim Threshold");
        m_MaterialEditor.FloatProperty(rimFactor, "Rim Factor");
        m_MaterialEditor.FloatProperty(brightness, "Brightness");
    }

}
