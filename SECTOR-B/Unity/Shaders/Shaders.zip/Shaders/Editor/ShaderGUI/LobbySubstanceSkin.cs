﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class LobbySubstanceSkin : ShaderGUI {
	
	MaterialProperty albedoMap = null;
	MaterialProperty albedoColor = null;
	
	MaterialProperty ambientColor = null;
	
	MaterialProperty metallicMap = null;
	MaterialProperty metallic = null;
	MaterialProperty smoothness = null;
	MaterialProperty rimLevel = null;
	MaterialProperty bumpScale = null;
	MaterialProperty bumpMap = null;
	MaterialProperty emissionColor = null;
	MaterialProperty emissionMap = null;
	
	bool useMetallicMap = false;
	bool useBumpMap = false;
	MaterialEditor m_MaterialEditor;
	
	public enum BlendMode { Opaque, AlphaBlend }
	MaterialProperty blendMode = null;
	private string[] blendNames = new string[]{ "Opaque", "Alpha Blend" };
	
	public enum CullMode { Off, Front, Back }
	MaterialProperty cullMode = null;
	private string[] cullModeNames = new string[]{ "Double Side", "Cull Front", "Cull Back (Default)" };
	
	public void FindProperties (MaterialProperty[] props)
	{
		albedoMap = FindProperty ("_MainTex", props);
		albedoColor = FindProperty ("_Color", props);
		
		ambientColor = FindProperty ("_AmbientColor", props);
		
		metallicMap = FindProperty ("_MetallicGlossMap", props, false);
		metallic = FindProperty ("_Metallic", props, false);
		smoothness = FindProperty ("_Glossiness", props);
		rimLevel = FindProperty ("_RimLevel", props);
		bumpScale = FindProperty ("_BumpScale", props);
		bumpMap = FindProperty ("_BumpMap", props);
		emissionColor = FindProperty ("_EmissionColor", props);
		emissionMap = FindProperty ("_EmissionMap", props);
		
		useMetallicMap = metallicMap != null;
		useBumpMap = bumpMap != null;
		
		blendMode = FindProperty ("_Mode", props);
		cullMode = FindProperty ("_CullMode", props);
	}
	
	public override void OnGUI (MaterialEditor materialEditor, MaterialProperty[] props)
	{
		FindProperties (props);
		m_MaterialEditor = materialEditor;
		Material material = materialEditor.target as Material;
		
		ShaderPropertiesGUI (material);
	}
	
	public void ShaderPropertiesGUI (Material material)
	{
		EditorGUI.BeginChangeCheck();
		{
			BlendModePopup();
			CullModePopup();
			m_MaterialEditor.SetDefaultGUIWidths();
			m_MaterialEditor.ColorProperty(albedoColor, "Color");
			
			m_MaterialEditor.ColorProperty(ambientColor, "Ambient Color");
			
			m_MaterialEditor.TextureProperty(albedoMap, "Main Tex");
			m_MaterialEditor.TextureProperty(metallicMap, "Metallic Map: R(Metallic) G(Smoothness) B(Occlusion)");
			m_MaterialEditor.RangeProperty(metallic, "Metallic");
			m_MaterialEditor.RangeProperty(smoothness, "Smoothness");
			m_MaterialEditor.RangeProperty(rimLevel, "Rim Level");
			m_MaterialEditor.TextureProperty(bumpMap, "Normal");
			m_MaterialEditor.FloatProperty(bumpScale, "Normal Scale");
			
			m_MaterialEditor.ColorProperty(emissionColor, "Emission Color");
			float brightness = emissionColor.colorValue.maxColorComponent;
			bool hadEmissionTexture = emissionMap.textureValue != null;
			m_MaterialEditor.TextureProperty(emissionMap, "Emission");
			if (emissionMap.textureValue != null && !hadEmissionTexture && brightness <= 0f) emissionColor.colorValue = Color.white;
		}
		
		if (EditorGUI.EndChangeCheck())
		{
			if (useMetallicMap) SetKeyword(material, "_METALLICGLOSSMAP", material.GetTexture ("_MetallicGlossMap"));
			if (useBumpMap) SetKeyword(material, "_NORMALMAP", material.GetTexture ("_BumpMap"));
			
			Color emissionColor = material.GetColor("_EmissionColor");
			bool emissionEnable = emissionColor.maxColorComponent > (0.1f / 255.0f);
			SetKeyword(material, "_EMISSION", emissionEnable);
			
			SetupMaterialWithBlendMode(material, (BlendMode)material.GetFloat("_Mode"));
			SetupMaterialWithCullMode(material, (CullMode)material.GetFloat("_CullMode"));
		}
	}
	
	static void SetKeyword(Material m, string keyword, bool state)
	{
		if (state) m.EnableKeyword (keyword);
		else m.DisableKeyword (keyword);
	}
	
	void BlendModePopup()
	{
		EditorGUI.showMixedValue = blendMode.hasMixedValue;
		var mode = (BlendMode)blendMode.floatValue;
		
		EditorGUI.BeginChangeCheck();
		mode = (BlendMode)EditorGUILayout.Popup("Rendering Mode", (int)mode, blendNames);
		
		if (EditorGUI.EndChangeCheck())
		{
			m_MaterialEditor.RegisterPropertyChangeUndo("Rendering Mode");
			blendMode.floatValue = (float)mode;
		}
		
		EditorGUI.showMixedValue = false;
	}
	
	void CullModePopup()
	{
		EditorGUI.showMixedValue = cullMode.hasMixedValue;
		var cull = (CullMode)cullMode.floatValue;
		
		EditorGUI.BeginChangeCheck();
		cull = (CullMode)EditorGUILayout.Popup("Cull Mode", (int)cull, cullModeNames);
		if (EditorGUI.EndChangeCheck())
		{
			m_MaterialEditor.RegisterPropertyChangeUndo("Cull Mode");
			cullMode.floatValue = (float)cull;
			Debug.Log(cull);
		}
		EditorGUI.showMixedValue = false;
	}
	
	public static void SetupMaterialWithBlendMode(Material material, BlendMode blendMode)
	{
		switch (blendMode)
		{
			case BlendMode.Opaque:
				material.SetOverrideTag("RenderType", "");
				material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
				material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.Zero);
				material.SetInt("_ZWrite", 1);
				material.DisableKeyword("_ALPHABLEND_ON");
				material.renderQueue = -1;
				break;
			case BlendMode.AlphaBlend:
				material.SetOverrideTag("RenderType", "Transparent");
				material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
				material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
				material.SetInt("_ZWrite", 0);
				material.EnableKeyword("_ALPHABLEND_ON");
				material.renderQueue = 3000;
				break;
		}
	}
	
	public static void SetupMaterialWithCullMode(Material material, CullMode cullMode)
	{
		switch (cullMode)
		{
			case CullMode.Back:material.SetInt("_CullMode", (int)UnityEngine.Rendering.CullMode.Back);break;
			case CullMode.Front:material.SetInt("_CullMode", (int)UnityEngine.Rendering.CullMode.Front);break;	
			case CullMode.Off:material.SetInt("_CullMode", (int)UnityEngine.Rendering.CullMode.Off);break;	
		}
	}
}
