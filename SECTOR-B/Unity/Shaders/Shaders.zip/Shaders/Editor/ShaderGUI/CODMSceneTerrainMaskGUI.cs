﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class CODMSceneTerrainMaskGUI : ShaderGUI 
{
	MaterialEditor m_MaterialEditor;

	MaterialProperty SpecBaseColor = null;
	MaterialProperty BaseTexture = null;
	MaterialProperty BaseNormal = null;
	MaterialProperty TerrainMask = null;

	MaterialProperty ColorTMaskR = null;
	MaterialProperty AlbedoTMaskR = null;
	MaterialProperty NormalTMaskR = null;
	MaterialProperty normalBlendMode = null;
	MaterialProperty SmoothnessTMaskR = null;
	MaterialProperty ReflectTMaskR = null;

	MaterialProperty ColorTMaskG = null;
	MaterialProperty AlbedoTMaskG = null;
	MaterialProperty NormalTMaskG = null;
	MaterialProperty normalBlendModeG = null;
	MaterialProperty SmoothnessTMaskG = null;
	MaterialProperty ReflectTMaskG = null;

	public enum NormalBlendMode {Lerp, Overlay}

	private string[] normalBlendname = new string[]{"Lerp", "Overlay"};

	bool useBaseTexture = false;
	bool useTerrainMask = false;
	bool useAlbedoTMaskR = false;
	bool useAlbedoTMaskG = false;

	public void FindProperties(MaterialProperty[] props)
	{
		SpecBaseColor = FindProperty ("_SpecBaseColor", props, false);
		BaseTexture = FindProperty ("_BaseTexture", props, false);
		BaseNormal = FindProperty ("_BaseNormal", props, false);
		TerrainMask = FindProperty ("_TerrainMask", props, false);

		ColorTMaskR = FindProperty ("_ColorTMaskR", props, false);
		AlbedoTMaskR = FindProperty ("_AlbedoTMaskR", props, false);
		NormalTMaskR = FindProperty ("_NormalTMaskR", props, false);
		normalBlendMode = FindProperty ("_NormalBlendMode", props, false);
		SmoothnessTMaskR = FindProperty ("_SmoothnessTMaskR", props, false);
		ReflectTMaskR = FindProperty ("_ReflectTMaskR", props, false);

		ColorTMaskG = FindProperty ("_ColorTMaskG", props, false);
		AlbedoTMaskG = FindProperty ("_AlbedoTMaskG", props, false);
		NormalTMaskG = FindProperty ("_NormalTMaskG", props, false);
		normalBlendModeG = FindProperty ("_NormalBlendModeG", props, false);
		SmoothnessTMaskG = FindProperty ("_SmoothnessTMaskG", props, false);
		ReflectTMaskG = FindProperty ("_ReflectTMaskG", props, false);
	}

	public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
	{
		FindProperties (props);
		m_MaterialEditor = materialEditor;
		Material material = materialEditor.target as Material;

		ShaderPropertiesGUI(material);
	}

	public void ShaderPropertiesGUI(Material material)
	{
		EditorGUI.BeginChangeCheck ();
		{
			m_MaterialEditor.SetDefaultGUIWidths();

			m_MaterialEditor.ColorProperty (SpecBaseColor, "Specular");
			m_MaterialEditor.TextureProperty (BaseTexture, "Base Texture");
			useBaseTexture = (BaseTexture.textureValue != null);
			if (useBaseTexture) 
			{
				m_MaterialEditor.TextureProperty (BaseNormal, "Base Normal");
			}
			m_MaterialEditor.TextureProperty (TerrainMask, "Terrain Mask");
			useTerrainMask = (TerrainMask.textureValue != null);
			if (useTerrainMask) 
			{
				m_MaterialEditor.TextureProperty (AlbedoTMaskR, "Albedo TMask R");
				useAlbedoTMaskR = (AlbedoTMaskR.textureValue != null);
				if (!useAlbedoTMaskR) 
				{
					m_MaterialEditor.ColorProperty (ColorTMaskR, "Color TMask R");
				}
				m_MaterialEditor.TextureProperty (NormalTMaskR, "Normal TMask R");
				normalBlendFunc (normalBlendMode, "R");
				m_MaterialEditor.RangeProperty (SmoothnessTMaskR, "Smoothness TMask R");
				m_MaterialEditor.RangeProperty (ReflectTMaskR, "Reflect TMask R");
					
				m_MaterialEditor.TextureProperty (AlbedoTMaskG, "Albedo TMask G");
				useAlbedoTMaskG = (AlbedoTMaskG.textureValue != null);
				if (!useAlbedoTMaskG) 
				{
					m_MaterialEditor.ColorProperty (ColorTMaskG, "Color TMask G");
				}
				m_MaterialEditor.TextureProperty (NormalTMaskG, "Normal TMask G");
				normalBlendFunc (normalBlendModeG, "G");
				m_MaterialEditor.RangeProperty (SmoothnessTMaskG, "Smoothness TMask G");
				m_MaterialEditor.RangeProperty (ReflectTMaskG, "Reflect TMask G");
			}
		}
		if (EditorGUI.EndChangeCheck())
		{
			SetKeyword (material, "_TERRAIN_MASK", useTerrainMask);
			SetKeyword (material, "_ALBEDOTMASK_R", useAlbedoTMaskR);
			normalBlendShaderFeature(material, (NormalBlendMode)normalBlendMode.floatValue, "R", "_NormalBlendMode");

			SetKeyword (material, "_ALBEDOTMASK_G", useAlbedoTMaskG);
			normalBlendShaderFeature (material, (NormalBlendMode)normalBlendModeG.floatValue, "G", "_NormalBlendModeG");
		}
	}

	void normalBlendFunc(MaterialProperty normalBlendChannel, string nameChannel)
	{
		EditorGUI.showMixedValue = normalBlendChannel.hasMixedValue;
		int intValue = (int)normalBlendChannel.floatValue;
		var normalBlend = (NormalBlendMode)intValue;

		EditorGUI.BeginChangeCheck();
		normalBlend = (NormalBlendMode)EditorGUILayout.Popup(("Normal Blend Mode " + nameChannel), (int)normalBlend, normalBlendname);
		if (EditorGUI.EndChangeCheck())
		{
			m_MaterialEditor.RegisterPropertyChangeUndo(("Normal Blend Mode " + nameChannel));
			normalBlendChannel.floatValue = (float)normalBlend;
		}
		EditorGUI.showMixedValue = false;
	}

	public static void normalBlendShaderFeature(Material material, NormalBlendMode normalBlendMode, string channelName, string SProperName)
	{
		material.DisableKeyword(("_NORMAL_BLEDN_LERP_" + channelName));
		material.DisableKeyword(("_NORMAL_BLEDN_OVERLAY_" + channelName));

		material.SetInt(SProperName, (int)normalBlendMode);
		switch (normalBlendMode)
		{
		case NormalBlendMode.Lerp:
			material.EnableKeyword(("_NORMAL_BLEDN_LERP_" + channelName));
			break;
		case NormalBlendMode.Overlay:
			material.EnableKeyword(("_NORMAL_BLEDN_OVERLAY_" + channelName));
			break;
		}
	}

	static void SetKeyword(Material m, string keyword, bool state)
	{
		if (state)
			m.EnableKeyword (keyword);
		else
			m.DisableKeyword (keyword);
	}
}
