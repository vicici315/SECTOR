﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class CODMStandardSpecularGUI : ShaderGUI
{
    MaterialProperty albedoMap = null;
    MaterialProperty albedoColor = null;
    MaterialProperty paramMap = null;
    MaterialProperty smoothness = null;
    MaterialProperty specularMap = null;
    MaterialProperty specularColor = null;
    MaterialProperty rimLevel = null;
    MaterialProperty bumpScale = null;
    MaterialProperty bumpMap = null;
    MaterialProperty emissionColor = null;
    MaterialProperty emissionMap = null;
    MaterialProperty occlusionStrength = null;

    MaterialProperty detailMaskMap = null;
    MaterialProperty detailAlbedoMap = null;

    bool useSpecularMap = false;
    bool useParamMap = false;
    bool useDetailMap = false;
    bool useNormalMap = false;

    MaterialEditor m_MaterialEditor;

    public enum BlendMode { Opaque, AlphaBlend }
    MaterialProperty blendMode = null;
    private string[] blendNames = new string[] { "Opaque", "Alpha Blend" };

    public enum CullMode { Off, Front, Back }
    MaterialProperty cullMode = null;
    private string[] cullModeNames = new string[] { "Double Side", "Cull Front", "Cull Back (Default)" };

    public enum DetailBlendMode { None, MulX2, Mul, Add, Lerp, DesaturateBlend }
    MaterialProperty detailBlendMode = null;
    private string[] detailBlendModeNames = new string[] { "None", "MulX2", "Mul", "Add", "Lerp", "Desaturate Blend"};

    public enum SpecularHighlightOptimizeMode{ Normal, None }
    MaterialProperty spcularHighlightOptimize = null;
    private string[] specularOptimizeModeNames = new string[] { "Normal", "No SpecularHighlight"};

    public enum GlossyReflectionOptimizeMode { Normal, None }
    MaterialProperty glossyReflectionOptimize = null;
    private string[] glossyReflectionOptimizeModeNames = new string[] { "Normal", "No GlossyReflection" };

    public void FindProperties(MaterialProperty[] props)
    {
        albedoMap = FindProperty("_MainTex", props);
        albedoColor = FindProperty("_Color", props);
        paramMap = FindProperty("_ParamMap", props, false);
        smoothness = FindProperty("_Glossiness", props);
        specularMap = FindProperty("_SpecGlossMap", props);
        specularColor = FindProperty("_SpecColor", props);
        rimLevel = FindProperty("_RimLevel", props);
        bumpScale = FindProperty("_BumpScale", props);
        bumpMap = FindProperty("_BumpMap", props);
        emissionColor = FindProperty("_EmissionColor", props);
        emissionMap = FindProperty("_EmissionMap", props);

        detailMaskMap = FindProperty("_DetailMask", props);
        detailAlbedoMap = FindProperty("_DetailAlbedoMap", props);

        useSpecularMap = (specularMap != null);
        useParamMap = (paramMap != null);
        useDetailMap = (detailMaskMap != null && detailAlbedoMap != null);

        blendMode = FindProperty("_Mode", props);
        cullMode = FindProperty("_CullMode", props);
        detailBlendMode = FindProperty("_DetialBlendMode", props);

        occlusionStrength = FindProperty("_OcclusionStrength", props);

        spcularHighlightOptimize = FindProperty("_SpecularHighlights", props);
        glossyReflectionOptimize = FindProperty("_GlossyReflections", props);
    }

    public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
    {
        FindProperties(props);
        m_MaterialEditor = materialEditor;
        Material material = materialEditor.target as Material;

        ShaderPropertiesGUI(material);
    }

    public void ShaderPropertiesGUI(Material material)
    {
        EditorGUI.BeginChangeCheck();
        {
            BlendModePopup();
            CullModePopup();
            DetailBlendPopup();
            m_MaterialEditor.SetDefaultGUIWidths();
            m_MaterialEditor.ColorProperty(albedoColor, "Color");
            m_MaterialEditor.TextureProperty(albedoMap, "Main Tex");

            // ParamMap Set
            m_MaterialEditor.TextureProperty(paramMap, "Param Map: R(Specular) G(Smoothness) B(Occlusion)");
            useParamMap = (paramMap.textureValue != null);

            if (useParamMap == false)
            {
                // 不由贴图指定Metallic和Smoothness，那么通过滑竿制定
                m_MaterialEditor.RangeProperty(smoothness, "Smoothness");
            }

            m_MaterialEditor.RangeProperty(rimLevel, "Rim Level");
            m_MaterialEditor.RangeProperty(occlusionStrength, "AO Level");

            // Specular map
            // m_MaterialEditor.TextureProperty(specularMap, "Specular Map");
            //useSpecularMap = (specularMap.textureValue != null);
            useSpecularMap = useParamMap;
            if (useSpecularMap == false)
            {
                // 不由贴图指定Specular和Smoothness，那么通过滑竿制定
                m_MaterialEditor.ColorProperty(specularColor, "Specular Color");
            }

            // Normal set
            m_MaterialEditor.TextureProperty(bumpMap, "Normal");
            m_MaterialEditor.FloatProperty(bumpScale, "Normal Scale");
            useNormalMap = (bumpMap.textureValue != null);

            // Optimize
            SpecularHighlightOptimizePopup();
            GlossyReflectionOptimizePopup();

            // Detail mask & map set
            m_MaterialEditor.TextureProperty(detailMaskMap, "Detail Mask");
            m_MaterialEditor.TextureProperty(detailAlbedoMap, "Detail Map");
            useDetailMap = (detailMaskMap.textureValue != null && detailAlbedoMap.textureValue != null);

            // Emission Color Set
            m_MaterialEditor.ColorProperty(emissionColor, "Emission Color");
            float brightness = emissionColor.colorValue.maxColorComponent;
            bool hadEmissionTexture = emissionMap.textureValue != null;
            m_MaterialEditor.TextureProperty(emissionMap, "Emission");
            if (emissionMap.textureValue != null && !hadEmissionTexture && brightness <= 0f)
            {
                emissionColor.colorValue = Color.white;
            }
        }

        if (EditorGUI.EndChangeCheck())
        {
            // 根据设置Apply Shader
            SetKeyword(material, "_SPECGLOSSMAP", useSpecularMap);
            SetKeyword(material, "_NORMALMAP", useNormalMap);

            if (useDetailMap == true)
            {
                // 使用DetailMode，那么开启正确的Detail分支
                SetupMaterialDetailBlendMode(material, (DetailBlendMode)detailBlendMode.floatValue);
            }
            else
            {
                // 否则关闭Detail分支
                SetupMaterialDetailBlendMode(material, DetailBlendMode.None);
            }

            Color emissionColor = material.GetColor("_EmissionColor");
            bool emissionEnable = emissionColor.maxColorComponent > (0.1f / 255.0f);
            SetKeyword(material, "_EMISSION", emissionEnable);

            SetupMaterialWithBlendMode(material, (BlendMode)material.GetFloat("_Mode"));
            SetupMaterialWithCullMode(material, (CullMode)material.GetFloat("_CullMode"));

            // 优化分支
            SetKeyword(material, "_SPECULARHIGHLIGHTS_OFF", (SpecularHighlightOptimizeMode)spcularHighlightOptimize.floatValue == SpecularHighlightOptimizeMode.None);
            SetKeyword(material, "_GLOSSYREFLECTIONS_OFF", (GlossyReflectionOptimizeMode)glossyReflectionOptimize.floatValue == GlossyReflectionOptimizeMode.None);
        }
    }

    static void SetKeyword(Material m, string keyword, bool state)
    {
        if (state)
            m.EnableKeyword(keyword);
        else
            m.DisableKeyword(keyword);
    }

    void BlendModePopup()
    {
        EditorGUI.showMixedValue = blendMode.hasMixedValue;
        var mode = (BlendMode)blendMode.floatValue;

        EditorGUI.BeginChangeCheck();
        mode = (BlendMode)EditorGUILayout.Popup("Rendering Mode", (int)mode, blendNames);

        if (EditorGUI.EndChangeCheck())
        {
            m_MaterialEditor.RegisterPropertyChangeUndo("Rendering Mode");
            blendMode.floatValue = (float)mode;

        }

        EditorGUI.showMixedValue = false;
    }

    void CullModePopup()
    {
        EditorGUI.showMixedValue = cullMode.hasMixedValue;
        var cull = (CullMode)cullMode.floatValue;

        EditorGUI.BeginChangeCheck();
        cull = (CullMode)EditorGUILayout.Popup("Cull Mode", (int)cull, cullModeNames);
        if (EditorGUI.EndChangeCheck())
        {
            m_MaterialEditor.RegisterPropertyChangeUndo("Cull Mode");
            cullMode.floatValue = (float)cull;
            Debug.Log(cull);
        }
        EditorGUI.showMixedValue = false;
    }

    void DetailBlendPopup()
    {
        EditorGUI.showMixedValue = detailBlendMode.hasMixedValue;
        var detailBlend = (DetailBlendMode)detailBlendMode.floatValue;

        EditorGUI.BeginChangeCheck();
        detailBlend = (DetailBlendMode)EditorGUILayout.Popup("Detail Blend Mode", (int)detailBlend, detailBlendModeNames);
        if (EditorGUI.EndChangeCheck())
        {
            m_MaterialEditor.RegisterPropertyChangeUndo("Detail Blend Mode");
            detailBlendMode.floatValue = (float)detailBlend;
            Debug.Log(detailBlend);
        }
        EditorGUI.showMixedValue = false;
    }

    void SpecularHighlightOptimizePopup()
    {
        EditorGUI.showMixedValue = spcularHighlightOptimize.hasMixedValue;
        var specOptimizeMode = (SpecularHighlightOptimizeMode)spcularHighlightOptimize.floatValue;

        EditorGUI.BeginChangeCheck();
        specOptimizeMode = (SpecularHighlightOptimizeMode)EditorGUILayout.Popup("Specular Optimize", (int)specOptimizeMode, specularOptimizeModeNames);
        if (EditorGUI.EndChangeCheck())
        {
            m_MaterialEditor.RegisterPropertyChangeUndo("Specular Optimize");
            spcularHighlightOptimize.floatValue = (float)specOptimizeMode;
            Debug.Log(specOptimizeMode);
        }
        EditorGUI.showMixedValue = false;
    }

    void GlossyReflectionOptimizePopup()
    {
        EditorGUI.showMixedValue = glossyReflectionOptimize.hasMixedValue;
        var glossyReflectionOptimizeMode = (GlossyReflectionOptimizeMode)glossyReflectionOptimize.floatValue;

        EditorGUI.BeginChangeCheck();
        glossyReflectionOptimizeMode = (GlossyReflectionOptimizeMode)EditorGUILayout.Popup("Glossy Reflection Optimize", (int)glossyReflectionOptimizeMode, glossyReflectionOptimizeModeNames);
        if (EditorGUI.EndChangeCheck())
        {
            m_MaterialEditor.RegisterPropertyChangeUndo("Glossy Reflection Optimize");
            glossyReflectionOptimize.floatValue = (float)glossyReflectionOptimizeMode;
            Debug.Log(glossyReflectionOptimizeMode);
        }
        EditorGUI.showMixedValue = false;
    }

    public static void SetupMaterialWithBlendMode(Material material, BlendMode blendMode)
    {
        switch (blendMode)
        {
            case BlendMode.Opaque:
                material.SetOverrideTag("RenderType", "");
                material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
                material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.Zero);
                material.SetInt("_ZWrite", 1);
                material.DisableKeyword("_ALPHABLEND_ON");
                material.renderQueue = -1;
                break;
            case BlendMode.AlphaBlend:
                material.SetOverrideTag("RenderType", "Transparent");
                material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                material.SetInt("_ZWrite", 0);
                material.EnableKeyword("_ALPHABLEND_ON");
                material.renderQueue = 3000;
                break;
        }
    }

    public static void SetupMaterialWithCullMode(Material material, CullMode cullMode)
    {
        switch (cullMode)
        {
            case CullMode.Back: material.SetInt("_CullMode", (int)UnityEngine.Rendering.CullMode.Back); break;
            case CullMode.Front: material.SetInt("_CullMode", (int)UnityEngine.Rendering.CullMode.Front); break;
            case CullMode.Off: material.SetInt("_CullMode", (int)UnityEngine.Rendering.CullMode.Off); break;
        }
    }

    public static void SetupMaterialDetailBlendMode(Material material, DetailBlendMode detialBlendMode)
    {
        material.DisableKeyword("_DETAIL_MULX2");
        material.DisableKeyword("_DETAIL_ADD");
        material.DisableKeyword("_DETAIL_MUL");
        material.DisableKeyword("_DETAIL_LERP");
        material.DisableKeyword("_DETAIL_DESATURATE");

        if (detialBlendMode == DetailBlendMode.None)
        {
            // 没有Detail Mode
            return;
        }

        // 下面并不影响Shader流程，但是却能够记录Shader分支变量进入Material中
        material.SetInt("_DetialBlendMode", (int)detialBlendMode);
        switch (detialBlendMode)
        {
            case DetailBlendMode.Add:
                material.EnableKeyword("_DETAIL_ADD");
                break;
            case DetailBlendMode.Mul:
                material.EnableKeyword("_DETAIL_MUL");
                break;
            case DetailBlendMode.MulX2:
                material.EnableKeyword("_DETAIL_MULX2");
                break;
            case DetailBlendMode.Lerp:
                material.EnableKeyword("_DETAIL_LERP");
                break;
            case DetailBlendMode.DesaturateBlend:
                material.EnableKeyword("_DETAIL_DESATURATE");
                break;
        }
    }
}
