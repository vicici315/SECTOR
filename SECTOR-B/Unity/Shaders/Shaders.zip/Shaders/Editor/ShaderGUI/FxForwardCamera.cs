﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class FxForwardCamera : ShaderGUI
{
    private MaterialEditor m_MaterialEditor;

    private MaterialProperty _BlendMode = null;
    private MaterialProperty _SrcBlend = null;
    private MaterialProperty _DstBlend = null;

    public enum BlendMode { Add, AlphaBlend }
    private string[] blendNames = new string[] { "Add", "Alpha Blend" };

    private void FindProperties(MaterialEditor materialEditor, MaterialProperty[] props)
    {
        m_MaterialEditor = materialEditor;
        _BlendMode = FindProperty("_BlendMode", props, false);
        _SrcBlend = FindProperty("_SrcBlend", props, false);
        _DstBlend = FindProperty("_DstBlend", props, false);
    }

    private void OnBlendModeGUI()
    {
        EditorGUI.BeginChangeCheck();

        var mode = (BlendMode)_BlendMode.floatValue;
        mode = (BlendMode)EditorGUILayout.Popup("Blend Mode", (int)mode, blendNames);

        if (EditorGUI.EndChangeCheck())
        {
            _BlendMode.floatValue = (float)mode;

            switch (mode)
            {
                case BlendMode.Add:
                    _SrcBlend.floatValue = (float)UnityEngine.Rendering.BlendMode.SrcAlpha;
                    _DstBlend.floatValue = (float)UnityEngine.Rendering.BlendMode.One;
                    break;
                case BlendMode.AlphaBlend:
                    _SrcBlend.floatValue = (float)UnityEngine.Rendering.BlendMode.SrcAlpha;
                    _DstBlend.floatValue = (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha;
                    break;
            }
        }
    }

    public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
    {
        FindProperties(materialEditor, props);
        OnBlendModeGUI();

        base.OnGUI(materialEditor, props);
    }
}
