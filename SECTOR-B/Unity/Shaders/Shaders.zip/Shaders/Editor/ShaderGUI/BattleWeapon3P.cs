﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class BattleWeapon3P : ShaderGUI
{
    MaterialProperty albedoMap = null;

    MaterialProperty detailMaskMap = null;
    MaterialProperty detailAlbedoMap = null;
    bool useDetailMap = false;

    MaterialEditor m_MaterialEditor;

    public enum DetailBlendMode { None, MulX2, Mul, Add, Lerp, DesaturateBlend }
    MaterialProperty detailBlendMode = null;
    private string[] detailBlendModeNames = new string[] { "None", "MulX2", "Mul", "Add", "Lerp", "Desaturate Blend"};


    public void FindProperties(MaterialProperty[] props)
    {
        albedoMap = FindProperty("_MainTex", props);

        detailMaskMap = FindProperty("_DetailMask", props);
        detailAlbedoMap = FindProperty("_DetailAlbedoMap", props);

        detailBlendMode = FindProperty("_DetialBlendMode", props);
    }

    public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] props)
    {
        FindProperties(props);
        m_MaterialEditor = materialEditor;
        Material material = materialEditor.target as Material;

        ShaderPropertiesGUI(material);
    }

    public void ShaderPropertiesGUI(Material material)
    {
        EditorGUI.BeginChangeCheck();
        {
            DetailBlendPopup();
            m_MaterialEditor.SetDefaultGUIWidths();
            m_MaterialEditor.TextureProperty(albedoMap, "Main Tex");
            

            // Detail mask & map set
            m_MaterialEditor.TextureProperty(detailMaskMap, "Detail Mask");
            m_MaterialEditor.TextureProperty(detailAlbedoMap, "Detail Map");
            useDetailMap = (detailMaskMap.textureValue != null && detailAlbedoMap.textureValue != null);
        }

        if (EditorGUI.EndChangeCheck())
        {
            if (useDetailMap == true)
            {
                // 使用DetailMode，那么开启正确的Detail分支
                SetupMaterialDetailBlendMode(material, (DetailBlendMode)detailBlendMode.floatValue);
            }
            else
            {
                // 否则关闭Detail分支
                SetupMaterialDetailBlendMode(material, DetailBlendMode.None);
            }
        }
    }

    static void SetKeyword(Material m, string keyword, bool state)
    {
        if (state)
            m.EnableKeyword(keyword);
        else
            m.DisableKeyword(keyword);
    }

    void DetailBlendPopup()
    {
        EditorGUI.showMixedValue = detailBlendMode.hasMixedValue;
        var detailBlend = (DetailBlendMode)detailBlendMode.floatValue;

        EditorGUI.BeginChangeCheck();
        detailBlend = (DetailBlendMode)EditorGUILayout.Popup("Detail Blend Mode", (int)detailBlend, detailBlendModeNames);
        if (EditorGUI.EndChangeCheck())
        {
            m_MaterialEditor.RegisterPropertyChangeUndo("Detail Blend Mode");
            detailBlendMode.floatValue = (float)detailBlend;
            Debug.Log(detailBlend);
        }
        EditorGUI.showMixedValue = false;
    }

    public static void SetupMaterialDetailBlendMode(Material material, DetailBlendMode detialBlendMode)
    {
        material.DisableKeyword("_DETAIL_MULX2");
        material.DisableKeyword("_DETAIL_ADD");
        material.DisableKeyword("_DETAIL_MUL");
        material.DisableKeyword("_DETAIL_LERP");
        material.DisableKeyword("_DETAIL_DESATURATE");

        if (detialBlendMode == DetailBlendMode.None)
        {
            // 没有Detail Mode
            return;
        }

        // 下面并不影响Shader流程，但是却能够记录Shader分支变量进入Material中
        material.SetInt("_DetialBlendMode", (int)detialBlendMode);
        switch (detialBlendMode)
        {
            case DetailBlendMode.Add:
                material.EnableKeyword("_DETAIL_ADD");
                break;
            case DetailBlendMode.Mul:
                material.EnableKeyword("_DETAIL_MUL");
                break;
            case DetailBlendMode.MulX2:
                material.EnableKeyword("_DETAIL_MULX2");
                break;
            case DetailBlendMode.Lerp:
                material.EnableKeyword("_DETAIL_LERP");
                break;
            case DetailBlendMode.DesaturateBlend:
                material.EnableKeyword("_DETAIL_DESATURATE");
                break;
        }
    }
}
